/**
 * Danganronpa RPG — the camera dock.
 * ---------------------------------------------------------------------------
 * Two things, both applied on every `renderCameraViews`:
 *
 *   1. Restyle it to match the rest of this module — the same purple accents
 *      and dark panels every other DRPG surface uses, instead of Foundry's
 *      default chrome sitting next to it looking like a different app.
 *
 *   2. Show the character's name instead of the account's. Voice already
 *      scopes who is even in a call to "people in your room" (see voice.mjs),
 *      so nothing is leaked by this that the room itself has not already —
 *      it just means the label matches what the sheet and the map already
 *      call that person, an account name never needed to appear anywhere in
 *      play at all.
 *
 * The name label is claimed the same way sheet.mjs claims the trait frame:
 * a known class first, a content-matching fallback second, because this is
 * core Foundry markup this module does not control and a version bump is
 * free to rename it.
 */

import { error } from "./utils.mjs";

export function registerCameraView() {
    Hooks.on("renderCameraViews", onRenderCameraViews);
}

function onRenderCameraViews(app, element) {
    try {
        const root = element instanceof HTMLElement ? element : element?.[0];
        if (!root) return;

        root.classList.add("drpg-camera-dock");

        for (const box of root.querySelectorAll("[data-user]")) {
            const userId = box.dataset.user;
            if (!userId) continue;
            relabel(box, userId);
        }
    } catch (err) {
        error("Could not style the camera dock", err);
    }
}

/** Swap the displayed name for this participant's character, if they have one. */
function relabel(box, userId) {
    const user = game.users.get(userId);
    if (!user) return;

    const actor = user.character
        ?? game.actors.find(a => a.type === "character" && a.testUserPermission(user, "OWNER"));
    if (!actor || actor.name === user.name) return; // nothing to change

    const label = findNameLabel(box, user.name);
    if (!label) return;

    if (label.dataset.drpgOriginalName === undefined) {
        label.dataset.drpgOriginalName = label.textContent ?? "";
    }
    label.textContent = actor.name;
}

/**
 * Several routes to the same element, tried in order. Foundry's own class
 * first; failing that, whichever element's text is exactly the account name
 * — the one thing guaranteed to be true regardless of what the element is
 * called.
 */
function findNameLabel(box, accountName) {
    const known = box.querySelector(".player-name, .charname, .name");
    if (known) return known;

    for (const el of box.querySelectorAll("*")) {
        if (el.children.length) continue; // only leaf nodes hold the plain name
        if (el.textContent?.trim() === accountName) return el;
    }
    return null;
}
