/**
 * Danganronpa RPG — calling the GM, and asking them to write.
 * ---------------------------------------------------------------------------
 * Two jobs:
 *
 *   callGm()  — the guide's actions that need a human ruling (Think, Listen,
 *               Analyze, Direct Murder, starting a project). The player's roll
 *               and request are whispered to the GMs with the context they need
 *               to answer, so nobody has to shout across the table.
 *
 *   request*() — world settings can only be written by a GM client, so a
 *               player's project progress is forwarded over the socket.
 */

import { MODULE_ID, TRAITS, HOPE_CALLS, DESPAIR_CALLS, STARTING } from "./config.mjs";
import { whisperToGms, whisperToOwner, isPrimaryGm, dialogContent, debug, warn, error } from "./utils.mjs";

const SOCKET_EVENT = `module.${MODULE_ID}`;
const ACTION_PROGRESS = "project.progress";
const ACTION_SHARE = "project.share";
const ACTION_REMNANT = "remnant.place";
const ACTION_REMNANT_EDIT = "remnant.edit";
const ACTION_CREATE = "project.create";
const ACTION_SABOTAGE = "project.sabotage";
const ACTION_UNSABOTAGE = "project.unsabotage";
const ACTION_SENDBACK = "token.sendBack";
const ACTION_ECLIPSE_MOVE = "eclipse.move";
const ACTION_ARM = "call.arm";
const ACTION_DESPAIR = "despair.adjust";
const ACTION_DIFFICULTY = "dynamic.difficulty";
const ACTION_DIFFICULTY_RESULT = "dynamic.difficultyResult";
const ACTION_ACK = "bridge.ack";

/** Player-side promises waiting on a GM ruling, keyed by request id. */
const pendingRulings = new Map();

export function registerGmBridge() {
    game.socket.on(SOCKET_EVENT, onSocket);
    // The answer travels back to the asking player, who is not a GM — so this
    // listener has to sit outside the `isPrimaryGm` gate in `onSocket`.
    game.socket.on(SOCKET_EVENT, onRulingResult);
    // Same reason as above: the acknowledgement travels back to a player.
    game.socket.on(SOCKET_EVENT, onAck);
}

/* ==========================================================================
 * ACKNOWLEDGEMENTS
 * --------------------------------------------------------------------------
 * Most of these requests are fire-and-forget: emit, return `{pending:true}`,
 * hope. `hasGm()` only proves a GM was connected at the moment of asking, so a
 * GM who dropped a second later took the request with them and the player was
 * never told — a sabotage, a project, a Remnant simply never happened.
 *
 * So every request now carries an id, and the receiving GM says "got it". No
 * answer inside the window means nobody is listening, and the player finds out
 * rather than waiting for something that is not coming.
 * ========================================================================== */

const awaitingAck = new Map();
const ACK_TIMEOUT_MS = 8000;

/** Watch for a "got it" and complain if none arrives. Returns the request id. */
function expectAck(label) {
    const requestId = foundry.utils.randomID();
    const timer = setTimeout(() => {
        if (!awaitingAck.has(requestId)) return;
        awaitingAck.delete(requestId);
        ui.notifications.warn(game.i18n.format("DRPG.Bridge.noAnswer", { what: label }));
        warn(`No GM acknowledged "${label}" within ${ACK_TIMEOUT_MS}ms.`);
    }, ACK_TIMEOUT_MS);
    awaitingAck.set(requestId, timer);
    return requestId;
}

function onAck(payload) {
    if (payload?.action !== ACTION_ACK) return;
    if (payload.userId !== game.user.id) return;
    const timer = awaitingAck.get(payload.requestId);
    if (timer === undefined) return;
    clearTimeout(timer);
    awaitingAck.delete(payload.requestId);
    debug(`Bridge request ${payload.requestId} acknowledged.`);
}

function onRulingResult(payload) {
    if (payload?.action !== ACTION_DIFFICULTY_RESULT) return;
    if (payload.userId !== game.user.id) return;

    const resolve = pendingRulings.get(payload.requestId);
    if (!resolve) return;
    pendingRulings.delete(payload.requestId);
    resolve(payload.ruling ?? null);
}

/**
 * Who asked, and may they.
 *
 * Every request below arrives as a plain socket message, and the primary GM used
 * to act on all of them without asking who sent it or whether the numbers were
 * sane. Anyone with a console could adjust a Despair pool, push progress onto
 * somebody else's project, or teleport a token. These two helpers are the whole
 * defence: the sender has to be a real, connected user, and anything scoped to an
 * actor has to be an actor that sender actually owns.
 */
function senderOf(payload) {
    const user = game.users.get(payload?.userId ?? payload?.senderId ?? "");
    return user?.active ? user : null;
}

function ownsActor(user, actorId) {
    if (!user || !actorId) return false;
    if (user.isGM) return true;
    return Boolean(game.actors.get(actorId)?.testUserPermission(user, "OWNER"));
}

/** Refuse loudly in the log rather than silently doing the wrong thing. */
function refuse(action, why) {
    warn(`Refused a "${action}" request over the socket: ${why}.`);
    return null;
}

async function onSocket(payload) {
    // The gate is per-action, not blanket. Keeping it up here meant every
    // handler that has to answer a *player* had to be registered as a separate
    // listener to escape it — a trap for the next one added.
    if (!payload?.action) return;
    if (payload.action === ACTION_ACK || payload.action === ACTION_DIFFICULTY_RESULT) return;
    if (!isPrimaryGm()) return;

    // Tell the asker a GM is here and has the request, before doing the work —
    // the point of the acknowledgement is "somebody is listening", and a slow
    // handler must not look like a dead socket.
    if (payload.requestId && payload.userId && payload.userId !== game.user.id) {
        game.socket.emit(SOCKET_EVENT, {
            action: ACTION_ACK, requestId: payload.requestId, userId: payload.userId
        });
    }

    if (payload?.action === ACTION_DIFFICULTY) {
        const { askDynamicDifficulty } = await import("./action-rolls.mjs");
        const ruling = await askDynamicDifficulty(payload);
        game.socket.emit(SOCKET_EVENT, {
            action: ACTION_DIFFICULTY_RESULT,
            requestId: payload.requestId,
            userId: payload.userId,
            ruling
        });
        return;
    }

    if (payload?.action === ACTION_PROGRESS) {
        if (!senderOf(payload)) return refuse(ACTION_PROGRESS, "unknown sender");

        // Progress comes from an action or a Call, so it is small by definition.
        // A payload asking for +999 is not the rules asking.
        const amount = Math.trunc(Number(payload.amount));
        if (!Number.isFinite(amount) || amount === 0 || Math.abs(amount) > STARTING.despairMax) {
            return refuse(ACTION_PROGRESS, `amount ${payload.amount} is out of range`);
        }

        const { addProgress } = await import("./projects.mjs");
        const result = await addProgress(payload.countdownId, amount);
        debug(`Applied ${payload.amount} progress to ${payload.countdownId} on behalf of a player.`, result);

        // Report back to whoever asked.
        //
        // A player cannot see whether their request arrived, was applied, or was
        // clamped to nothing — so a project that refused to move looked exactly
        // like a socket that never fired. Now it says which of the three it was.
        const to = payload.userId ? [payload.userId] : [];
        if (!to.length) return;

        const line = !result
            ? game.i18n.localize("DRPG.Project.gone")
            : result.changed === false
                ? game.i18n.format(result.reason ?? "DRPG.Project.alreadyFull", {
                      name: result.name, current: result.from, target: result.target
                  })
                : game.i18n.format("DRPG.Project.now", {
                      project: result.name, current: result.to, target: result.target
                  });

        await ChatMessage.create({
            content: `<p><strong>${game.i18n.localize("DRPG.Project.title")}</strong> — ${
                foundry.utils.escapeHTML(line)
            }</p>`,
            whisper: to
        });
        return;
    }

    if (payload?.action === ACTION_SHARE) {
        if (!senderOf(payload)) return refuse(ACTION_SHARE, "unknown sender");
        const { shareWith } = await import("./projects.mjs");
        await shareWith(payload.countdownId, payload.targetUserId);
        debug(`Shared project ${payload.countdownId} with ${payload.targetUserId} on behalf of a player.`);
        return;
    }

    if (payload?.action === ACTION_REMNANT) {
        const sender = senderOf(payload);
        if (!ownsActor(sender, payload.data?.sourceActor)) {
            return refuse(ACTION_REMNANT, "sender does not own the character leaving it");
        }
        const { placeRemnant } = await import("./remnants.mjs");
        await placeRemnant(payload.data);
        debug("Placed a Remnant on behalf of a player.");
        return;
    }

    if (payload?.action === ACTION_REMNANT_EDIT) {
        const sender = senderOf(payload);
        if (!sender) return refuse(ACTION_REMNANT_EDIT, "unknown sender");

        // Only the character who left it may re-rate it, which is what a reroll
        // of their own action is. Anyone else editing evidence is the one thing
        // an investigation cannot survive.
        const scene = game.scenes.get(payload.sceneId) ?? canvas?.scene;
        const token = scene?.tokens?.get(payload.tokenId);
        const { REMNANT_FLAGS } = await import("./remnants.mjs");
        const source = token?.getFlag(MODULE_ID, REMNANT_FLAGS.sourceActor);
        if (!ownsActor(sender, source)) {
            return refuse(ACTION_REMNANT_EDIT, "sender did not leave that Remnant");
        }

        const { retuneRemnant } = await import("./remnants.mjs");
        await retuneRemnant(payload.sceneId, payload.tokenId, payload.patch ?? {});
        debug("Retuned a Remnant on behalf of a player.", payload.patch);
        return;
    }

    if (payload?.action === ACTION_SABOTAGE) {
        if (!senderOf(payload)) return refuse(ACTION_SABOTAGE, "unknown sender");
        const { sabotageProject } = await import("./projects.mjs");
        await sabotageProject(payload.targetId, payload.difficulty);
        return;
    }

    if (payload?.action === ACTION_UNSABOTAGE) {
        if (!senderOf(payload)) return refuse(ACTION_UNSABOTAGE, "unknown sender");
        const { undoSabotage } = await import("./projects.mjs");
        await undoSabotage(payload.targetId, payload.repairId);
        return;
    }

    if (payload?.action === ACTION_SENDBACK) {
        const sender = senderOf(payload);
        const scene = game.scenes.get(payload.sceneId);
        const token = scene?.tokens?.get(payload.tokenId);
        if (!ownsActor(sender, token?.actorId)) {
            return refuse(ACTION_SENDBACK, "sender does not own that token");
        }
        const { REVERT } = await import("./movement.mjs");
        if (token) await token.update(payload.position, { animate: false, [REVERT]: true });
        return;
    }

    if (payload?.action === ACTION_ARM) {
        const actor = game.actors.get(payload.actorId);
        if (!actor) return;
        if (!senderOf(payload)) return refuse(ACTION_ARM, "unknown sender");

        // The Call has to be one the rules define, and `grants` has to be the
        // one that Call actually buys. Without this the payload was taken at
        // face value: "arm me a free critical" was a single socket emit away.
        const call = HOPE_CALLS[payload.call?.key] ?? DESPAIR_CALLS[payload.call?.key];
        if (!call || call.grants !== payload.call?.grants) {
            return refuse(ACTION_ARM, `"${payload.call?.key}" does not grant "${payload.call?.grants}"`);
        }

        const { MODULE_ID: id, FLAGS } = await import("./config.mjs");
        await actor.setFlag(id, FLAGS.pendingCall, payload.call);
        debug(`Armed ${payload.call?.key} on ${actor.name} on behalf of a player.`);
        // The beneficiary is not the buyer: tell them what they have been given,
        // or they will meet a locked roll dialog with no idea why it opened up.
        await whisperToOwner(actor, `<p><strong>${game.i18n.localize("DRPG.Calls.armedTitle")}</strong> — ${
            game.i18n.format("DRPG.Calls.armedForYou", {
                what: game.i18n.localize(`DRPG.Calls.grants.${payload.call?.grants}`)
            })
        }</p>`);
        return;
    }

    if (payload?.action === ACTION_DESPAIR) {
        const sender = senderOf(payload);
        if (!sender) return refuse(ACTION_DESPAIR, "unknown sender");

        // The only legitimate player-side Despair adjustment is a reroll giving
        // one point back or taking one. Anything larger is not the rules asking.
        const delta = Math.trunc(Number(payload.delta));
        if (!Number.isFinite(delta) || Math.abs(delta) !== 1) {
            return refuse(ACTION_DESPAIR, `delta ${payload.delta} is out of range`);
        }
        const target = game.users.get(payload.targetUserId ?? "");
        if (target?.role !== CONST.USER_ROLES.GAMEMASTER) {
            return refuse(ACTION_DESPAIR, "target is not a Gamemaster");
        }

        const { adjustDespair } = await import("./despair.mjs");
        await adjustDespair(target.id, delta);
        debug(`Adjusted Despair for ${target.name} by ${delta} on behalf of ${sender.name}.`);
        return;
    }

    if (payload?.action === ACTION_ECLIPSE_MOVE) {
        const sender = senderOf(payload);
        if (!ownsActor(sender, payload.actorId)) {
            return refuse(ACTION_ECLIPSE_MOVE, "sender does not own that character");
        }
        const { applyRecordedMove } = await import("./eclipse.mjs");
        await applyRecordedMove(payload.actorId);
        return;
    }

    if (payload?.action === ACTION_CREATE) {
        if (!senderOf(payload)) return refuse(ACTION_CREATE, "unknown sender");
        const { createProject } = await import("./projects.mjs");
        const made = await createProject(payload.data);
        if (made) {
            // Tell the GMs what appeared, so nothing is created behind their back.
            await whisperToGms(`<h3>${game.i18n.localize("DRPG.Project.startNew")}</h3>
                <p><strong>${foundry.utils.escapeHTML(payload.data.by ?? "?")}</strong> — ${foundry.utils.escapeHTML(made.name)}
                (${made.target} progress${payload.data.room ? `, ${foundry.utils.escapeHTML(payload.data.room)}` : ""})${
                payload.data.indirectMurder ? ` · <em>${game.i18n.localize("DRPG.Project.indirect")}</em>` : ""}</p>
                <p><em>${game.i18n.localize("DRPG.Project.gmCanAdjust")}</em></p>`);
        }
    }
}

/**
 * Arm a Call on somebody else's character.
 *
 * Support gives another player advantage. Flags live on the beneficiary's actor,
 * which the buyer has no write access to — hence "Player A lacks permission".
 * The GM owns everything, so they set it.
 */
export async function requestArmCall(actorId, call) {
    if (game.user.isGM) {
        const actor = game.actors.get(actorId);
        if (!actor) return null;
        const { MODULE_ID: id, FLAGS } = await import("./config.mjs");
        await actor.setFlag(id, FLAGS.pendingCall, call);
        return true;
    }
    if (!hasGm()) return null;
    game.socket.emit(SOCKET_EVENT, { action: ACTION_ARM, userId: game.user.id, requestId: expectAck(call?.key ?? "Call"), actorId, call });
    return true;
}

/**
 * Despair pools are a world setting; a player's reroll asks the GM to fix one.
 *
 * `userId` is the sender, `targetUserId` the Monokuma being adjusted. They used
 * to be the same field, which is how the GM side had no way of telling who was
 * asking from whose pool was moving.
 */
export async function requestDespairAdjust(targetUserId, delta) {
    if (game.user.isGM) {
        const { adjustDespair } = await import("./despair.mjs");
        return adjustDespair(targetUserId, delta);
    }
    if (!hasGm()) return null;
    game.socket.emit(SOCKET_EVENT, {
        action: ACTION_DESPAIR, userId: game.user.id,
        requestId: expectAck("Despair"), targetUserId, delta
    });
    return { pending: true };
}

/** Sabotage writes two world settings; the GM applies it. */
export function requestSabotage(targetId, difficulty) {
    if (!hasGm()) return null;
    game.socket.emit(SOCKET_EVENT, { action: ACTION_SABOTAGE, userId: game.user.id, requestId: expectAck("Sabotage"), targetId, difficulty });
    return { pending: true };
}

/** And taking one back writes the same two, so it travels the same way. */
export function requestUndoSabotage(targetId, repairId) {
    if (!hasGm()) return null;
    game.socket.emit(SOCKET_EVENT, { action: ACTION_UNSABOTAGE, userId: game.user.id, requestId: expectAck("Sabotage"), targetId, repairId });
    return { pending: true };
}

/** A player whose token cannot be moved back asks the GM to do it. */
export function requestSendBack(sceneId, tokenId, position) {
    if (!hasGm()) return null;
    game.socket.emit(SOCKET_EVENT, { action: ACTION_SENDBACK, userId: game.user.id, requestId: expectAck("Move"), sceneId, tokenId, position });
    return { pending: true };
}

/** Count an Eclipse crossing on the GM's copy of the world setting. */
export function requestEclipseMove(actorId) {
    if (!hasGm()) return null;
    game.socket.emit(SOCKET_EVENT, { action: ACTION_ECLIPSE_MOVE, userId: game.user.id, requestId: expectAck("Eclipse"), actorId });
    return { pending: true };
}

/** Creating a countdown writes a world setting, so the GM does it for us. */
export function requestProjectCreate(data) {
    if (game.user.isGM) {
        return import("./projects.mjs").then(m => m.createProject(data));
    }
    if (!hasGm()) return null;
    game.socket.emit(SOCKET_EVENT, { action: ACTION_CREATE, userId: game.user.id, requestId: expectAck("Project"), data });
    return { pending: true };
}

/** Creating tokens is GM-only, so a player's Remnant is placed for them. */
export function requestRemnant(data) {
    if (!hasGm()) return null;
    game.socket.emit(SOCKET_EVENT, { action: ACTION_REMNANT, userId: game.user.id, requestId: expectAck("Remnant"), data });
    return { pending: true };
}

/**
 * Retune or remove a Remnant a player's own action left behind — a reroll has
 * changed how well they hid it, or removed the reason for the trace entirely.
 * Editing tokens is GM-only, same as creating them.
 */
export function requestRemnantEdit(sceneId, tokenId, patch) {
    if (!hasGm()) return null;
    game.socket.emit(SOCKET_EVENT, { action: ACTION_REMNANT_EDIT, userId: game.user.id, requestId: expectAck("Remnant"), sceneId, tokenId, patch });
    return { pending: true };
}

function hasGm() {
    if (game.users.some(u => u.isGM && u.active)) return true;
    ui.notifications.warn(game.i18n.localize("DRPG.Bridge.noGm"));
    return false;
}

/**
 * Ask a GM how hard a described action is.
 *
 * The guide gives the threshold to the GM: "the player describes something, the
 * GM picks a threshold". The picker used to render on the player's own client,
 * so the person being tested chose their own difficulty — and would always
 * choose the easiest band. The dialog now opens on the GM's screen and the
 * answer comes back over the socket.
 *
 * Generous timeout on purpose: a GM reading a description and making a ruling is
 * a human taking their time, not a machine failing to answer.
 *
 * @returns {Promise<{tier: number, trait: string}|null>} null if refused or unanswered.
 */
export function requestDynamicDifficulty({ description, actorName, room }, timeoutMs = 180000) {
    if (!hasGm()) return Promise.resolve(null);

    const requestId = foundry.utils.randomID();
    return new Promise(resolve => {
        pendingRulings.set(requestId, resolve);
        game.socket.emit(SOCKET_EVENT, {
            action: ACTION_DIFFICULTY,
            requestId,
            userId: game.user.id,
            description, actorName, room
        });

        setTimeout(() => {
            if (!pendingRulings.has(requestId)) return;
            pendingRulings.delete(requestId);
            ui.notifications.warn(game.i18n.localize("DRPG.Action.dynamicNoRuling"));
            resolve(null);
        }, timeoutMs);
    });
}

/** Ask the GM to add project progress on our behalf. */
export function requestProjectProgress(countdownId, amount) {
    if (!hasGm()) return null;
    game.socket.emit(SOCKET_EVENT, {
        action: ACTION_PROGRESS, countdownId, amount,
        userId: game.user.id, requestId: expectAck("Project")
    });
    // `changed` is unknown from here — the GM whispers back what actually
    // happened. Claiming success would be a guess.
    return { pending: true, changed: null };
}

/**
 * Ask the GM to let another player in on a secret project. Players are allowed
 * to bring someone in on their own plan — the guide's whole social engine runs
 * on conspiracies — but the write itself has to happen GM-side.
 */
export function requestProjectShare(countdownId, userId) {
    if (!hasGm()) return null;
    game.socket.emit(SOCKET_EVENT, { action: ACTION_SHARE, userId: game.user.id, requestId: expectAck("Project"), countdownId, targetUserId: userId });
    return { pending: true };
}

/* ==========================================================================
 * CALLING THE GM
 * ========================================================================== */

/**
 * Whisper a ruling request to the GMs and confirm to the player that it went.
 *
 * @param {Actor} actor
 * @param {object} params
 * @param {string} params.title     What is being asked, e.g. "Think".
 * @param {string} [params.body]    Extra context, already escaped.
 * @param {object} [params.roll]    Result of the roll, if one was made.
 * @param {string} [params.request] The player's own words.
 * @param {string} [params.room]    Where they are standing.
 */
export async function callGm(actor, { title, body = "", roll = null, request = "", room = null } = {}) {
    const esc = s => foundry.utils.escapeHTML(String(s ?? ""));
    const parts = [];

    parts.push(`<h3>${esc(title)}</h3>`);
    parts.push(`<p><strong>${esc(actor?.name ?? "?")}</strong>${room ? ` · ${esc(room)}` : ""}</p>`);

    if (roll) {
        const traitLabel = TRAITS[roll.trait]?.label ?? roll.trait ?? "";
        parts.push(`<p>${traitLabel} · <strong>${roll.total}</strong>${
            roll.isCritical ? ` · <em>${game.i18n.localize("DRPG.Action.critical")}</em>`
            : roll.withHope ? " · Hope"
            : roll.withFear ? " · Despair" : ""
        }</p>`);

        // The guide owes the player a substantial hint on a critical Observe or
        // Analyze. Say so loudly rather than leaving the GM to remember it.
        if (roll.isCritical) {
            parts.push(`<p class="drpg-warning"><strong>${
                game.i18n.localize("DRPG.Bridge.criticalHint")
            }</strong></p>`);
        }
    }

    if (request) parts.push(`<blockquote>${esc(request)}</blockquote>`);
    if (body) parts.push(`<p>${body}</p>`);
    parts.push(`<p><em>${game.i18n.localize("DRPG.Bridge.awaitingRuling")}</em></p>`);

    try {
        await whisperToGms(parts.join(""));
        await whisperToOwner(actor, `<p><em>${game.i18n.format("DRPG.Bridge.sent", { title: esc(title) })}</em></p>`);
        return true;
    } catch (err) {
        error("Could not reach the GM", err);
        return false;
    }
}

/**
 * Ask the player what they want, then send it to the GM. Returns the text, or
 * null if they backed out.
 */
export async function promptAndCallGm(actor, { title, prompt, placeholder = "", roll = null, room = null }) {
    const DialogV2 = foundry.applications.api.DialogV2;

    const text = await DialogV2.wait({
        window: { title },
        content: dialogContent(`<form>
                    <p>${prompt}</p>
                    <textarea name="request" rows="3" placeholder="${foundry.utils.escapeHTML(placeholder)}"></textarea>
                  </form>`),
        buttons: [
            {
                action: "send",
                label: game.i18n.localize("DRPG.Bridge.send"),
                default: true,
                callback: (event, button, dialog) => dialog.element.querySelector("[name=request]").value.trim()
            },
            { action: "cancel", label: game.i18n.localize("DRPG.Advance.cancel") }
        ],
        rejectClose: false
    });

    if (text === "cancel" || text === null || text === undefined) return null;

    await callGm(actor, { title, roll, request: text, room });
    return text;
}
