/**
 * Danganronpa RPG — who is a Monokuma, and whose Despair they spend.
 * ---------------------------------------------------------------------------
 * Two questions that used to have no answer anywhere in the interface:
 *
 *   1. which actors are Monokumas at all — only reachable from a context-menu
 *      toggle in the actor directory, easy to miss and easy to forget
 *   2. which Despair pool each of them draws on
 *
 * The second one had no answer even in the data. `poolUserFor` guessed from
 * ownership, and every GM is an owner of every actor, so with two Gamemasters
 * the guess collapsed to "whoever is looking at the sheet". Monokuma and
 * Monomi therefore showed — and spent — the same pool, which is exactly the
 * bug this panel exists to make impossible: the link is now stated, stored in
 * world state, and visible in one table.
 */

import { monokumas } from "./despair.mjs";
import { isMonokuma, setMonokuma, poolFor, setPools } from "./monokuma.mjs";
import { error } from "./utils.mjs";

const DialogV2 = foundry.applications.api.DialogV2;

/** Open the Monokuma panel. GM only. */
export async function openMonokumaDialog() {
    if (!game.user.isGM) {
        ui.notifications.warn(game.i18n.localize("DRPG.Panel.gmOnly"));
        return null;
    }

    const gms = monokumas();
    if (!gms.length) {
        ui.notifications.warn(game.i18n.localize("DRPG.Assign.noMonokumas"));
        return null;
    }

    const actors = game.actors
        .filter(a => a.type === "character")
        .sort((a, b) => a.name.localeCompare(b.name));

    if (!actors.length) {
        ui.notifications.warn(game.i18n.localize("DRPG.Panel.noCharacters"));
        return null;
    }

    const result = await DialogV2.wait({
        window: { title: game.i18n.localize("DRPG.Monokuma.panelTitle") },
        classes: ["drpg-panel", "drpg-projects", "drpg-monokuma-panel"],
        content: buildContent(actors, gms),
        buttons: [
            {
                action: "save",
                label: game.i18n.localize("DRPG.Assign.save"),
                default: true,
                callback: (event, button, dialog) => readForm(dialog, actors)
            },
            { action: "cancel", label: game.i18n.localize("DRPG.Panel.close") }
        ],
        render: (event, dialog) => wire(dialog),
        rejectClose: false
    });

    if (!result || result === "cancel") return null;

    try {
        // The flag first: `setMonokuma` clears the action budget and Hope, and a
        // pool entry for an actor that is not a Monokuma would be dead state.
        for (const row of result) {
            const actor = game.actors.get(row.id);
            if (!actor) continue;
            if (isMonokuma(actor) !== row.monokuma) await setMonokuma(actor, row.monokuma);
        }

        const pools = {};
        for (const row of result) {
            if (row.monokuma && row.pool) pools[row.id] = row.pool;
        }
        await setPools(pools);

        ui.notifications.info(game.i18n.localize("DRPG.Monokuma.saved"));
        return pools;
    } catch (err) {
        error("Could not save the Monokuma panel", err);
        ui.notifications.error(game.i18n.localize("DRPG.Assign.failed"));
        return null;
    }
}

function buildContent(actors, gms) {
    const rows = actors.map(actor => {
        const marked = isMonokuma(actor);
        const pool = poolFor(actor);

        const options = [
            `<option value="">${game.i18n.localize("DRPG.Monokuma.noPool")}</option>`,
            ...gms.map(u => `<option value="${u.id}"${u.id === pool ? " selected" : ""}>${
                foundry.utils.escapeHTML(u.name)
            }</option>`)
        ].join("");

        return `<tr data-actor="${actor.id}"${marked ? ' class="drpg-is-monokuma"' : ""}>
            <td>
                <img src="${actor.img}" alt="" class="drpg-monokuma-portrait" />
                ${foundry.utils.escapeHTML(actor.name)}
            </td>
            <td style="text-align:center">
                <input type="checkbox" name="mk.${actor.id}" data-drpg-mk ${marked ? "checked" : ""} />
            </td>
            <td>
                <select name="pool.${actor.id}" data-drpg-pool ${marked ? "" : "disabled"}>${options}</select>
            </td>
        </tr>`;
    }).join("");

    return `<form>
        <p>${game.i18n.localize("DRPG.Monokuma.panelIntro")}</p>
        <div class="drpg-monokuma-warning"></div>
        <table>
            <thead><tr>
                <th>${game.i18n.localize("DRPG.Panel.character")}</th>
                <th>${game.i18n.localize("DRPG.Monokuma.isMonokuma")}</th>
                <th>${game.i18n.localize("DRPG.Monokuma.pool")}</th>
            </tr></thead>
            <tbody>${rows}</tbody>
        </table>
        <p class="notes">${game.i18n.localize("DRPG.Monokuma.panelNote")}</p>
    </form>`;
}

/**
 * The pool picker only means anything for a Monokuma, and two Monokumas sharing
 * one pool is the exact mistake this panel was built to catch — so it is called
 * out live rather than discovered three sessions later.
 */
function wire(dialog) {
    const root = dialog.element;
    const warning = root.querySelector(".drpg-monokuma-warning");

    const refresh = () => {
        const used = new Map();

        for (const box of root.querySelectorAll("[data-drpg-mk]")) {
            const row = box.closest("tr");
            const select = row?.querySelector("[data-drpg-pool]");
            row?.classList.toggle("drpg-is-monokuma", box.checked);
            if (!select) continue;

            select.disabled = !box.checked;
            if (!box.checked) continue;

            const value = select.value;
            if (!value) continue;
            if (!used.has(value)) used.set(value, []);
            used.get(value).push(row.querySelector("td")?.textContent?.trim() ?? "?");
        }

        if (!warning) return;
        const clashes = Array.from(used.entries()).filter(([, names]) => names.length > 1);
        warning.innerHTML = clashes.length
            ? `<p class="drpg-warning">${clashes.map(([userId, names]) =>
                  game.i18n.format("DRPG.Monokuma.sharedPool", {
                      name: foundry.utils.escapeHTML(game.users.get(userId)?.name ?? "?"),
                      actors: foundry.utils.escapeHTML(names.join(", "))
                  })).join("<br>")}</p>`
            : "";
    };

    root.querySelectorAll("[data-drpg-mk], [data-drpg-pool]")
        .forEach(el => el.addEventListener("change", refresh));
    refresh();
}

function readForm(dialog, actors) {
    const root = dialog.element;
    return actors.map(actor => ({
        id: actor.id,
        monokuma: root.querySelector(`[name="mk.${CSS.escape(actor.id)}"]`)?.checked ?? false,
        pool: root.querySelector(`[name="pool.${CSS.escape(actor.id)}"]`)?.value || null
    }));
}
