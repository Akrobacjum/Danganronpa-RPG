/**
 * Danganronpa RPG — the GM's side of an Investigation.
 * ---------------------------------------------------------------------------
 * Guide, p. 28: "DM szykuje 5 poszlak przed morderstwem: Banalną, Standardową,
 * Standardową, Skomplikowaną, Desperacką. Ich ostateczna ilość jest zależna od
 * rzutów kością na otwarciu morderstwa, ale nigdy mniejsza, niż 3. Wszystkie 5
 * Key Remnants łącznie powinno zawężać krąg podejrzanych do 3-8 graczy."
 *
 * Two screens, and between them they answer the only two questions a GM has
 * during an Investigation:
 *
 *   the planner    what are my five clues, and have I actually put them on the
 *                  map — or am I one session in with three of them still in my
 *                  head?
 *   the dashboard  who has found what, how much of the case is reachable, and
 *                  is this trial about to fail because nobody found the
 *                  evidence that makes it work?
 *
 * The dashboard is the one place in this module that reads the answer key in
 * bulk, which is why it is GM-only in the strongest sense: it runs nowhere else
 * (see D6 — the ledger only exists on a GM's browser).
 */

import { MODULE_ID, KEY_REMNANTS, TRUTH_BULLET_TYPES } from "./config.mjs";
import { SETTINGS } from "./settings.mjs";
import { getClock } from "./clock.mjs";
import { remnantsOn, remnantData } from "./remnants.mjs";
import { bulletsOf, secretOf, truthBulletData } from "./truth-bullets.mjs";
import { studentActors } from "./monokuma.mjs";
import { monokumas, adjustDespair, poolLabel } from "./despair.mjs";
import { isDeceased } from "./chapter.mjs";
import { dialogContent, whisperToGms, log, error } from "./utils.mjs";

const DialogV2 = foundry.applications.api.DialogV2;

/** Human labels for the guide's five difficulty steps. */
const SCALE_LABELS = {
    trivial: "Trivial",
    standard: "Standard",
    complex: "Complex",
    desperate: "Desperate"
};

/* ==========================================================================
 * THE PLAN
 * ========================================================================== */

/** The plan as stored, or a fresh one for this chapter. */
export function keyPlan() {
    const stored = game.settings.get(MODULE_ID, SETTINGS.keyRemnantPlan) ?? {};
    const chapter = getClock().chapter;

    // A plan belongs to one murder. When the chapter has moved on, the previous
    // chapter's clues are not this chapter's blanks — start clean rather than
    // present stale text as though it were the current case.
    if (stored.chapter !== chapter) {
        return {
            chapter,
            entries: KEY_REMNANTS.scale.map(scale => ({
                scale, note: "", tokenId: null, sceneId: null
            }))
        };
    }
    return stored;
}

/** Save the plan. GM only. */
export async function setKeyPlan(plan) {
    if (!game.user.isGM) return null;
    await game.settings.set(MODULE_ID, SETTINGS.keyRemnantPlan, plan);
    return plan;
}

/** Every Key Remnant currently on the map, across every scene. */
function placedKeyRemnants() {
    const out = [];
    for (const scene of game.scenes) {
        for (const token of remnantsOn(scene)) {
            const data = remnantData(token);
            if (data?.type !== "key") continue;
            out.push({ token, data, scene });
        }
    }
    return out;
}

/**
 * Who has copied which Key Remnant.
 *
 * Read off the ledger rather than off what the players can see: a Key bullet
 * arrives identified, but a GM who issued one by hand as "unidentified" would
 * otherwise vanish from this count — and this count is what decides whether the
 * trial is solvable.
 */
function findersByRemnant() {
    const map = new Map();
    for (const actor of studentActors()) {
        for (const item of bulletsOf(actor)) {
            const secret = secretOf(item.uuid);
            if (secret.realType !== "key" || !secret.remnantId) continue;
            if (!map.has(secret.remnantId)) map.set(secret.remnantId, new Set());
            map.get(secret.remnantId).add(actor.name);
        }
    }
    return map;
}

/**
 * The plan, scored against reality.
 *
 * @returns {{entries: Array, placed: number, found: number, missing: number}}
 */
export function keyPlanStatus() {
    const plan = keyPlan();
    const finders = findersByRemnant();
    const onMap = new Set(placedKeyRemnants().map(r => r.token.id));

    const entries = plan.entries.map(entry => {
        const placed = Boolean(entry.tokenId && onMap.has(entry.tokenId));
        const who = entry.tokenId ? Array.from(finders.get(entry.tokenId) ?? []) : [];
        return { ...entry, placed, finders: who, found: who.length > 0 };
    });

    return {
        entries,
        placed: entries.filter(e => e.placed).length,
        found: entries.filter(e => e.found).length,
        missing: entries.filter(e => !e.found).length
    };
}

/** The planner: five clues, their notes, and which token each one is. */
export async function openKeyPlanner() {
    if (!game.user.isGM) {
        ui.notifications.warn(game.i18n.localize("DRPG.Panel.gmOnly"));
        return null;
    }

    const plan = keyPlan();
    const placed = placedKeyRemnants();

    const options = placed.map(r => {
        const label = `${r.data.visibilityLabel}${r.data.room ? ` · ${r.data.room}` : ""}`
            + `${r.data.note ? ` · ${r.data.note}` : ""}`
            + `${game.scenes.size > 1 ? ` · ${r.scene.name}` : ""}`;
        return { id: r.token.id, sceneId: r.scene.id, label };
    });

    const rows = plan.entries.map((entry, i) => {
        const picker = options.map(o =>
            `<option value="${o.id}|${o.sceneId}"${o.id === entry.tokenId ? " selected" : ""}>${
                foundry.utils.escapeHTML(o.label)}</option>`).join("");
        return `<tr>
            <td><strong>${foundry.utils.escapeHTML(SCALE_LABELS[entry.scale] ?? entry.scale)}</strong></td>
            <td><input type="text" name="note:${i}"
                value="${foundry.utils.escapeHTML(entry.note ?? "")}"
                placeholder="${game.i18n.localize("DRPG.Investigation.notePlaceholder")}" /></td>
            <td><select name="token:${i}">
                <option value="">${game.i18n.localize("DRPG.Investigation.notPlaced")}</option>
                ${picker}</select></td>
        </tr>`;
    }).join("");

    const result = await DialogV2.wait({
        window: { title: game.i18n.localize("DRPG.Investigation.plannerTitle") },
        classes: ["drpg-panel"],
        position: { width: 720 },
        content: dialogContent(`<form>
            <p>${game.i18n.format("DRPG.Investigation.plannerIntro", {
                chapter: plan.chapter,
                min: KEY_REMNANTS.suspectRange[0],
                max: KEY_REMNANTS.suspectRange[1]
            })}</p>
            <table class="drpg-vault-table"><thead><tr>
                <th>${game.i18n.localize("DRPG.Investigation.difficulty")}</th>
                <th>${game.i18n.localize("DRPG.Investigation.clue")}</th>
                <th>${game.i18n.localize("DRPG.Investigation.onMap")}</th>
            </tr></thead><tbody>${rows}</tbody></table>
            <p class="notes">${game.i18n.format("DRPG.Investigation.plannerNote", {
                min: KEY_REMNANTS.minimum
            })}</p>
        </form>`),
        buttons: [
            {
                action: "ok", label: game.i18n.localize("DRPG.Panel.apply"), default: true,
                callback: (e, b, d) => {
                    const f = d.element.querySelector("form");
                    return plan.entries.map((entry, i) => {
                        const raw = f.querySelector(`[name="token:${i}"]`)?.value ?? "";
                        const [tokenId, sceneId] = raw ? raw.split("|") : [null, null];
                        return {
                            scale: entry.scale,
                            note: f.querySelector(`[name="note:${i}"]`)?.value.trim() ?? "",
                            tokenId: tokenId || null,
                            sceneId: sceneId || null
                        };
                    });
                }
            },
            { action: "cancel", label: game.i18n.localize("DRPG.Advance.cancel") }
        ],
        rejectClose: false
    });

    if (!Array.isArray(result)) return null;

    await setKeyPlan({ chapter: plan.chapter, entries: result });
    ui.notifications.info(game.i18n.localize("DRPG.Investigation.plannerSaved"));
    return result;
}

/* ==========================================================================
 * THE DASHBOARD
 * ========================================================================== */

/** What each living student is holding, summarised. */
function evidenceByStudent() {
    return studentActors()
        .filter(a => !isDeceased(a))
        .map(actor => {
            const bullets = bulletsOf(actor).map(item => ({
                item,
                data: truthBulletData(item),
                real: secretOf(item.uuid).realType ?? "neutral"
            }));
            return {
                actor,
                total: bullets.length,
                keys: bullets.filter(b => b.real === "key").length,
                unidentified: bullets.filter(b => !b.data?.analyzed).length,
                types: bullets.reduce((acc, b) => {
                    acc[b.real] = (acc[b.real] ?? 0) + 1;
                    return acc;
                }, {})
            };
        });
}

/**
 * The Investigation at a glance, plus the guide's penalty for a case the
 * players could not reach.
 *
 * `KEY_REMNANTS.despairPerMissing` per missing clue, to EACH Monokuma. That is
 * not a punishment for the players — it is the guide balancing a trial the GM
 * made too hard to solve by handing the GM side the resources to press it.
 */
export async function openInvestigationDashboard() {
    if (!game.user.isGM) {
        ui.notifications.warn(game.i18n.localize("DRPG.Panel.gmOnly"));
        return null;
    }

    const status = keyPlanStatus();
    const students = evidenceByStudent();

    const keyRows = status.entries.map(entry => {
        const state = !entry.tokenId
            ? `<em>${game.i18n.localize("DRPG.Investigation.notPlaced")}</em>`
            : !entry.placed
                ? `<strong>${game.i18n.localize("DRPG.Investigation.tokenGone")}</strong>`
                : entry.found
                    ? foundry.utils.escapeHTML(entry.finders.join(", "))
                    : `<em>${game.i18n.localize("DRPG.Investigation.notFound")}</em>`;
        return `<tr>
            <td>${foundry.utils.escapeHTML(SCALE_LABELS[entry.scale] ?? entry.scale)}</td>
            <td>${foundry.utils.escapeHTML(entry.note || "—")}</td>
            <td>${state}</td>
        </tr>`;
    }).join("");

    const studentRows = students.map(s => {
        const breakdown = Object.entries(s.types)
            .map(([type, n]) => `${foundry.utils.escapeHTML(
                TRUTH_BULLET_TYPES[type]?.label ?? type)} ×${n}`)
            .join(", ");
        return `<tr>
            <td>${foundry.utils.escapeHTML(s.actor.name)}</td>
            <td>${s.total}</td>
            <td>${s.keys}</td>
            <td>${s.unidentified}</td>
            <td class="notes">${breakdown || "—"}</td>
        </tr>`;
    }).join("");

    // The guide's floor is three Key Remnants; the plan's own warning threshold
    // is one above it, so a GM is told the trial is getting thin BEFORE it is
    // actually unsolvable rather than at the moment it already is.
    const thin = status.found < KEY_REMNANTS.minimum + 1;

    const action = await DialogV2.wait({
        window: { title: game.i18n.localize("DRPG.Investigation.dashboardTitle") },
        classes: ["drpg-panel"],
        position: { width: 720 },
        content: dialogContent(`<div>
            <h4>${game.i18n.localize("DRPG.Investigation.keyHeading")}</h4>
            <p>${game.i18n.format("DRPG.Investigation.keySummary", {
                found: status.found, placed: status.placed, total: status.entries.length
            })}</p>
            <table class="drpg-vault-table"><thead><tr>
                <th>${game.i18n.localize("DRPG.Investigation.difficulty")}</th>
                <th>${game.i18n.localize("DRPG.Investigation.clue")}</th>
                <th>${game.i18n.localize("DRPG.Investigation.foundBy")}</th>
            </tr></thead><tbody>${keyRows}</tbody></table>

            ${thin ? `<p class="drpg-warning">${game.i18n.format("DRPG.Investigation.tooThin", {
                found: status.found, min: KEY_REMNANTS.minimum
            })}</p>` : ""}

            <h4>${game.i18n.localize("DRPG.Investigation.whoHasWhat")}</h4>
            <table class="drpg-vault-table"><thead><tr>
                <th>${game.i18n.localize("DRPG.Investigation.student")}</th>
                <th>${game.i18n.localize("DRPG.Investigation.bullets")}</th>
                <th>${game.i18n.localize("DRPG.Investigation.keysHeld")}</th>
                <th>${game.i18n.localize("DRPG.Investigation.unidentified")}</th>
                <th>${game.i18n.localize("DRPG.Investigation.breakdown")}</th>
            </tr></thead><tbody>${studentRows}</tbody></table>
        </div>`),
        buttons: [
            ...(status.missing ? [{
                action: "despair",
                label: game.i18n.format("DRPG.Investigation.awardDespair", {
                    n: status.missing * KEY_REMNANTS.despairPerMissing
                })
            }] : []),
            { action: "plan", label: game.i18n.localize("DRPG.Investigation.plannerTitle") },
            { action: "close", label: game.i18n.localize("DRPG.Panel.close"), default: true }
        ],
        rejectClose: false
    });

    if (action === "plan") return openKeyPlanner();
    if (action === "despair") return awardMissingKeyDespair();
    return null;
}

/**
 * Hand every Monokuma Despair for the Key Remnants nobody reached.
 *
 * Deliberately a button rather than something that fires at the trial: the GM
 * decides when the Investigation is over, and a clue found in the last five
 * minutes should not have already been paid for.
 */
export async function awardMissingKeyDespair() {
    if (!game.user.isGM) return 0;

    const status = keyPlanStatus();
    if (!status.missing) {
        ui.notifications.info(game.i18n.localize("DRPG.Investigation.nothingMissing"));
        return 0;
    }

    const amount = status.missing * KEY_REMNANTS.despairPerMissing;
    const names = [];

    for (const user of monokumas()) {
        try {
            await adjustDespair(user.id, amount);
            names.push(poolLabel(user));
        } catch (err) {
            error(`Could not award Despair to ${user.name}`, err);
        }
    }

    if (!names.length) {
        ui.notifications.warn(game.i18n.localize("DRPG.Investigation.noPools"));
        return 0;
    }

    await whisperToGms(`
        <h3>${game.i18n.localize("DRPG.Investigation.dashboardTitle")}</h3>
        <p>${game.i18n.format("DRPG.Investigation.awarded", {
            n: amount, missing: status.missing, who: foundry.utils.escapeHTML(names.join(", "))
        })}</p>`);

    log(`Awarded ${amount} Despair to ${names.length} pool(s) for ${status.missing} missing Key Remnant(s).`);
    return amount;
}
