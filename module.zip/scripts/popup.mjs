/**
 * Danganronpa RPG — the one popup every player-facing message uses.
 * ---------------------------------------------------------------------------
 * Search, Work on Project, Sabotage, a refused room crossing, a DM's reply, a
 * Despair Call, the time of day — all of it used to be a line in the sidebar
 * somebody had to notice. This is where all of it surfaces instead: a floating
 * card in the middle of the screen, purple for an ordinary update, red for
 * something that was refused, gold for evidence.
 *
 * Everyone gets them, GMs included. The chat log is still the paper trail, but
 * it is not a notification channel — during an incident nobody is reading it.
 *
 * Two ways something ends up here:
 *   showPopup()              called directly, when the caller wants a title or
 *                            a sticky card — `report()` in action-rolls.mjs,
 *                            the messenger, the Class Trial's evidence card.
 *   the createChatMessage    anything posted through `announce`,
 *   catch-all hook           `whisperToGms` or `whisperToOwner` in utils.mjs,
 *                            all of which stamp `MESSAGE_FLAG`. The accent
 *                            comes from a `popupKind` flag on the message;
 *                            `"none"` opts out for the callers that raise
 *                            their own richer card.
 */

import { MODULE_ID } from "./config.mjs";
import { MESSENGER_FLAGS } from "./messenger.mjs";
import { MESSAGE_FLAG } from "./utils.mjs";

const CONTAINER_ID = "drpg-popups";
const AUTO_DISMISS_MS = 12000;

function container() {
    let el = document.getElementById(CONTAINER_ID);
    if (!el) {
        el = document.createElement("div");
        el.id = CONTAINER_ID;
        document.body.append(el);
    }
    return el;
}

/**
 * Show a floating, auto-dismissing card on THIS client. Several can stack if
 * things happen close together.
 *
 * @param {string} bodyHtml       Already-escaped HTML.
 * @param {object} [options]
 * @param {string} [options.title]     Shown in a header bar. Omitted entirely
 *   when there is none — most whispers were never built with a clean title to
 *   pull out of them, and a generic placeholder label helps nobody.
 * @param {"info"|"error"|"evidence"|"objection"} [options.kind]  Only the accent
 *   changes: purple for an ordinary update (default), red for something
 *   refused, gold for evidence, loud red for an Objection.
 * @param {() => void} [options.onClick]   Extra action on click, before the
 *   card dismisses. Used to jump straight to the messenger for a DM reply.
 * @param {boolean} [options.sticky]  Stay until dismissed by hand. Evidence put
 *   in front of the table has to survive being read and argued with, which is
 *   considerably longer than twelve seconds.
 */
const KINDS = ["info", "error", "evidence", "objection"];

export function showPopup(bodyHtml, {
    title = null, kind = "info", onClick = null, sticky = false
} = {}) {
    const card = document.createElement("div");
    card.className = `drpg-popup drpg-popup-${KINDS.includes(kind) ? kind : "info"}`;

    // A sticky card must be closeable, so it grows a header even when the
    // caller did not ask for one — otherwise the only way out is the click
    // handler, which is not obvious and is not always harmless.
    if (!title && sticky) title = game.i18n.localize("DRPG.Panel.close");

    if (title) {
        const head = document.createElement("div");
        head.className = "drpg-popup-title";
        head.textContent = title;

        const close = document.createElement("button");
        close.type = "button";
        close.className = "drpg-popup-close";
        close.innerHTML = `<i class="fa-solid fa-xmark" inert></i>`;
        close.setAttribute("aria-label", game.i18n.localize("DRPG.Panel.close"));
        head.append(close);
        close.addEventListener("click", event => {
            event.preventDefault();
            event.stopPropagation();
            dismiss();
        });

        card.append(head);
    }

    const body = document.createElement("div");
    body.className = "drpg-popup-body";
    body.innerHTML = bodyHtml ?? "";
    card.append(body);

    container().append(card);

    let dismissed = false;
    const dismiss = () => {
        if (dismissed) return;
        dismissed = true;
        card.classList.add("leaving");
        setTimeout(() => card.remove(), 300);
    };

    // Click-anywhere-to-dismiss is right for a notification and wrong for a card
    // somebody is reading: a sticky one closes only from its own button, unless
    // the caller gave it something to do on click.
    if (!sticky || onClick) {
        card.addEventListener("click", () => {
            onClick?.();
            dismiss();
        });
    }

    requestAnimationFrame(() => card.classList.add("visible"));
    if (!sticky) setTimeout(dismiss, AUTO_DISMISS_MS);
}

/* ==========================================================================
 * CATCH-ALL — any DRPG whisper reaching a non-GM player becomes a popup too
 * ========================================================================== */

export function registerPopups() {
    Hooks.on("createChatMessage", onCreateChatMessage);
}

/**
 * Every module message surfaces in the middle of the screen, for everybody it
 * was addressed to — GMs included.
 *
 * The old rule was "players only, whispers only". That left the GM reading a
 * sidebar for the half of this module that talks to them exclusively — every
 * ruling request, every Remnant placed, every Despair Call receipt, the entire
 * murder engine's commentary — while the players got cards. During an incident
 * the chat log is the last place anyone is looking.
 *
 * "Ours" is decided by the marker `utils.mjs` stamps on the three helpers every
 * module message goes through, not by sniffing the content: half of these are a
 * bare heading and a paragraph with nothing to recognise them by.
 */
function onCreateChatMessage(message) {
    if (!message.getFlag(MODULE_ID, MESSAGE_FLAG)) return;

    // Surfaces that already present themselves, and must not be shown twice.
    //
    //   the messenger  raises its own card, or appends to an open window
    //   `popupKind: "none"`  the poster is calling `showPopup` itself, with a
    //                        richer card than this generic one — the Class
    //                        Trial's sticky evidence card is the case in point
    if (message.getFlag(MODULE_ID, MESSENGER_FLAGS.thread)) return;
    const kind = message.getFlag(MODULE_ID, "popupKind") ?? "info";
    if (kind === "none") return;

    // A genuine dice roll should animate and show in chat normally, not get
    // swallowed into a popup card.
    if ((message.rolls?.length ?? 0) > 0) return;

    // A whisper reaches the people it names. A public announcement reaches
    // everyone, which is what makes it an announcement.
    const whisper = message.whisper ?? [];
    if (whisper.length && !whisper.includes(game.user.id)) return;

    showPopup(message.content, { kind });
}
