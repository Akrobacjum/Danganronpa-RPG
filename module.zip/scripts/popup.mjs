/**
 * Danganronpa RPG — the one popup every player-facing message uses.
 * ---------------------------------------------------------------------------
 * Search, Work on Project, Sabotage, a refused room crossing, a DM's reply —
 * all of it used to be a whisper the player had to notice sitting in the
 * sidebar. This is where all of it surfaces instead: a floating card, purple
 * for an ordinary update, red for something that was refused. GMs keep the
 * chat log as their paper trail (see the callers below); this is what the
 * player sees instead of having to go looking for it.
 *
 * Two ways something ends up here:
 *   showPopup()              called directly — the shared report() in
 *                            action-rolls.mjs, and the messenger.
 *   the createChatMessage    any DRPG-flagged whisper that reaches a non-GM
 *   catch-all hook           player, tagged "error" only if the sender said
 *                            so (see utils.mjs's whisperToOwner `extra`
 *                            parameter and its "popupKind" flag).
 */

import { MODULE_ID } from "./config.mjs";
import { MESSENGER_FLAGS } from "./messenger.mjs";

const CONTAINER_ID = "drpg-popups";
const AUTO_DISMISS_MS = 7000;

function container() {
    let el = document.getElementById(CONTAINER_ID);
    if (!el) {
        el = document.createElement("div");
        el.id = CONTAINER_ID;
        document.body.append(el);
    }
    return el;
}

/**
 * Show a floating, auto-dismissing card on THIS client. Several can stack if
 * things happen close together.
 *
 * @param {string} bodyHtml       Already-escaped HTML.
 * @param {object} [options]
 * @param {string} [options.title]     Shown in a header bar. Omitted entirely
 *   when there is none — most whispers were never built with a clean title to
 *   pull out of them, and a generic placeholder label helps nobody.
 * @param {"info"|"error"} [options.kind]  info = purple border (default),
 *   error = red — the same layout, only the accent changes.
 * @param {() => void} [options.onClick]   Extra action on click, before the
 *   card dismisses. Used to jump straight to the messenger for a DM reply.
 */
export function showPopup(bodyHtml, { title = null, kind = "info", onClick = null } = {}) {
    const card = document.createElement("div");
    card.className = `drpg-popup drpg-popup-${kind === "error" ? "error" : "info"}`;

    if (title) {
        const head = document.createElement("div");
        head.className = "drpg-popup-title";
        head.textContent = title;

        const close = document.createElement("button");
        close.type = "button";
        close.className = "drpg-popup-close";
        close.innerHTML = `<i class="fa-solid fa-xmark" inert></i>`;
        close.setAttribute("aria-label", game.i18n.localize("DRPG.Panel.close"));
        head.append(close);
        close.addEventListener("click", event => {
            event.preventDefault();
            event.stopPropagation();
            dismiss();
        });

        card.append(head);
    }

    const body = document.createElement("div");
    body.className = "drpg-popup-body";
    body.innerHTML = bodyHtml ?? "";
    card.append(body);

    container().append(card);

    let dismissed = false;
    const dismiss = () => {
        if (dismissed) return;
        dismissed = true;
        card.classList.add("leaving");
        setTimeout(() => card.remove(), 300);
    };

    card.addEventListener("click", () => {
        onClick?.();
        dismiss();
    });

    requestAnimationFrame(() => card.classList.add("visible"));
    setTimeout(dismiss, AUTO_DISMISS_MS);
}

/* ==========================================================================
 * CATCH-ALL — any DRPG whisper reaching a non-GM player becomes a popup too
 * ========================================================================== */

export function registerPopups() {
    Hooks.on("createChatMessage", onCreateChatMessage);
}

function onCreateChatMessage(message) {
    if (game.user.isGM) return; // GMs keep the sidebar as their paper trail

    // The messenger has its own popup path (see messenger-app.mjs) — a DM
    // reply should not also fire this generic one.
    if (message.getFlag(MODULE_ID, MESSENGER_FLAGS.thread)) return;

    const whisper = message.whisper ?? [];
    if (!whisper.includes(game.user.id)) return;

    const authorId = message.author?.id ?? message.user?.id;
    if (authorId === game.user.id) return; // never popup your own message

    // A genuine dice roll should animate and show in chat normally, not get
    // swallowed into a popup card.
    if ((message.rolls?.length ?? 0) > 0) return;

    const kind = message.getFlag(MODULE_ID, "popupKind") ?? "info";
    showPopup(message.content, { kind });
}
