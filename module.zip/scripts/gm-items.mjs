/**
 * Danganronpa RPG — the GM hands things out, and takes them away.
 * ---------------------------------------------------------------------------
 * Search puts items into an inventory on its own, but plenty of things arrive
 * by other routes: a project that produced a tool, a reward, a Truth Bullet the
 * GM is issuing for a Remnant somebody Observed, or a crime tool being confiscated
 * after the trial. All of those were console work before this.
 *
 * Truth Bullets matter most here. They are the one category nothing in the module
 * creates automatically, so until the investigation loop exists this dialog is
 * how evidence reaches a player's sheet — and it writes the same category flag
 * the sheet groups on, which is exactly what the old hand-rolled macro did not.
 */

import { MODULE_ID, ITEM_CATEGORIES, ITEM_TIERS, TIER_EFFECTS } from "./config.mjs";
import { grantItem, itemsInCategory, countInCategory, inventorySummary } from "./inventory.mjs";
import { ITEM_POOLS } from "./tables.mjs";
import { studentActors } from "./monokuma.mjs";
import { whisperToOwner, dialogContent, log, error } from "./utils.mjs";

const DialogV2 = foundry.applications.api.DialogV2;

/* ==========================================================================
 * ENTRY POINT
 * ========================================================================== */

/**
 * Open the item manager. GM only.
 *
 * @param {Actor} [actor]  Skip the character picker when the caller knows who.
 */
export async function openItemManager(actor = null) {
    if (!game.user.isGM) {
        ui.notifications.warn(game.i18n.localize("DRPG.Panel.gmOnly"));
        return null;
    }

    const target = actor ?? await pickCharacter();
    if (!target) return null;

    const choice = await DialogV2.wait({
        window: { title: game.i18n.format("DRPG.Items.title", { actor: target.name }) },
        classes: ["drpg-panel"],
        content: `<div>
            <p><strong>${foundry.utils.escapeHTML(target.name)}</strong></p>
            <p class="notes">${foundry.utils.escapeHTML(inventorySummary(target))}</p>
        </div>`,
        buttons: [
            { action: "give", label: game.i18n.localize("DRPG.Items.give"), default: true },
            { action: "take", label: game.i18n.localize("DRPG.Items.take") },
            { action: "cancel", label: game.i18n.localize("DRPG.Panel.close") }
        ],
        rejectClose: false
    });

    if (choice === "give") {
        const made = await giveItemDialog(target);
        // Straight back to the manager, so handing over three things is three
        // clicks rather than three trips through the menu.
        return made ? openItemManager(target) : null;
    }
    if (choice === "take") {
        const taken = await takeItemDialog(target);
        return taken ? openItemManager(target) : null;
    }
    return null;
}

/** Which student. Monokumas are excluded — they carry nothing. */
async function pickCharacter() {
    const actors = studentActors();
    if (!actors.length) {
        ui.notifications.warn(game.i18n.localize("DRPG.Panel.noCharacters"));
        return null;
    }

    const options = actors
        .map(a => `<option value="${a.id}">${foundry.utils.escapeHTML(a.name)} — ${
            foundry.utils.escapeHTML(inventorySummary(a))
        }</option>`)
        .join("");

    const id = await DialogV2.wait({
        window: { title: game.i18n.localize("DRPG.Items.whichCharacter") },
        classes: ["drpg-panel"],
        content: `<form><label>${game.i18n.localize("DRPG.Items.whichCharacter")}
                    <select name="actor">${options}</select></label></form>`,
        buttons: [
            {
                action: "ok", label: game.i18n.localize("DRPG.Action.proceed"), default: true,
                callback: (e, b, d) => d.element.querySelector("[name=actor]").value
            },
            { action: "cancel", label: game.i18n.localize("DRPG.Advance.cancel") }
        ],
        rejectClose: false
    });

    if (!id || id === "cancel") return null;
    return game.actors.get(id) ?? null;
}

/* ==========================================================================
 * GIVING
 * ========================================================================== */

/**
 * Hand over one item.
 *
 * The carry limit is shown rather than silently enforced: a GM putting something
 * on a sheet is making a ruling, and being told "Crime Tools 1/1" is more useful
 * than being refused. Going over the cap is deliberate and flagged.
 */
async function giveItemDialog(actor) {
    const categories = Object.entries(ITEM_CATEGORIES).map(([key, cat]) => {
        const held = countInCategory(actor, key);
        const cap = cat.limit ? ` — ${held}/${cat.limit}` : ` — ${held}`;
        return `<option value="${key}">${foundry.utils.escapeHTML(cat.label)}${cap}</option>`;
    }).join("");

    const tiers = ITEM_TIERS
        .map(t => `<option value="${t}"${t === 2 ? " selected" : ""}>${
            game.i18n.format("DRPG.Items.tierN", { n: t })
        }</option>`).join("");

    // Every built-in name, offered as autocomplete. The GM can type anything.
    const suggestions = Array.from(new Set(
        Object.values(ITEM_POOLS).flatMap(byTier => Object.values(byTier).flat())
    )).sort();

    const result = await DialogV2.wait({
        window: { title: game.i18n.format("DRPG.Items.giveTo", { actor: actor.name }) },
        classes: ["drpg-panel"],
        content: dialogContent(`<form>
            <label>${game.i18n.localize("DRPG.Items.category")}
                <select name="category">${categories}</select></label>
            <label>${game.i18n.localize("DRPG.Items.tier")}
                <select name="tier">${tiers}</select></label>
            <label>${game.i18n.localize("DRPG.Items.name")}
                <input type="text" name="name" list="drpg-item-names" autofocus
                       placeholder="${game.i18n.localize("DRPG.Items.namePlaceholder")}" /></label>
            <datalist id="drpg-item-names">${
                suggestions.map(n => `<option value="${foundry.utils.escapeHTML(n)}"></option>`).join("")
            }</datalist>
            <label>${game.i18n.localize("DRPG.Items.description")}
                <textarea name="description" rows="2"
                    placeholder="${game.i18n.localize("DRPG.Items.descriptionPlaceholder")}"></textarea></label>
            <label class="drpg-checkbox">
                <input type="checkbox" name="tell" checked />
                ${game.i18n.localize("DRPG.Items.tellPlayer")}</label>
            <p class="notes">${game.i18n.localize("DRPG.Items.overCapNote")}</p>
        </form>`),
        buttons: [
            {
                action: "ok", label: game.i18n.localize("DRPG.Items.give"), default: true,
                callback: (e, b, d) => {
                    const f = d.element.querySelector("form");
                    return {
                        category: f.category.value,
                        tier: Number(f.tier.value),
                        name: f.name.value.trim(),
                        description: f.description.value.trim(),
                        tell: f.tell.checked
                    };
                }
            },
            { action: "cancel", label: game.i18n.localize("DRPG.Advance.cancel") }
        ],
        rejectClose: false
    });

    if (!result || result === "cancel") return false;
    if (!result.name) {
        ui.notifications.warn(game.i18n.localize("DRPG.Items.needsName"));
        return false;
    }

    const item = await grantItem(actor, {
        name: result.name,
        category: result.category,
        tier: result.tier,
        description: result.description
            ? `<p>${foundry.utils.escapeHTML(result.description)}</p>`
            : "",
        // A GM handing something over outranks the carry limit.
        override: true
    });

    if (!item) {
        ui.notifications.error(game.i18n.localize("DRPG.Items.failed"));
        return false;
    }

    log(`GM gave ${actor.name} "${result.name}" (${result.category}, Tier ${result.tier}).`);
    ui.notifications.info(game.i18n.format("DRPG.Items.gave", {
        item: result.name, actor: actor.name
    }));

    if (result.tell) {
        const effect = TIER_EFFECTS[result.category]?.[result.tier] ?? "";
        await whisperToOwner(actor, `
            <h3>${game.i18n.localize("DRPG.Items.received")}</h3>
            <p><strong>${foundry.utils.escapeHTML(result.name)}</strong> — ${
                foundry.utils.escapeHTML(ITEM_CATEGORIES[result.category]?.label ?? result.category)
            }, ${game.i18n.format("DRPG.Items.tierN", { n: result.tier })}</p>
            ${result.description ? `<p>${foundry.utils.escapeHTML(result.description)}</p>` : ""}
            ${effect ? `<p><em>${foundry.utils.escapeHTML(effect)}</em></p>` : ""}`);
    }

    return true;
}

/* ==========================================================================
 * TAKING AWAY
 * ========================================================================== */

/** Remove one item the module knows about. */
async function takeItemDialog(actor) {
    const owned = Object.keys(ITEM_CATEGORIES)
        .flatMap(key => itemsInCategory(actor, key).map(item => ({ item, category: key })));

    if (!owned.length) {
        ui.notifications.warn(game.i18n.format("DRPG.Items.nothingToTake", { actor: actor.name }));
        return false;
    }

    const options = owned.map(({ item, category }) => {
        const tier = item.getFlag(MODULE_ID, "tier");
        const label = `${ITEM_CATEGORIES[category]?.label ?? category} · ${item.name}${
            tier !== undefined ? ` (T${tier})` : ""
        }`;
        return `<option value="${item.id}">${foundry.utils.escapeHTML(label)}</option>`;
    }).join("");

    const result = await DialogV2.wait({
        window: { title: game.i18n.format("DRPG.Items.takeFrom", { actor: actor.name }) },
        classes: ["drpg-panel"],
        content: `<form>
            <label>${game.i18n.localize("DRPG.Items.whichItem")}
                <select name="item">${options}</select></label>
            <label class="drpg-checkbox">
                <input type="checkbox" name="tell" checked />
                ${game.i18n.localize("DRPG.Items.tellPlayer")}</label>
        </form>`,
        buttons: [
            {
                action: "ok", label: game.i18n.localize("DRPG.Items.take"), default: true,
                callback: (e, b, d) => {
                    const f = d.element.querySelector("form");
                    return { id: f.item.value, tell: f.tell.checked };
                }
            },
            { action: "cancel", label: game.i18n.localize("DRPG.Advance.cancel") }
        ],
        rejectClose: false
    });

    if (!result || result === "cancel") return false;

    const item = actor.items.get(result.id);
    if (!item) return false;

    const name = item.name;
    try {
        await item.delete();
    } catch (err) {
        error("Could not remove the item", err);
        ui.notifications.error(game.i18n.localize("DRPG.Items.failed"));
        return false;
    }

    log(`GM took "${name}" from ${actor.name}.`);
    ui.notifications.info(game.i18n.format("DRPG.Items.took", { item: name, actor: actor.name }));

    if (result.tell) {
        await whisperToOwner(actor, `<p><strong>${game.i18n.localize("DRPG.Items.lostTitle")}</strong> — ${
            game.i18n.format("DRPG.Items.lost", { item: foundry.utils.escapeHTML(name) })
        }</p>`);
    }

    return true;
}
