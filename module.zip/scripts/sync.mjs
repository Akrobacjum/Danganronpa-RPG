/**
 * Danganronpa RPG — telling every client what just happened.
 * ---------------------------------------------------------------------------
 * World settings synchronise by themselves: a GM writes, and every client's copy
 * updates. What does NOT travel is the work that follows the write — redrawing
 * the HUD, dimming the canvas for an Eclipse, recomputing who can see whose
 * token, re-rendering open sheets.
 *
 * That work was being driven by `Hooks.callAll(...)` immediately after the
 * write, which runs on the writer's client and nowhere else. On one machine
 * with a GM window and a player window it looked fine, because both windows
 * were the same browser and the settings `onChange` covered the gap. On a real
 * server it was not fine: the clock advanced for the GM alone.
 *
 * So every world-state change is announced here, on the module's own socket, and
 * every client — the sender included — reacts identically. One code path, no
 * "works on my machine".
 */

import { MODULE_ID } from "./config.mjs";
import { debug, error } from "./utils.mjs";

const SOCKET_EVENT = `module.${MODULE_ID}`;
const ACTION = "sync";

/** What can be announced. Add a kind here and a handler in `apply`. */
export const SYNC = {
    /** The clock moved: time of day, day, session, chapter, phase. */
    clock: "clock",
    /** An Eclipse started or ended. */
    eclipse: "eclipse",
    /** Room occupancy changed enough to redraw who sees whom. */
    visibility: "visibility",
    /** A project was created, advanced, frozen or made secret. */
    projects: "projects",
    /** A Despair pool changed. */
    despair: "despair",
    /** Search tokens were spent or restocked. */
    searchTokens: "searchTokens",
    /** A room was sealed or unsealed, or a player silenced or chained. */
    restrictions: "restrictions"
};

/**
 * Which world setting, when it changes, means which refresh.
 *
 * The socket is the fast path, but it is not the *reliable* one: it needs
 * `registerSync()` to have run on the receiving client, the module's socket to
 * be up, and the sender to still be connected. A world setting needs none of
 * that. Foundry syncs the Setting document to every client and calls the
 * registered `onChange` there, so keying the refresh off the setting itself is
 * the path that cannot be missed — see settings.mjs, which routes every one of
 * these through `applyFor()`.
 */
const SETTING_KINDS = {
    clock: SYNC.clock,
    sealedRooms: SYNC.restrictions,
    restrictions: SYNC.restrictions,
    eclipseMoves: SYNC.visibility,
    despairPools: SYNC.despair,
    searchTokens: SYNC.searchTokens,
    projectMeta: SYNC.projects
};

export function registerSync() {
    game.socket.on(SOCKET_EVENT, payload => {
        if (payload?.action !== ACTION) return;
        apply(payload.kind, payload.data);
    });
}

/**
 * Refresh in response to a world setting changing. Called from the settings'
 * own `onChange`, which Foundry runs on every client that receives the update.
 */
export function applyFor(settingKey, data = {}) {
    const kind = SETTING_KINDS[settingKey];
    if (!kind) return;
    apply(kind, data);
}

/**
 * Announce a change to every client, and apply it here.
 *
 * Safe to call from any client. The local half runs regardless of who is
 * connected, so a single-GM world behaves the same as a full table.
 */
export function broadcast(kind, data = {}) {
    try {
        game.socket.emit(SOCKET_EVENT, { action: ACTION, kind, data });
    } catch (err) {
        error(`Could not broadcast "${kind}"`, err);
    }
    apply(kind, data);
}

/**
 * React to a change, wherever it came from.
 *
 * Every branch is defensive: a client that cannot do one part of the refresh —
 * no canvas yet, a sheet mid-render — must still do the rest.
 *
 * The socket announcement and the setting's own `onChange` describe the same
 * event, and on a healthy connection both arrive. Doing the work twice is
 * wasteful — re-rendering every open sheet is not cheap — so events arriving
 * inside a short window are merged.
 *
 * Merged, NOT discarded. This used to return early and throw the second event
 * away, which is only safe when the two describe the same state. They often do
 * not: a Despair Call spends and then refunds within a few milliseconds, and
 * clearing the seals writes two settings back to back. In both cases the screen
 * was left showing the state *before* the final write, with no further event
 * coming to correct it. The trailing run below always applies the newest data.
 */
const lastRun = new Map();
const queued = new Map();
const COALESCE_MS = 120;

function apply(kind, data = {}) {
    const now = Date.now();
    const since = now - (lastRun.get(kind) ?? 0);

    if (since < COALESCE_MS) {
        const alreadyQueued = queued.has(kind);
        queued.set(kind, data);                 // newest state wins
        if (alreadyQueued) return;

        debug(`sync: ${kind} deferred`);
        setTimeout(() => {
            const pending = queued.get(kind) ?? {};
            queued.delete(kind);
            lastRun.set(kind, Date.now());
            refresh(kind, pending);
        }, COALESCE_MS - since);
        return;
    }

    lastRun.set(kind, now);
    refresh(kind, data);
}

function refresh(kind, data = {}) {
    debug(`sync: ${kind}`, data);

    const run = (label, fn) => {
        try {
            const result = fn();
            if (result?.catch) result.catch(err => error(`sync ${kind}/${label} failed`, err));
        } catch (err) {
            error(`sync ${kind}/${label} failed`, err);
        }
    };

    switch (kind) {
        case SYNC.clock:
            run("hud", () => import("./hud.mjs").then(m => m.renderHud()));
            run("sheets", () => import("./clock.mjs").then(m => m.refreshSheets()));
            run("eclipse", () => import("./eclipse.mjs").then(m => m.refreshEclipse()));
            run("visibility", () => import("./visibility.mjs").then(m => m.applyAll()));
            // Local listeners (other modules, macros) still get their hook — but
            // now they get it on every client, which is what they always meant.
            //
            // The clock is read back from the setting when the announcement did
            // not carry one: this path is also reached from the setting's own
            // `onChange`, which knows the value changed but not what was in the
            // socket payload. A listener must never be handed an empty object.
            run("hook", async () => {
                const { getClock } = await import("./clock.mjs");
                Hooks.callAll("drpgTimeOfDayChanged", data.clock ?? getClock(), data.summary ?? {});
            });
            break;

        case SYNC.eclipse:
            run("eclipse", () => import("./eclipse.mjs").then(m => m.refreshEclipse()));
            run("hud", () => import("./hud.mjs").then(m => m.renderHud()));
            run("visibility", () => import("./visibility.mjs").then(m => m.applyAll()));
            run("hook", async () => {
                const { isEclipse } = await import("./eclipse.mjs");
                Hooks.callAll("drpgEclipseChanged", data.active ?? isEclipse());
            });
            break;

        case SYNC.visibility:
            run("visibility", () => import("./visibility.mjs").then(m => m.applyAll()));
            break;

        case SYNC.projects:
            run("tray", () => import("./projects-ui.mjs").then(m => m.refreshProjects?.()));
            run("sheets", () => import("./clock.mjs").then(m => m.refreshSheets()));
            break;

        case SYNC.despair:
            run("bar", () => import("./despair.mjs").then(m => m.renderDespairBar?.()));
            run("sheets", () => import("./clock.mjs").then(m => m.refreshSheets()));
            break;

        case SYNC.searchTokens:
            // The world setting has just landed, so it is authoritative again —
            // drop the player-side "GM just told me" cache rather than let it
            // outlive the value it was standing in for.
            run("cache", () => import("./search-tokens.mjs").then(m => m.SearchTokens.clearFreshCounts()));
            run("sheets", () => import("./clock.mjs").then(m => m.refreshSheets()));
            break;

        case SYNC.restrictions:
            run("sheets", () => import("./clock.mjs").then(m => m.refreshSheets()));
            break;

        default:
            debug(`sync: unknown kind "${kind}" ignored`);
    }
}
