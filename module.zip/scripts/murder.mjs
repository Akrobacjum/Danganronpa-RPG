/**
 * Danganronpa RPG — the murder engine.
 * ---------------------------------------------------------------------------
 * Guide, pp. 17–27. The murder is the one part of this game the rules treat as
 * exceptional, and it is the only place where two players roll against each
 * other turn by turn.
 *
 * The shape of it:
 *
 *   Stage 4  two opening rolls. The killer's decides whether the incident
 *            happens at all and HOW MANY Key Remnants it leaves — the better
 *            the roll, the fewer clues. The victim's decides whether they
 *            sense it coming.
 *   Stage 5  the incident. The victim always moves first, and every turn costs
 *            them Stress until it runs out and then HP. Both sides pick crisis
 *            actions; a third party who walks in gets a free one.
 *   Stage 6  resolution. The killer cleans up — and now, for the first time,
 *            can see the Remnants they left.
 *
 * WHAT IS AUTOMATED AND WHAT IS NOT. The module owns the numbers: thresholds,
 * the drain, turn order, damage, which Remnants each outcome leaves, who is
 * hindered and for how long. It does not own the prose. "The victim takes
 * something of the killer's and makes evidence of it" is a sentence a person
 * finishes, so each outcome's text goes to the GM and the table rather than
 * being invented here.
 *
 * WHY THE STATE IS WORLD-SCOPED. Unlike the Truth Bullet ledger, this is not
 * secret-by-design. Both participants need to see whose turn it is, what the
 * victim has left and which of their own actions are blocked — live, every
 * turn. See the note on SETTINGS.murderState for the trade that was made.
 */

import {
    MODULE_ID, FLAGS, MURDER_OPENING, INCIDENT, CRISIS_ACTIONS, KEY_REMNANTS,
    RESOLUTION_STRESS_COST
} from "./config.mjs";
import { isMonokuma } from "./monokuma.mjs";
import { SETTINGS } from "./settings.mjs";
import { getClock } from "./clock.mjs";
import { resourceValue, resourceMax } from "./character.mjs";
import { automatedUpdate } from "./resource-guard.mjs";
import { carriedInCategory, ITEM_FLAGS } from "./inventory.mjs";
import { isEquipped } from "./use-items.mjs";
import { dropRemnant } from "./remnants.mjs";
import { dialogContent, whisperToGms, whisperToOwner, isPrimaryGm, log, error } from "./utils.mjs";

const DialogV2 = foundry.applications.api.DialogV2;

/* ==========================================================================
 * STATE
 * ========================================================================== */

/** The murder in progress, or `null`. */
export function murderState() {
    const stored = game.settings.get(MODULE_ID, SETTINGS.murderState) ?? {};
    return stored.active ? stored : null;
}

async function writeState(patch) {
    if (!game.user.isGM) return null;
    const next = { ...(game.settings.get(MODULE_ID, SETTINGS.murderState) ?? {}), ...patch };
    await game.settings.set(MODULE_ID, SETTINGS.murderState, next);
    return next;
}

/** Which side is this actor on, if any: "killer" | "victim" | "third" | null. */
export function sideOf(actor) {
    const state = murderState();
    if (!state || !actor) return null;
    if (state.killerId === actor.id) return "killer";
    if (state.victimId === actor.id) return "victim";
    if (state.thirdId === actor.id) return "third";
    return null;
}

/**
 * Is it this actor's turn to act?
 *
 * A third party is deliberately outside the turn order. The guide gives
 * whoever walks in on an incident ONE free action, and "free" here means
 * exactly that: it does not wait for a turn and it does not consume one. Since
 * `turnSide` only ever holds "victim" or "killer", asking whether it equals
 * "third" is always false — which meant the third party was told they had a
 * free action and then refused with "not your turn" every time they tried to
 * use it. They may act while they still have that action, and not after.
 */
export function isTheirTurn(actor) {
    const state = murderState();
    if (!state || state.stage !== "incident") return false;
    const side = sideOf(actor);
    if (side === "third") return !state.thirdActed;
    return state.turnSide === side;
}

/** Crisis actions this actor may take right now, with their hindered flags. */
export function availableCrisisActions(actor) {
    const state = murderState();
    const side = sideOf(actor);
    if (!state || state.stage !== "incident" || !side) return [];

    const hindered = state.hindered?.[side] ?? {};
    const blocked = state.blocked?.[side] ?? {};
    const unlocked = new Set(state.unlocked ?? []);
    const spent = new Set(state.spent ?? []);

    return Object.entries(CRISIS_ACTIONS)
        .filter(([, def]) => def.side === side)
        // The guide takes Role Reversal away from a victim whose killer opened
        // on a Despair success.
        .filter(([key]) => !(state.deniedToVictim ?? []).includes(key))
        .map(([key, def]) => {
            const locked = Boolean(def.lockedUntil && !unlocked.has(key));
            return {
                key,
                def,
                hindered: (hindered[key] ?? 0) > 0,
                // Self-defence gates the victim's two ways out, and closes
                // itself once it lands. `blocked` already means "you may not
                // press this", so both reasons fold into it — and each carries
                // its own explanation for the tooltip.
                blocked: (blocked[key] ?? 0) > 0 || locked || spent.has(key),
                locked,
                spent: spent.has(key),
                lockedBy: def.lockedUntil ? CRISIS_ACTIONS[def.lockedUntil]?.label ?? null : null
            };
        });
}

/* ==========================================================================
 * STAGE 4 — THE OPENING
 * ========================================================================== */

/** Is it night? The killer's roll wants to know, and so does the victim's. */
function atNight() {
    const t = getClock().timeOfDay;
    return t === "night" || t === "Night";
}

/**
 * Open a murder. GM-driven: the declaration and the consent happened away from
 * the table, and this is the moment they become mechanical.
 */
export async function openMurder({ killerId, victimId, indirect = false } = {}) {
    if (!game.user.isGM) return null;

    const killer = game.actors.get(killerId);
    const victim = game.actors.get(victimId);
    if (!killer || !victim || killer.id === victim.id) return null;

    await writeState({
        active: true,
        stage: "openingRoll",
        indirect,
        killerId, victimId, thirdId: null,
        turn: 0,
        turnSide: "victim",
        keyRemnants: KEY_REMNANTS.prepared,
        deniedToVictim: [],
        hindered: { victim: {}, killer: {} },
        blocked: { victim: {}, killer: {} },
        // Survive and Role reversal start closed; Self-defence opens them.
        unlocked: [],
        // A critical Self-defence stops the drain for the rest of the incident.
        drainStopped: false,
        advantageNext: { victim: false, killer: false },
        openedAt: Date.now()
    });

    await whisperToGms(`
        <h3>${game.i18n.localize("DRPG.Murder.openedTitle")}</h3>
        <p>${game.i18n.format("DRPG.Murder.opened", {
            killer: foundry.utils.escapeHTML(killer.name),
            victim: foundry.utils.escapeHTML(victim.name)
        })}</p>
        <p>${game.i18n.localize(atNight()
            ? "DRPG.Murder.nightNote" : "DRPG.Murder.dayNote")}</p>`);

    log(`Murder opened: ${killer.name} → ${victim.name}${indirect ? " (indirect)" : ""}.`);
    return murderState();
}

/**
 * Record the killer's opening roll.
 *
 * The Key Remnant count comes straight off the duality: Hope leaves the most
 * evidence, a critical the least. Floored at the guide's minimum so a case can
 * never become unsolvable by a good roll.
 */
export async function resolveKillerOpening({ total, isCritical, withHope }) {
    if (!game.user.isGM) return null;
    const state = murderState();
    if (!state) return null;

    const def = MURDER_OPENING.killer;
    const success = isCritical || total >= def.threshold;

    if (!success) {
        await tellGms(def.failure);
        await endMurder({ reason: "openingFailed" });
        return { success: false };
    }

    const band = isCritical ? "critical" : (withHope ? "hope" : "despair");
    const keys = Math.max(KEY_REMNANTS.minimum, def.keyRemnants[band]);

    const patch = { stage: "incident", keyRemnants: keys, turn: 1, turnSide: "victim" };

    // A Despair success costs the victim their Stress and their way out.
    if (band === "despair") {
        const victim = game.actors.get(state.victimId);
        if (victim) {
            await automatedUpdate(victim, {
                "system.resources.stress.value": resourceMax(victim, "stress")
            });
        }
        patch.deniedToVictim = ["roleReversal"];
    }

    await writeState(patch);
    await tellGms(def[band], { keys });
    return { success: true, band, keys };
}

/**
 * Record the victim's opening roll.
 *
 * This is the WHOLE of Stage 4 for an indirect murder. There is no confrontation
 * to open — the trap is already set, and the only question the guide asks is
 * whether the victim sees it coming:
 *
 *   success   they get a free Move and a bad feeling, or (on Despair) see
 *             through the plan outright. No incident.
 *   failure   "Śmierć ofiary" — the trap closes, and the incident begins with
 *             the victim alone, draining 2 a turn (INCIDENT.drain.indirect).
 *
 * For a direct murder nothing here starts anything: the killer's roll already
 * did, and this is only the victim's chance to sense it.
 */
export async function resolveVictimOpening({ total, isCritical, withHope }) {
    if (!game.user.isGM) return null;
    const state = murderState();
    if (!state) return null;

    const def = MURDER_OPENING.victim;
    const success = isCritical || total >= def.threshold;

    if (!success) {
        await tellGms(def.failure);

        // An indirect murder has no killer's roll to open it, so this is the
        // moment the incident starts. Without this the state sat on
        // "openingRoll" for ever and an indirect murder could never be played.
        if (state.indirect) {
            await writeState({ stage: "incident", turn: 1, turnSide: "victim" });
            await whisperToGms(`<p>${game.i18n.localize("DRPG.Murder.indirectBegins")}</p>`);
            return { success: false, started: true };
        }
        return { success: false };
    }

    const band = isCritical ? "critical" : (withHope ? "hope" : "despair");
    await tellGms(def[band]);

    // The victim sensing it coming does not end the incident by itself — the
    // guide gives them a free Move and lets them use it or not. Ending it is
    // the GM's call, which is why this reports rather than decides.
    return { success: true, band };
}

/* ==========================================================================
 * STAGE 5 — THE INCIDENT
 * ========================================================================== */

/**
 * Take one crisis action, roll it, and apply everything mechanical about it.
 *
 * Called from the actor's own client — it is their roll — but every world write
 * it produces goes through the GM, same as the rest of the module.
 */
export async function takeCrisisAction(actor, key) {
    const state = murderState();
    const side = sideOf(actor);
    const def = CRISIS_ACTIONS[key];

    if (!state || state.stage !== "incident" || !def || def.side !== side) return null;
    if (!isTheirTurn(actor)) {
        ui.notifications.warn(game.i18n.localize("DRPG.Murder.notYourTurn"));
        return null;
    }
    // The sheet greys these out, but the panel is only rebuilt on render — a
    // window left open across somebody else's turn still has live buttons.
    const offered = availableCrisisActions(actor).find(o => o.key === key);
    if (offered?.locked) {
        ui.notifications.warn(game.i18n.format("DRPG.Murder.actionLocked", {
            name: offered.lockedBy ?? "?"
        }));
        return null;
    }
    if (offered?.spent) {
        ui.notifications.warn(game.i18n.localize("DRPG.Murder.actionSpent"));
        return null;
    }
    if ((state.blocked?.[side]?.[key] ?? 0) > 0) {
        ui.notifications.warn(game.i18n.localize("DRPG.Murder.actionBlocked"));
        return null;
    }
    // A resolution action costs Stress rather than an action, and needs some.
    if (def.kind === "resolution" && resourceValue(actor, "stress") >= resourceMax(actor, "stress")) {
        ui.notifications.warn(game.i18n.localize("DRPG.Murder.noStressLeft"));
        return null;
    }

    const { rollTrait } = await import("./action-rolls.mjs");
    const calls = await import("./call-effects.mjs");

    // Advantage and disadvantage that belong to the situation rather than to a
    // Call: a hindered action, a weapon in hand, a second try after a miss.
    let situational = 0;
    if ((state.hindered?.[side]?.[key] ?? 0) > 0) situational -= 1;
    if (state.advantageNext?.[side]) situational += 1;
    if (def.weaponAdvantage && hasWeapon(actor)) situational += 1;
    if (def.unarmedDisadvantage && !hasWeapon(actor)) situational -= 1;

    const trait = def.traits?.[0] ?? "body";
    if (situational) calls.armSituational(situational);

    let roll;
    try {
        roll = await rollTrait(actor, trait, { actionKey: "crisis", context: { crisis: key } });
    } finally {
        calls.clearSituational();
    }
    if (!roll) return null;

    const { requestCrisisResult } = await import("./gm-bridge.mjs");
    await requestCrisisResult({
        actorId: actor.id, key,
        total: roll.total,
        isCritical: Boolean(roll.isCritical),
        withHope: Boolean(roll.withHope)
    });

    return { roll };
}

/**
 * Anything they could swing.
 *
 * Carried only — a crowbar in the stash back in your bedroom is not in your
 * hand at the crime scene. `carriedInCategory` is the same filter the carry
 * limits use.
 */
function weaponsOf(actor) {
    // Through the shared helpers, not through flag names spelled out here.
    // `carriedInCategory` already means "this category, and not in the stash",
    // and `isEquipped` owns the spelling of the equipped flag — a literal
    // "equipped" here would have kept compiling and silently stopped matching
    // the day that constant moved.
    const carried = carriedInCategory(actor, "crimeTool");
    const equipped = carried.find(isEquipped);
    return equipped ? [equipped] : carried;
}

function hasWeapon(actor) {
    return weaponsOf(actor).length > 0;
}

/**
 * The weapon this attack swings, and the tier it counts as.
 *
 * Two things the old `bestWeaponTier` could not express, both from the guide's
 * own Attack-with-a-weapon row:
 *
 *   "Przedmiot tieru 0 jest negocjowalny jako tier 1 lub 2 w ramach
 *    kreatywności zabójcy."
 *      A Tier 0 item is "a random, seemingly useless object". Whether swinging
 *      a stapler is worth anything is a ruling, so the GM is asked for one
 *      instead of the formula quietly returning 1 damage and nobody noticing
 *      that a whole rule never fired.
 *
 *   Highest tier is not automatically the right weapon either — an equipped one
 *      wins, because the killer said which they meant. See `weaponsOf`.
 *
 * @returns {Promise<{item: Item|null, tier: number}>}
 */
async function chooseWeapon(actor) {
    const carried = weaponsOf(actor);
    if (!carried.length) return { item: null, tier: 0 };

    const tierOf = item => item.getFlag(MODULE_ID, ITEM_FLAGS.tier) ?? 0;
    const best = carried.reduce((a, b) => (tierOf(b) > tierOf(a) ? b : a));
    const tier = tierOf(best);

    const rule = CRISIS_ACTIONS.weaponAttack.tierZeroNegotiable;
    if (tier !== 0 || !rule?.prompt) return { item: best, tier };

    const rated = await rateTierZero(actor, best, rule);
    return { item: best, tier: rated };
}

/** The GM prices one Tier 0 object for this particular swing. */
async function rateTierZero(actor, item, rule) {
    const options = [];
    for (let t = rule.min; t <= rule.max; t++) {
        options.push(`<option value="${t}"${t === 0 ? " selected" : ""}>${
            game.i18n.format("DRPG.Murder.asTier", { n: t })
        }</option>`);
    }

    const picked = await DialogV2.wait({
        window: { title: game.i18n.localize("DRPG.Murder.tierZeroTitle") },
        classes: ["drpg-panel"],
        content: dialogContent(`<form>
            <p>${game.i18n.format("DRPG.Murder.tierZeroIntro", {
                actor: foundry.utils.escapeHTML(actor.name),
                item: foundry.utils.escapeHTML(item.name)
            })}</p>
            <label>${game.i18n.localize("DRPG.Murder.tierZeroRate")}
                <select name="tier">${options}</select></label>
            <p class="notes">${game.i18n.localize("DRPG.Murder.tierZeroNote")}</p>
        </form>`),
        buttons: [
            {
                action: "ok", label: game.i18n.localize("DRPG.Panel.apply"), default: true,
                callback: (e, b, d) => d.element.querySelector("[name=tier]").value
            }
        ],
        rejectClose: false
    }).catch(() => null);

    // Dismissed is not a ruling — fall back to what the item actually is.
    const n = Number(picked);
    return Number.isFinite(n) ? Math.max(rule.min, Math.min(rule.max, n)) : 0;
}

/**
 * An unarmed attack that lands leaves the killer holding something.
 *
 * Guide: "Jeśli zabójca nie ma broni, może wykonać atak z disadvantage. Przy
 * sukcesie zyskuje broń improwizowaną, czyli narzędzie. Hope - Tier 2,
 * Despair - Tier 1." A real Crime Tool on the sheet, not a sentence — the next
 * Attack with a weapon has to be able to find it.
 */
async function grantImprovisedWeapon(actor, def, band, done) {
    const tier = def.unarmedImprovises?.[band];
    if (tier === undefined) return;

    const { grantItem } = await import("./inventory.mjs");
    const item = await grantItem(actor, {
        name: def.unarmedImprovises.name,
        category: "crimeTool",
        tier,
        // The killer is mid-incident and cannot go and put something down;
        // a GM's ruling outranks the carry cap here.
        override: true,
        description: `<p>${game.i18n.localize("DRPG.Murder.improvisedNote")}</p>`
    });

    if (item) {
        done.push(game.i18n.format("DRPG.Murder.improvised", {
            item: item.name, tier
        }));
    }
}

/**
 * Score a crisis action and apply it. GM-side: it writes to both participants'
 * sheets and to the map.
 */
export async function resolveCrisisAction({ actorId, key, total, isCritical, withHope } = {}) {
    if (!game.user.isGM) return null;

    const state = murderState();
    const actor = game.actors.get(actorId);
    const def = CRISIS_ACTIONS[key];
    if (!state || !actor || !def) return null;

    const side = def.side;
    const threshold = key === "finishingBlow"
        ? finishingBlowThreshold(state)
        : def.threshold;
    const success = isCritical || total >= threshold;
    const band = isCritical ? "critical" : (withHope ? "hope" : "despair");
    const done = [];

    // The advantage a missed attempt earned is spent whatever happens next.
    await clearAdvantage(side);

    // Read before anything is applied: `grantImprovisedWeapon` below puts a
    // Crime Tool on the sheet, and asking afterwards would find the weapon the
    // attack itself just produced.
    const wasUnarmed = def.unarmedImprovises ? !hasWeapon(actor) : false;

    if (success) {
        await applyRemnant(actor, def.remnant?.[band], def, band, done);
        await applyDamage(actor, state, def, band, done);
        if (wasUnarmed) await grantImprovisedWeapon(actor, def, band, done);
        await applyHindrance(state, def, band, done);
        await applyUnlocks(state, def, key, band, done);
        if (def.swapsRoles) await swapRoles(state, band, done);
        if (def.endsIncident) await finishIncident(state, key, band, done);
    } else {
        if (def.failureGrantsAdvantage) {
            await grantAdvantage(side);
            done.push(game.i18n.localize("DRPG.Murder.advantageNext"));
        }
        await applyRemnant(actor, def.failureRemnant?.[band], def, band, done,
            Boolean(def.failureRemnantReinforced?.[band]));
        await applyDamage(actor, state, def, band, done, true);
        if (def.failureExtraDrain) {
            await drain(state, def.failureExtraDrain, done);
        }
    }

    if (def.kind === "resolution") await spendStress(actor, done);

    await announceCrisis(actor, def, { success, band, total, threshold, done });

    // A third party's action is free: it is taken out of the victim→killer
    // order and must not advance it, or somebody walking in would silently
    // skip whoever's turn it actually was. It is also the only one they get.
    if (side === "third") {
        if (murderState()?.stage === "incident") await writeState({ thirdActed: true });
        return { success, band, done };
    }

    // The turn passes unless the incident just ended.
    if (murderState()?.stage === "incident") await passTurn();

    return { success, band, done };
}

/** Five times the victim's remaining HP; free once they are at zero. */
function finishingBlowThreshold(state) {
    const victim = game.actors.get(state.victimId);
    if (!victim) return 0;
    const left = resourceMax(victim, "hitPoints") - resourceValue(victim, "hitPoints");
    return Math.max(0, left * INCIDENT.finishingBlowPerHp);
}

async function applyRemnant(actor, visibility, def, band, done, reinforced = false) {
    if (!visibility) return;
    const placed = await dropRemnant(actor, {
        type: def.remnantType ?? "incident",
        visibility,
        tiedToCrime: true,
        reinforced: reinforced || Boolean(def.criticalReinforced && band === "critical"),
        action: "incident",
        note: def.label
    });
    if (placed) done.push(game.i18n.format("DRPG.Murder.leftRemnant", { visibility }));
}

/** Damage the killer deals. HP and Stress are reverse resources. */
async function applyDamage(actor, state, def, band, done, failed = false) {
    const table = failed ? def.failureDamage : def.damage;
    let hit = table?.[band];

    // A weapon attack scales on the tool rather than reading from a table.
    //
    // Unarmed is not tier 0 — the guide treats "no weapon" as its own case:
    // the attack is made at disadvantage and, on a success, produces a weapon
    // rather than using one. So an unarmed hit deals the bare 1, and the tool
    // it improvises is handed over by `grantImprovisedWeapon`.
    if (!failed && def.weaponDamage) {
        const { tier } = await chooseWeapon(actor);
        const amount = band === "critical"
            ? def.weaponDamage.critical(tier)
            : def.weaponDamage.normal(tier);
        hit = { hp: amount };
    }

    // The critical Strike lets the killer choose. Not a decision the module can
    // make, so it is reported and the GM applies it.
    if (hit?.choice) {
        done.push(game.i18n.localize("DRPG.Murder.killerChooses"));
        return;
    }
    if (!hit) return;

    const victim = game.actors.get(state.victimId);
    if (!victim) return;

    const update = {};
    for (const [resource, amount] of Object.entries(hit)) {
        const field = resource === "hp" ? "hitPoints" : "stress";
        const marks = resourceValue(victim, field);
        update[`system.resources.${field}.value`] =
            Math.min(resourceMax(victim, field), marks + amount);
    }
    await automatedUpdate(victim, update);
    done.push(game.i18n.format("DRPG.Murder.damaged", {
        name: victim.name,
        what: Object.entries(hit).map(([r, n]) => `${n} ${r.toUpperCase()}`).join(", ")
    }));
}

/**
 * Self-defence opening the victim's way out.
 *
 * Guide, the Samoobrona row: Hope unlocks "obie akcje kryzysowe rozwiązania
 * ofiary", Despair only "odwrócenie ról", and a critical unlocks both AND stops
 * the drain — "Ofiara przestaje tracić hp i stress". Either success also
 * "blokuje akcję kryzysową: Samoobrona", so there is exactly one attempt at it.
 *
 * Written as config rather than as a special case here, so a second gated
 * action later is a table entry and not another branch — see `unlocks` and
 * `lockedUntil` in CRISIS_ACTIONS.
 */
async function applyUnlocks(state, def, key, band, done) {
    const opened = def.unlocks?.[band];
    if (!opened?.length && !def.blocksSelf) return;

    const patch = {};

    if (opened?.length) {
        const unlocked = new Set(state.unlocked ?? []);
        for (const id of opened) unlocked.add(id);
        patch.unlocked = Array.from(unlocked);
        done.push(game.i18n.format("DRPG.Murder.unlockedActions", {
            names: opened.map(id => CRISIS_ACTIONS[id]?.label ?? id).join(", ")
        }));
    }

    // One attempt: the action closes itself for the rest of the incident.
    //
    // A separate list rather than a huge number in `blocked`. That store is
    // decremented every round by `passTurn`, and world state is stored as JSON —
    // `Infinity` serialises to `null`, which reads back as "not blocked at all".
    if (def.blocksSelf) {
        const spent = new Set(state.spent ?? []);
        spent.add(key);
        patch.spent = Array.from(spent);
    }

    if (def.criticalStopsDrain && band === "critical") {
        patch.drainStopped = true;
        done.push(game.i18n.localize("DRPG.Murder.drainStopped"));
    }

    await writeState(patch);
}

async function applyHindrance(state, def, band, done) {
    if (!def.hinders) return;

    const target = def.side === "killer" ? "victim" : "killer";
    const store = band === "critical" ? "blocked" : "hindered";
    const next = { ...(state[store] ?? {}) };
    next[target] = { ...(next[target] ?? {}) };
    for (const key of def.hinders.actions) next[target][key] = def.hinders.turns;

    await writeState({ [store]: next });
    done.push(game.i18n.format(
        band === "critical" ? "DRPG.Murder.blockedActions" : "DRPG.Murder.hinderedActions",
        { n: def.hinders.actions.length, turns: def.hinders.turns }
    ));
}

async function swapRoles(state, band, done) {
    const victim = game.actors.get(state.victimId);
    if (band !== "despair" && victim) {
        await automatedUpdate(victim, {
            "system.resources.stress.value": 0,
            "system.resources.hitPoints.value": 0
        });
    }
    // Everything that described the OLD arrangement of the fight is cleared,
    // not only the two hindrance stores.
    //
    // `unlocked`, `spent` and `drainStopped` are all statements about a
    // particular victim: which ways out they had bought, that they had used
    // their one Self-defence, and that a critical had stopped their bleeding.
    // Carrying them across a reversal handed all three to the person who just
    // became the victim — so the new victim started with Survive and Role
    // reversal already open, could never attempt Self-defence because somebody
    // else had spent it, and did not bleed at all. That last one guts the
    // reversal outright: the guide's whole point is "tym razem to zabójca traci
    // hp/stres".
    await writeState({
        killerId: state.victimId,
        victimId: state.killerId,
        hindered: { victim: {}, killer: {} },
        blocked: { victim: {}, killer: {} },
        unlocked: [],
        spent: [],
        drainStopped: false,
        advantageNext: { victim: false, killer: false },
        // The killer's Despair-success opener took Role reversal away from the
        // person who was the victim THEN. They are the killer now, and the
        // restriction is not a property of the chair they are sitting in.
        deniedToVictim: []
    });
    done.push(game.i18n.localize("DRPG.Murder.rolesSwapped"));
}

async function finishIncident(state, key, band, done) {
    await writeState({ stage: "resolution" });
    done.push(game.i18n.localize(
        key === "finishingBlow" ? "DRPG.Murder.victimDead" : "DRPG.Murder.incidentEnded"));

    // The killer can see their own traces from Stage 6 onwards — guide p. 26.
    if (key === "finishingBlow") {
        await whisperToGms(`<p>${game.i18n.localize("DRPG.Murder.resolutionNote")}</p>`);
    }
}

/** One turn's cost to the victim: Stress first, then HP. */
async function drain(state, amount, done) {
    const victim = game.actors.get(state.victimId);
    if (!victim) return;

    // A critical Self-defence buys the bleeding stopping — guide: "Ofiara
    // przestaje tracić hp i stress."
    if (state.drainStopped) {
        done.push(game.i18n.localize("DRPG.Murder.drainStopped"));
        return;
    }

    let left = amount;
    const update = {};

    const stressMarks = resourceValue(victim, "stress");
    const stressMax = resourceMax(victim, "stress");
    const stressRoom = stressMax - stressMarks;
    const toStress = Math.min(stressRoom, left);
    if (toStress > 0) {
        update["system.resources.stress.value"] = stressMarks + toStress;
        left -= toStress;
    }
    if (left > 0) {
        const hpMarks = resourceValue(victim, "hitPoints");
        update["system.resources.hitPoints.value"] =
            Math.min(resourceMax(victim, "hitPoints"), hpMarks + left);
    }

    if (Object.keys(update).length) {
        await automatedUpdate(victim, update);
        done.push(game.i18n.format("DRPG.Murder.drained", { name: victim.name, n: amount }));
    }
}

async function grantAdvantage(side) {
    const state = murderState();
    await writeState({ advantageNext: { ...(state?.advantageNext ?? {}), [side]: true } });
}

async function clearAdvantage(side) {
    const state = murderState();
    if (!state?.advantageNext?.[side]) return;
    await writeState({ advantageNext: { ...state.advantageNext, [side]: false } });
}

async function spendStress(actor, done) {
    const marks = resourceValue(actor, "stress");
    const max = resourceMax(actor, "stress");
    if (marks >= max) return;
    await automatedUpdate(actor, {
        "system.resources.stress.value": Math.min(max, marks + RESOLUTION_STRESS_COST)
    });
    done.push(game.i18n.format("DRPG.Murder.spentStress", { n: RESOLUTION_STRESS_COST }));
}

/**
 * Hand the turn over. The victim always opens the incident, so a full round is
 * victim → killer, and the drain lands at the start of each of the victim's.
 */
export async function passTurn() {
    if (!game.user.isGM) return null;
    const state = murderState();
    if (!state || state.stage !== "incident") return null;

    const next = state.turnSide === "victim" ? "killer" : "victim";
    const turn = next === "victim" ? state.turn + 1 : state.turn;

    // Tick down the two-turn hindrances at the top of each round.
    const decay = store => {
        const out = {};
        for (const [side, actions] of Object.entries(state[store] ?? {})) {
            out[side] = {};
            for (const [key, turns] of Object.entries(actions)) {
                if (turns > 1) out[side][key] = turns - 1;
            }
        }
        return out;
    };

    const patch = { turnSide: next, turn };
    if (next === "victim") {
        patch.hindered = decay("hindered");
        patch.blocked = decay("blocked");
    }

    await writeState(patch);

    if (next === "victim") {
        const done = [];
        await drain(murderState(), state.indirect ? INCIDENT.drain.indirect : INCIDENT.drain.direct, done);
        if (done.length) await whisperToGms(`<p>${done.join("<br>")}</p>`);
    }

    return murderState();
}

/* ==========================================================================
 * WALKING IN ON IT
 * --------------------------------------------------------------------------
 * Guide: "W wypadku, gdy w dowolnym momencie do pomieszczenia w trakcie
 * Incydentu wejdzie strona trzecia poprzez akcję ruch, strona trzecia
 * otrzymuje automatyczny, darmowy wybór między akcjami kryzysowymi rozwiązania
 * bezpośredniej strony trzeciej."
 *
 * "Automatyczny" is the operative word, and it was the one thing the module
 * left to the GM noticing: `thirdPartyEnters` existed but only ever fired from
 * a picker in the incident tracker. So somebody could walk their token straight
 * into a murder in progress and nothing would happen unless a human spotted it
 * on the map — which, during an incident, nobody is watching for.
 *
 * DIRECT MURDERS ONLY. An indirect one has no confrontation to walk in on: the
 * victim is alone with a trap, which is what INCIDENT.drain.indirect models and
 * why `sharedEscape` is written for two people in a room. There is nobody there
 * to be interrupted.
 * ========================================================================== */

export function registerMurder() {
    Hooks.on("updateToken", (tokenDoc, changes) => {
        if (changes.x === undefined && changes.y === undefined) return;
        // One client decides, or several GMs would each write the same
        // participant in — the same rule movement.mjs applies to who pays.
        if (!isPrimaryGm()) return;
        maybeThirdParty(tokenDoc).catch(err =>
            error("Could not check for a third party walking in", err));
    });
}

/**
 * Did this token just walk into the room the incident is happening in?
 *
 * "The room" is the VICTIM's, not the killer's. They are in the same place for
 * the whole of Stage 5 — but the victim is the one who cannot leave, so their
 * position is the stable answer, and a killer momentarily read as elsewhere
 * (an unlinked token, a half-loaded canvas) must not move the crime scene.
 */
async function maybeThirdParty(tokenDoc) {
    const state = murderState();
    if (!state || state.stage !== "incident") return;
    if (state.indirect) return;          // nothing to interrupt
    if (state.thirdId) return;           // the guide gives the scene one

    const actor = tokenDoc?.actor;
    if (!actor || actor.type !== "character") return;
    if (actor.id === state.killerId || actor.id === state.victimId) return;
    if (isMonokuma(actor)) return;       // the GM on the map is not a witness
    if (actor.getFlag(MODULE_ID, FLAGS.deceased)) return;
    // A token the GM has hidden is not in the scene as far as the fiction is
    // concerned — the same rule `othersInRoom` applies.
    if (tokenDoc.hidden) return;

    const { roomOfToken, locateActor } = await import("./movement.mjs");
    const scene = locateActor(game.actors.get(state.victimId));
    if (!scene?.room) return;
    // Same scene, same room. Two rooms of the same name on two maps are not
    // one room — `sameRoom` makes the same distinction for a handover.
    if (tokenDoc.parent?.id !== scene.scene?.id) return;
    if (roomOfToken(tokenDoc) !== scene.room) return;

    await thirdPartyEnters(actor);
}

/** Somebody walked in. The guide gives them a free resolution action. */
export async function thirdPartyEnters(actor) {
    if (!game.user.isGM || !actor) return null;
    const state = murderState();
    if (!state || state.stage !== "incident") return null;
    if (state.thirdId) return null;

    // `thirdActed` is written explicitly rather than left undefined: it is what
    // gates their one free action, and a murder opened before this field
    // existed would otherwise carry no value at all.
    await writeState({ thirdId: actor.id, thirdActed: false });
    await whisperToOwner(actor, `
        <h3>${game.i18n.localize("DRPG.Murder.thirdTitle")}</h3>
        <p>${game.i18n.localize("DRPG.Murder.thirdIntro")}</p>`);
    log(`${actor.name} walked into the incident.`);
    return murderState();
}

/** Close the murder out. */
export async function endMurder({ reason = "closed" } = {}) {
    if (!game.user.isGM) return null;
    await game.settings.set(MODULE_ID, SETTINGS.murderState, {});
    log(`Murder closed (${reason}).`);
    return null;
}

/* ==========================================================================
 * TELLING THE TABLE
 * ========================================================================== */

async function tellGms(text, extra = {}) {
    await whisperToGms(`<p>${foundry.utils.escapeHTML(text)}</p>${
        extra.keys ? `<p><strong>${game.i18n.format("DRPG.Murder.keyCount", {
            n: extra.keys
        })}</strong></p>` : ""
    }`);
}

async function announceCrisis(actor, def, { success, band, total, threshold, done }) {
    const outcome = success ? (def[band] ?? "") : (def.failure ?? "");
    await whisperToGms(`
        <h3>${foundry.utils.escapeHTML(def.label)} — ${foundry.utils.escapeHTML(actor.name)}</h3>
        <p>${total} ${success ? "≥" : "<"} ${threshold} · ${
            game.i18n.localize(`DRPG.Murder.band.${band}`)}</p>
        ${outcome ? `<p>${foundry.utils.escapeHTML(outcome)}</p>` : ""}
        ${done.length ? `<ul>${done.map(d => `<li>${d}</li>`).join("")}</ul>` : ""}`);
}

/* ==========================================================================
 * THE GM'S TRACKER
 * ========================================================================== */

/** Open a murder from the GM panel. */
export async function openMurderDialog() {
    if (!game.user.isGM) {
        ui.notifications.warn(game.i18n.localize("DRPG.Panel.gmOnly"));
        return null;
    }

    if (murderState()) return openIncidentTracker();

    const { livingStudents } = await import("./chapter.mjs");
    const alive = livingStudents();
    if (alive.length < 2) {
        ui.notifications.warn(game.i18n.localize("DRPG.Murder.needTwo"));
        return null;
    }

    const options = alive
        .map(a => `<option value="${a.id}">${foundry.utils.escapeHTML(a.name)}</option>`).join("");

    const result = await DialogV2.wait({
        window: { title: game.i18n.localize("DRPG.Murder.openTitle") },
        classes: ["drpg-panel"],
        content: dialogContent(`<form>
            <p class="notes">${game.i18n.localize("DRPG.Murder.openIntro")}</p>
            <label>${game.i18n.localize("DRPG.Murder.killer")}
                <select name="killer">${options}</select></label>
            <label>${game.i18n.localize("DRPG.Murder.victim")}
                <select name="victim">${options}</select></label>
            <label class="drpg-checkbox">
                <input type="checkbox" name="indirect" />
                ${game.i18n.localize("DRPG.Murder.indirect")}</label>
        </form>`),
        buttons: [
            {
                action: "ok", label: game.i18n.localize("DRPG.Murder.openConfirm"), default: true,
                callback: (e, b, d) => {
                    const f = d.element.querySelector("form");
                    return {
                        killerId: f.killer.value,
                        victimId: f.victim.value,
                        indirect: f.indirect.checked
                    };
                }
            },
            { action: "cancel", label: game.i18n.localize("DRPG.Advance.cancel") }
        ],
        rejectClose: false
    });

    if (!result || result === "cancel") return null;
    if (result.killerId === result.victimId) {
        ui.notifications.warn(game.i18n.localize("DRPG.Murder.sameActor"));
        return null;
    }

    await openMurder(result);
    return openIncidentTracker();
}

/**
 * Throw one of the two opening rolls.
 *
 * Rolled on the GM's client, on the participant's actor. That is a deliberate
 * difference from every other roll in this module: Stage 4 happens before the
 * table knows an incident is coming, and handing the victim a roll window
 * titled "opening roll — victim" would tell them the one thing the guide is
 * careful not to.
 *
 * Night swings both rolls, in opposite directions.
 */
async function rollOpening(side, state) {
    const def = MURDER_OPENING[side];
    const actor = game.actors.get(side === "killer" ? state.killerId : state.victimId);
    if (!actor) return null;

    const calls = await import("./call-effects.mjs");
    const night = atNight();
    const situational = night ? (def.nightAdvantage ? 1 : def.nightDisadvantage ? -1 : 0) : 0;
    if (situational) calls.armSituational(situational);

    let roll;
    try {
        const { rollTrait } = await import("./action-rolls.mjs");
        roll = await rollTrait(actor, def.traits[0], {
            remember: false,
            actionKey: "murderOpening",
            context: { side }
        });
    } finally {
        calls.clearSituational();
    }
    if (!roll) return null;

    const payload = {
        total: roll.total,
        isCritical: Boolean(roll.isCritical),
        withHope: Boolean(roll.withHope)
    };
    return side === "killer"
        ? resolveKillerOpening(payload)
        : resolveVictimOpening(payload);
}

/** The live tracker: whose turn, what is left, and the controls. */
export async function openIncidentTracker() {
    if (!game.user.isGM) return null;
    const state = murderState();
    if (!state) {
        ui.notifications.info(game.i18n.localize("DRPG.Murder.none"));
        return null;
    }

    const killer = game.actors.get(state.killerId);
    const victim = game.actors.get(state.victimId);
    const third = state.thirdId ? game.actors.get(state.thirdId) : null;

    const left = res => victim
        ? `${resourceMax(victim, res) - resourceValue(victim, res)} / ${resourceMax(victim, res)}`
        : "?";

    const action = await DialogV2.wait({
        window: { title: game.i18n.localize("DRPG.Murder.trackerTitle") },
        classes: ["drpg-panel"],
        content: dialogContent(`<div>
            <p><strong>${foundry.utils.escapeHTML(killer?.name ?? "?")}</strong> →
               <strong>${foundry.utils.escapeHTML(victim?.name ?? "?")}</strong>${
                third ? ` · ${game.i18n.format("DRPG.Murder.thirdIs", {
                    name: foundry.utils.escapeHTML(third.name)
                })}` : ""}</p>
            <p>${game.i18n.format("DRPG.Murder.trackerState", {
                stage: game.i18n.localize(`DRPG.Murder.stage.${state.stage}`),
                turn: state.turn,
                side: game.i18n.localize(`DRPG.Murder.side.${state.turnSide}`)
            })}</p>
            <p>${game.i18n.format("DRPG.Murder.victimLeft", {
                hp: left("hitPoints"), stress: left("stress")
            })}</p>
            <p>${game.i18n.format("DRPG.Murder.keyCount", { n: state.keyRemnants })}</p>
        </div>`),
        buttons: [
            // Stage 4 offers exactly one roll, and which one is decided by the
            // kind of murder rather than by asking.
            //
            // A direct murder opens on the KILLER's roll: they are in the room,
            // and the question is whether they go through with it. An indirect
            // one has nobody to confront — the trap is already set — so the only
            // roll is the VICTIM's, on whether they sense it. Offering both
            // meant half of every Stage 4 was a button that should not have been
            // pressed, and pressing the wrong one wrote the wrong state.
            ...(state.stage === "openingRoll" ? [
                state.indirect
                    ? { action: "rollVictim", label: game.i18n.localize("DRPG.Murder.rollVictim"),
                        default: true }
                    : { action: "rollKiller", label: game.i18n.localize("DRPG.Murder.rollKiller"),
                        default: true }
            ] : [
                { action: "pass", label: game.i18n.localize("DRPG.Murder.passTurn"), default: true },
                { action: "third", label: game.i18n.localize("DRPG.Murder.addThird") }
            ]),
            { action: "end", label: game.i18n.localize("DRPG.Murder.endMurder") },
            { action: "close", label: game.i18n.localize("DRPG.Panel.close") }
        ],
        rejectClose: false
    });

    if (action === "rollKiller" || action === "rollVictim") {
        await rollOpening(action === "rollKiller" ? "killer" : "victim", state);
        return openIncidentTracker();
    }
    if (action === "pass") {
        await passTurn();
        return openIncidentTracker();
    }
    if (action === "third") {
        const { livingStudents } = await import("./chapter.mjs");
        const others = livingStudents().filter(a =>
            a.id !== state.killerId && a.id !== state.victimId);
        if (!others.length) {
            ui.notifications.warn(game.i18n.localize("DRPG.Murder.nobodyElse"));
            return openIncidentTracker();
        }
        const id = await DialogV2.wait({
            window: { title: game.i18n.localize("DRPG.Murder.addThird") },
            content: `<form><label>${game.i18n.localize("DRPG.Murder.whoWalkedIn")}
                <select name="who">${others.map(a =>
                    `<option value="${a.id}">${foundry.utils.escapeHTML(a.name)}</option>`
                ).join("")}</select></label></form>`,
            buttons: [
                {
                    action: "ok", label: game.i18n.localize("DRPG.Panel.apply"), default: true,
                    callback: (e, b, d) => d.element.querySelector("[name=who]").value
                },
                { action: "cancel", label: game.i18n.localize("DRPG.Advance.cancel") }
            ],
            rejectClose: false
        });
        if (id && id !== "cancel") await thirdPartyEnters(game.actors.get(id));
        return openIncidentTracker();
    }
    if (action === "end") {
        const sure = await DialogV2.confirm({
            window: { title: game.i18n.localize("DRPG.Murder.endMurder") },
            content: `<p>${game.i18n.localize("DRPG.Murder.endConfirm")}</p>`
        });
        if (sure) await endMurder();
    }
    return null;
}
