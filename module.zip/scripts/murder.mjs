/**
 * Danganronpa RPG — the murder engine.
 * ---------------------------------------------------------------------------
 * Guide, pp. 17–27. The murder is the one part of this game the rules treat as
 * exceptional, and it is the only place where two players roll against each
 * other turn by turn.
 *
 * The shape of it:
 *
 *   Stage 4  two opening rolls. The killer's decides whether the incident
 *            happens at all and HOW MANY Key Remnants it leaves — the better
 *            the roll, the fewer clues. The victim's decides whether they
 *            sense it coming.
 *   Stage 5  the incident. The victim always moves first, and every turn costs
 *            them Stress until it runs out and then HP. Both sides pick crisis
 *            actions; a third party who walks in gets a free one.
 *   Stage 6  resolution. The killer cleans up — and now, for the first time,
 *            can see the Remnants they left.
 *
 * WHAT IS AUTOMATED AND WHAT IS NOT. The module owns the numbers: thresholds,
 * the drain, turn order, damage, which Remnants each outcome leaves, who is
 * hindered and for how long. It does not own the prose. "The victim takes
 * something of the killer's and makes evidence of it" is a sentence a person
 * finishes, so each outcome's text goes to the GM and the table rather than
 * being invented here.
 *
 * WHY THE STATE IS WORLD-SCOPED. Unlike the Truth Bullet ledger, this is not
 * secret-by-design. Both participants need to see whose turn it is, what the
 * victim has left and which of their own actions are blocked — live, every
 * turn. See the note on SETTINGS.murderState for the trade that was made.
 */

import {
    MODULE_ID, MURDER_OPENING, INCIDENT, CRISIS_ACTIONS, KEY_REMNANTS,
    RESOLUTION_STRESS_COST
} from "./config.mjs";
import { SETTINGS } from "./settings.mjs";
import { getClock } from "./clock.mjs";
import { resourceValue, resourceMax } from "./character.mjs";
import { automatedUpdate } from "./resource-guard.mjs";
import { dropRemnant } from "./remnants.mjs";
import { dialogContent, whisperToGms, whisperToOwner, log, error } from "./utils.mjs";

const DialogV2 = foundry.applications.api.DialogV2;

/* ==========================================================================
 * STATE
 * ========================================================================== */

/** The murder in progress, or `null`. */
export function murderState() {
    const stored = game.settings.get(MODULE_ID, SETTINGS.murderState) ?? {};
    return stored.active ? stored : null;
}

async function writeState(patch) {
    if (!game.user.isGM) return null;
    const next = { ...(game.settings.get(MODULE_ID, SETTINGS.murderState) ?? {}), ...patch };
    await game.settings.set(MODULE_ID, SETTINGS.murderState, next);
    return next;
}

/** Which side is this actor on, if any: "killer" | "victim" | "third" | null. */
export function sideOf(actor) {
    const state = murderState();
    if (!state || !actor) return null;
    if (state.killerId === actor.id) return "killer";
    if (state.victimId === actor.id) return "victim";
    if (state.thirdId === actor.id) return "third";
    return null;
}

/**
 * Is it this actor's turn to act?
 *
 * A third party is deliberately outside the turn order. The guide gives
 * whoever walks in on an incident ONE free action, and "free" here means
 * exactly that: it does not wait for a turn and it does not consume one. Since
 * `turnSide` only ever holds "victim" or "killer", asking whether it equals
 * "third" is always false — which meant the third party was told they had a
 * free action and then refused with "not your turn" every time they tried to
 * use it. They may act while they still have that action, and not after.
 */
export function isTheirTurn(actor) {
    const state = murderState();
    if (!state || state.stage !== "incident") return false;
    const side = sideOf(actor);
    if (side === "third") return !state.thirdActed;
    return state.turnSide === side;
}

/** Crisis actions this actor may take right now, with their hindered flags. */
export function availableCrisisActions(actor) {
    const state = murderState();
    const side = sideOf(actor);
    if (!state || state.stage !== "incident" || !side) return [];

    const hindered = state.hindered?.[side] ?? {};
    const blocked = state.blocked?.[side] ?? {};

    return Object.entries(CRISIS_ACTIONS)
        .filter(([, def]) => def.side === side)
        // The guide takes Role Reversal away from a victim whose killer opened
        // on a Despair success.
        .filter(([key]) => !(state.deniedToVictim ?? []).includes(key))
        .map(([key, def]) => ({
            key,
            def,
            hindered: (hindered[key] ?? 0) > 0,
            blocked: (blocked[key] ?? 0) > 0
        }));
}

/* ==========================================================================
 * STAGE 4 — THE OPENING
 * ========================================================================== */

/** Is it night? The killer's roll wants to know, and so does the victim's. */
function atNight() {
    const t = getClock().timeOfDay;
    return t === "night" || t === "Night";
}

/**
 * Open a murder. GM-driven: the declaration and the consent happened away from
 * the table, and this is the moment they become mechanical.
 */
export async function openMurder({ killerId, victimId, indirect = false } = {}) {
    if (!game.user.isGM) return null;

    const killer = game.actors.get(killerId);
    const victim = game.actors.get(victimId);
    if (!killer || !victim || killer.id === victim.id) return null;

    await writeState({
        active: true,
        stage: "openingRoll",
        indirect,
        killerId, victimId, thirdId: null,
        turn: 0,
        turnSide: "victim",
        keyRemnants: KEY_REMNANTS.prepared,
        deniedToVictim: [],
        hindered: { victim: {}, killer: {} },
        blocked: { victim: {}, killer: {} },
        advantageNext: { victim: false, killer: false },
        openedAt: Date.now()
    });

    await whisperToGms(`
        <h3>${game.i18n.localize("DRPG.Murder.openedTitle")}</h3>
        <p>${game.i18n.format("DRPG.Murder.opened", {
            killer: foundry.utils.escapeHTML(killer.name),
            victim: foundry.utils.escapeHTML(victim.name)
        })}</p>
        <p>${game.i18n.localize(atNight()
            ? "DRPG.Murder.nightNote" : "DRPG.Murder.dayNote")}</p>`);

    log(`Murder opened: ${killer.name} → ${victim.name}${indirect ? " (indirect)" : ""}.`);
    return murderState();
}

/**
 * Record the killer's opening roll.
 *
 * The Key Remnant count comes straight off the duality: Hope leaves the most
 * evidence, a critical the least. Floored at the guide's minimum so a case can
 * never become unsolvable by a good roll.
 */
export async function resolveKillerOpening({ total, isCritical, withHope }) {
    if (!game.user.isGM) return null;
    const state = murderState();
    if (!state) return null;

    const def = MURDER_OPENING.killer;
    const success = isCritical || total >= def.threshold;

    if (!success) {
        await announce(def.failure);
        await endMurder({ reason: "openingFailed" });
        return { success: false };
    }

    const band = isCritical ? "critical" : (withHope ? "hope" : "despair");
    const keys = Math.max(KEY_REMNANTS.minimum, def.keyRemnants[band]);

    const patch = { stage: "incident", keyRemnants: keys, turn: 1, turnSide: "victim" };

    // A Despair success costs the victim their Stress and their way out.
    if (band === "despair") {
        const victim = game.actors.get(state.victimId);
        if (victim) {
            await automatedUpdate(victim, {
                "system.resources.stress.value": resourceMax(victim, "stress")
            });
        }
        patch.deniedToVictim = ["roleReversal"];
    }

    await writeState(patch);
    await announce(def[band], { keys });
    return { success: true, band, keys };
}

/** Record the victim's opening roll. A success can call the whole thing off. */
export async function resolveVictimOpening({ total, isCritical, withHope }) {
    if (!game.user.isGM) return null;
    const state = murderState();
    if (!state) return null;

    const def = MURDER_OPENING.victim;
    const success = isCritical || total >= def.threshold;

    if (!success) {
        await announce(def.failure);
        return { success: false };
    }

    const band = isCritical ? "critical" : (withHope ? "hope" : "despair");
    await announce(def[band]);

    // The victim sensing it coming does not end the incident by itself — the
    // guide gives them a free Move and lets them use it or not. Ending it is
    // the GM's call, which is why this reports rather than decides.
    return { success: true, band };
}

/* ==========================================================================
 * STAGE 5 — THE INCIDENT
 * ========================================================================== */

/**
 * Take one crisis action, roll it, and apply everything mechanical about it.
 *
 * Called from the actor's own client — it is their roll — but every world write
 * it produces goes through the GM, same as the rest of the module.
 */
export async function takeCrisisAction(actor, key) {
    const state = murderState();
    const side = sideOf(actor);
    const def = CRISIS_ACTIONS[key];

    if (!state || state.stage !== "incident" || !def || def.side !== side) return null;
    if (!isTheirTurn(actor)) {
        ui.notifications.warn(game.i18n.localize("DRPG.Murder.notYourTurn"));
        return null;
    }
    if ((state.blocked?.[side]?.[key] ?? 0) > 0) {
        ui.notifications.warn(game.i18n.localize("DRPG.Murder.actionBlocked"));
        return null;
    }
    // A resolution action costs Stress rather than an action, and needs some.
    if (def.kind === "resolution" && resourceValue(actor, "stress") >= resourceMax(actor, "stress")) {
        ui.notifications.warn(game.i18n.localize("DRPG.Murder.noStressLeft"));
        return null;
    }

    const { rollTrait } = await import("./action-rolls.mjs");
    const calls = await import("./call-effects.mjs");

    // Advantage and disadvantage that belong to the situation rather than to a
    // Call: a hindered action, a weapon in hand, a second try after a miss.
    let situational = 0;
    if ((state.hindered?.[side]?.[key] ?? 0) > 0) situational -= 1;
    if (state.advantageNext?.[side]) situational += 1;
    if (def.weaponAdvantage && hasWeapon(actor)) situational += 1;
    if (def.unarmedDisadvantage && !hasWeapon(actor)) situational -= 1;

    const trait = def.traits?.[0] ?? "body";
    if (situational) calls.armSituational(situational);

    let roll;
    try {
        roll = await rollTrait(actor, trait, { actionKey: "crisis", context: { crisis: key } });
    } finally {
        calls.clearSituational();
    }
    if (!roll) return null;

    const { requestCrisisResult } = await import("./gm-bridge.mjs");
    await requestCrisisResult({
        actorId: actor.id, key,
        total: roll.total,
        isCritical: Boolean(roll.isCritical),
        withHope: Boolean(roll.withHope)
    });

    return { roll };
}

/** Anything they could swing. Tier is what a weapon attack scales on. */
function hasWeapon(actor) {
    return actor.items.some(i => i.getFlag(MODULE_ID, "category") === "crimeTool");
}

function bestWeaponTier(actor) {
    return actor.items
        .filter(i => i.getFlag(MODULE_ID, "category") === "crimeTool")
        .reduce((best, i) => Math.max(best, i.getFlag(MODULE_ID, "tier") ?? 0), 0);
}

/**
 * Score a crisis action and apply it. GM-side: it writes to both participants'
 * sheets and to the map.
 */
export async function resolveCrisisAction({ actorId, key, total, isCritical, withHope } = {}) {
    if (!game.user.isGM) return null;

    const state = murderState();
    const actor = game.actors.get(actorId);
    const def = CRISIS_ACTIONS[key];
    if (!state || !actor || !def) return null;

    const side = def.side;
    const threshold = key === "finishingBlow"
        ? finishingBlowThreshold(state)
        : def.threshold;
    const success = isCritical || total >= threshold;
    const band = isCritical ? "critical" : (withHope ? "hope" : "despair");
    const done = [];

    // The advantage a missed attempt earned is spent whatever happens next.
    await clearAdvantage(side);

    if (success) {
        await applyRemnant(actor, def.remnant?.[band], def, band, done);
        await applyDamage(actor, state, def, band, done);
        await applyHindrance(state, def, band, done);
        if (def.swapsRoles) await swapRoles(state, band, done);
        if (def.endsIncident) await finishIncident(state, key, band, done);
    } else {
        if (def.failureGrantsAdvantage) {
            await grantAdvantage(side);
            done.push(game.i18n.localize("DRPG.Murder.advantageNext"));
        }
        await applyRemnant(actor, def.failureRemnant?.[band], def, band, done,
            Boolean(def.failureRemnantReinforced?.[band]));
        await applyDamage(actor, state, def, band, done, true);
        if (def.failureExtraDrain) {
            await drain(state, def.failureExtraDrain, done);
        }
    }

    if (def.kind === "resolution") await spendStress(actor, done);

    await announceCrisis(actor, def, { success, band, total, threshold, done });

    // A third party's action is free: it is taken out of the victim→killer
    // order and must not advance it, or somebody walking in would silently
    // skip whoever's turn it actually was. It is also the only one they get.
    if (side === "third") {
        if (murderState()?.stage === "incident") await writeState({ thirdActed: true });
        return { success, band, done };
    }

    // The turn passes unless the incident just ended.
    if (murderState()?.stage === "incident") await passTurn();

    return { success, band, done };
}

/** Five times the victim's remaining HP; free once they are at zero. */
function finishingBlowThreshold(state) {
    const victim = game.actors.get(state.victimId);
    if (!victim) return 0;
    const left = resourceMax(victim, "hitPoints") - resourceValue(victim, "hitPoints");
    return Math.max(0, left * INCIDENT.finishingBlowPerHp);
}

async function applyRemnant(actor, visibility, def, band, done, reinforced = false) {
    if (!visibility) return;
    const placed = await dropRemnant(actor, {
        type: def.remnantType ?? "incident",
        visibility,
        tiedToCrime: true,
        reinforced: reinforced || Boolean(def.criticalReinforced && band === "critical"),
        action: "incident",
        note: def.label
    });
    if (placed) done.push(game.i18n.format("DRPG.Murder.leftRemnant", { visibility }));
}

/** Damage the killer deals. HP and Stress are reverse resources. */
async function applyDamage(actor, state, def, band, done, failed = false) {
    const table = failed ? def.failureDamage : def.damage;
    let hit = table?.[band];

    // A weapon attack scales on the tool rather than reading from a table.
    if (!failed && def.weaponDamage) {
        const tier = bestWeaponTier(actor);
        const amount = band === "critical"
            ? def.weaponDamage.critical(tier)
            : def.weaponDamage.normal(tier);
        hit = { hp: amount };
    }

    // The critical Strike lets the killer choose. Not a decision the module can
    // make, so it is reported and the GM applies it.
    if (hit?.choice) {
        done.push(game.i18n.localize("DRPG.Murder.killerChooses"));
        return;
    }
    if (!hit) return;

    const victim = game.actors.get(state.victimId);
    if (!victim) return;

    const update = {};
    for (const [resource, amount] of Object.entries(hit)) {
        const field = resource === "hp" ? "hitPoints" : "stress";
        const marks = resourceValue(victim, field);
        update[`system.resources.${field}.value`] =
            Math.min(resourceMax(victim, field), marks + amount);
    }
    await automatedUpdate(victim, update);
    done.push(game.i18n.format("DRPG.Murder.damaged", {
        name: victim.name,
        what: Object.entries(hit).map(([r, n]) => `${n} ${r.toUpperCase()}`).join(", ")
    }));
}

async function applyHindrance(state, def, band, done) {
    if (!def.hinders) return;

    const target = def.side === "killer" ? "victim" : "killer";
    const store = band === "critical" ? "blocked" : "hindered";
    const next = { ...(state[store] ?? {}) };
    next[target] = { ...(next[target] ?? {}) };
    for (const key of def.hinders.actions) next[target][key] = def.hinders.turns;

    await writeState({ [store]: next });
    done.push(game.i18n.format(
        band === "critical" ? "DRPG.Murder.blockedActions" : "DRPG.Murder.hinderedActions",
        { n: def.hinders.actions.length, turns: def.hinders.turns }
    ));
}

async function swapRoles(state, band, done) {
    const victim = game.actors.get(state.victimId);
    if (band !== "despair" && victim) {
        await automatedUpdate(victim, {
            "system.resources.stress.value": 0,
            "system.resources.hitPoints.value": 0
        });
    }
    await writeState({
        killerId: state.victimId,
        victimId: state.killerId,
        hindered: { victim: {}, killer: {} },
        blocked: { victim: {}, killer: {} }
    });
    done.push(game.i18n.localize("DRPG.Murder.rolesSwapped"));
}

async function finishIncident(state, key, band, done) {
    await writeState({ stage: "resolution" });
    done.push(game.i18n.localize(
        key === "finishingBlow" ? "DRPG.Murder.victimDead" : "DRPG.Murder.incidentEnded"));

    // The killer can see their own traces from Stage 6 onwards — guide p. 26.
    if (key === "finishingBlow") {
        await whisperToGms(`<p>${game.i18n.localize("DRPG.Murder.resolutionNote")}</p>`);
    }
}

/** One turn's cost to the victim: Stress first, then HP. */
async function drain(state, amount, done) {
    const victim = game.actors.get(state.victimId);
    if (!victim) return;

    let left = amount;
    const update = {};

    const stressMarks = resourceValue(victim, "stress");
    const stressMax = resourceMax(victim, "stress");
    const stressRoom = stressMax - stressMarks;
    const toStress = Math.min(stressRoom, left);
    if (toStress > 0) {
        update["system.resources.stress.value"] = stressMarks + toStress;
        left -= toStress;
    }
    if (left > 0) {
        const hpMarks = resourceValue(victim, "hitPoints");
        update["system.resources.hitPoints.value"] =
            Math.min(resourceMax(victim, "hitPoints"), hpMarks + left);
    }

    if (Object.keys(update).length) {
        await automatedUpdate(victim, update);
        done.push(game.i18n.format("DRPG.Murder.drained", { name: victim.name, n: amount }));
    }
}

async function grantAdvantage(side) {
    const state = murderState();
    await writeState({ advantageNext: { ...(state?.advantageNext ?? {}), [side]: true } });
}

async function clearAdvantage(side) {
    const state = murderState();
    if (!state?.advantageNext?.[side]) return;
    await writeState({ advantageNext: { ...state.advantageNext, [side]: false } });
}

async function spendStress(actor, done) {
    const marks = resourceValue(actor, "stress");
    const max = resourceMax(actor, "stress");
    if (marks >= max) return;
    await automatedUpdate(actor, {
        "system.resources.stress.value": Math.min(max, marks + RESOLUTION_STRESS_COST)
    });
    done.push(game.i18n.format("DRPG.Murder.spentStress", { n: RESOLUTION_STRESS_COST }));
}

/**
 * Hand the turn over. The victim always opens the incident, so a full round is
 * victim → killer, and the drain lands at the start of each of the victim's.
 */
export async function passTurn() {
    if (!game.user.isGM) return null;
    const state = murderState();
    if (!state || state.stage !== "incident") return null;

    const next = state.turnSide === "victim" ? "killer" : "victim";
    const turn = next === "victim" ? state.turn + 1 : state.turn;

    // Tick down the two-turn hindrances at the top of each round.
    const decay = store => {
        const out = {};
        for (const [side, actions] of Object.entries(state[store] ?? {})) {
            out[side] = {};
            for (const [key, turns] of Object.entries(actions)) {
                if (turns > 1) out[side][key] = turns - 1;
            }
        }
        return out;
    };

    const patch = { turnSide: next, turn };
    if (next === "victim") {
        patch.hindered = decay("hindered");
        patch.blocked = decay("blocked");
    }

    await writeState(patch);

    if (next === "victim") {
        const done = [];
        await drain(murderState(), state.indirect ? INCIDENT.drain.indirect : INCIDENT.drain.direct, done);
        if (done.length) await whisperToGms(`<p>${done.join("<br>")}</p>`);
    }

    return murderState();
}

/** Somebody walked in. The guide gives them a free resolution action. */
export async function thirdPartyEnters(actor) {
    if (!game.user.isGM || !actor) return null;
    const state = murderState();
    if (!state || state.stage !== "incident") return null;
    if (state.thirdId) return null;

    // `thirdActed` is written explicitly rather than left undefined: it is what
    // gates their one free action, and a murder opened before this field
    // existed would otherwise carry no value at all.
    await writeState({ thirdId: actor.id, thirdActed: false });
    await whisperToOwner(actor, `
        <h3>${game.i18n.localize("DRPG.Murder.thirdTitle")}</h3>
        <p>${game.i18n.localize("DRPG.Murder.thirdIntro")}</p>`);
    log(`${actor.name} walked into the incident.`);
    return murderState();
}

/** Close the murder out. */
export async function endMurder({ reason = "closed" } = {}) {
    if (!game.user.isGM) return null;
    await game.settings.set(MODULE_ID, SETTINGS.murderState, {});
    log(`Murder closed (${reason}).`);
    return null;
}

/* ==========================================================================
 * TELLING THE TABLE
 * ========================================================================== */

async function announce(text, extra = {}) {
    await whisperToGms(`<p>${foundry.utils.escapeHTML(text)}</p>${
        extra.keys ? `<p><strong>${game.i18n.format("DRPG.Murder.keyCount", {
            n: extra.keys
        })}</strong></p>` : ""
    }`);
}

async function announceCrisis(actor, def, { success, band, total, threshold, done }) {
    const outcome = success ? (def[band] ?? "") : (def.failure ?? "");
    await whisperToGms(`
        <h3>${foundry.utils.escapeHTML(def.label)} — ${foundry.utils.escapeHTML(actor.name)}</h3>
        <p>${total} ${success ? "≥" : "<"} ${threshold} · ${
            game.i18n.localize(`DRPG.Murder.band.${band}`)}</p>
        ${outcome ? `<p>${foundry.utils.escapeHTML(outcome)}</p>` : ""}
        ${done.length ? `<ul>${done.map(d => `<li>${d}</li>`).join("")}</ul>` : ""}`);
}

/* ==========================================================================
 * THE GM'S TRACKER
 * ========================================================================== */

/** Open a murder from the GM panel. */
export async function openMurderDialog() {
    if (!game.user.isGM) {
        ui.notifications.warn(game.i18n.localize("DRPG.Panel.gmOnly"));
        return null;
    }

    if (murderState()) return openIncidentTracker();

    const { livingStudents } = await import("./chapter.mjs");
    const alive = livingStudents();
    if (alive.length < 2) {
        ui.notifications.warn(game.i18n.localize("DRPG.Murder.needTwo"));
        return null;
    }

    const options = alive
        .map(a => `<option value="${a.id}">${foundry.utils.escapeHTML(a.name)}</option>`).join("");

    const result = await DialogV2.wait({
        window: { title: game.i18n.localize("DRPG.Murder.openTitle") },
        classes: ["drpg-panel"],
        position: { width: 520 },
        content: dialogContent(`<form>
            <p class="notes">${game.i18n.localize("DRPG.Murder.openIntro")}</p>
            <label>${game.i18n.localize("DRPG.Murder.killer")}
                <select name="killer">${options}</select></label>
            <label>${game.i18n.localize("DRPG.Murder.victim")}
                <select name="victim">${options}</select></label>
            <label class="drpg-checkbox">
                <input type="checkbox" name="indirect" />
                ${game.i18n.localize("DRPG.Murder.indirect")}</label>
        </form>`),
        buttons: [
            {
                action: "ok", label: game.i18n.localize("DRPG.Murder.openConfirm"), default: true,
                callback: (e, b, d) => {
                    const f = d.element.querySelector("form");
                    return {
                        killerId: f.killer.value,
                        victimId: f.victim.value,
                        indirect: f.indirect.checked
                    };
                }
            },
            { action: "cancel", label: game.i18n.localize("DRPG.Advance.cancel") }
        ],
        rejectClose: false
    });

    if (!result || result === "cancel") return null;
    if (result.killerId === result.victimId) {
        ui.notifications.warn(game.i18n.localize("DRPG.Murder.sameActor"));
        return null;
    }

    await openMurder(result);
    return openIncidentTracker();
}

/**
 * Throw one of the two opening rolls.
 *
 * Rolled on the GM's client, on the participant's actor. That is a deliberate
 * difference from every other roll in this module: Stage 4 happens before the
 * table knows an incident is coming, and handing the victim a roll window
 * titled "opening roll — victim" would tell them the one thing the guide is
 * careful not to.
 *
 * Night swings both rolls, in opposite directions.
 */
async function rollOpening(side, state) {
    const def = MURDER_OPENING[side];
    const actor = game.actors.get(side === "killer" ? state.killerId : state.victimId);
    if (!actor) return null;

    const calls = await import("./call-effects.mjs");
    const night = atNight();
    const situational = night ? (def.nightAdvantage ? 1 : def.nightDisadvantage ? -1 : 0) : 0;
    if (situational) calls.armSituational(situational);

    let roll;
    try {
        const { rollTrait } = await import("./action-rolls.mjs");
        roll = await rollTrait(actor, def.traits[0], {
            remember: false,
            actionKey: "murderOpening",
            context: { side }
        });
    } finally {
        calls.clearSituational();
    }
    if (!roll) return null;

    const payload = {
        total: roll.total,
        isCritical: Boolean(roll.isCritical),
        withHope: Boolean(roll.withHope)
    };
    return side === "killer"
        ? resolveKillerOpening(payload)
        : resolveVictimOpening(payload);
}

/** The live tracker: whose turn, what is left, and the controls. */
export async function openIncidentTracker() {
    if (!game.user.isGM) return null;
    const state = murderState();
    if (!state) {
        ui.notifications.info(game.i18n.localize("DRPG.Murder.none"));
        return null;
    }

    const killer = game.actors.get(state.killerId);
    const victim = game.actors.get(state.victimId);
    const third = state.thirdId ? game.actors.get(state.thirdId) : null;

    const left = res => victim
        ? `${resourceMax(victim, res) - resourceValue(victim, res)} / ${resourceMax(victim, res)}`
        : "?";

    const action = await DialogV2.wait({
        window: { title: game.i18n.localize("DRPG.Murder.trackerTitle") },
        classes: ["drpg-panel"],
        position: { width: 520 },
        content: dialogContent(`<div>
            <p><strong>${foundry.utils.escapeHTML(killer?.name ?? "?")}</strong> →
               <strong>${foundry.utils.escapeHTML(victim?.name ?? "?")}</strong>${
                third ? ` · ${game.i18n.format("DRPG.Murder.thirdIs", {
                    name: foundry.utils.escapeHTML(third.name)
                })}` : ""}</p>
            <p>${game.i18n.format("DRPG.Murder.trackerState", {
                stage: game.i18n.localize(`DRPG.Murder.stage.${state.stage}`),
                turn: state.turn,
                side: game.i18n.localize(`DRPG.Murder.side.${state.turnSide}`)
            })}</p>
            <p>${game.i18n.format("DRPG.Murder.victimLeft", {
                hp: left("hitPoints"), stress: left("stress")
            })}</p>
            <p>${game.i18n.format("DRPG.Murder.keyCount", { n: state.keyRemnants })}</p>
        </div>`),
        buttons: [
            // Stage 4 has its own two buttons. Without them the murder opened
            // and then sat there: the state says "openingRoll" and nothing in
            // the module was rolling it.
            ...(state.stage === "openingRoll" ? [
                { action: "rollKiller", label: game.i18n.localize("DRPG.Murder.rollKiller"),
                  default: true },
                { action: "rollVictim", label: game.i18n.localize("DRPG.Murder.rollVictim") }
            ] : [
                { action: "pass", label: game.i18n.localize("DRPG.Murder.passTurn"), default: true },
                { action: "third", label: game.i18n.localize("DRPG.Murder.addThird") }
            ]),
            { action: "end", label: game.i18n.localize("DRPG.Murder.endMurder") },
            { action: "close", label: game.i18n.localize("DRPG.Panel.close") }
        ],
        rejectClose: false
    });

    if (action === "rollKiller" || action === "rollVictim") {
        await rollOpening(action === "rollKiller" ? "killer" : "victim", state);
        return openIncidentTracker();
    }
    if (action === "pass") {
        await passTurn();
        return openIncidentTracker();
    }
    if (action === "third") {
        const { livingStudents } = await import("./chapter.mjs");
        const others = livingStudents().filter(a =>
            a.id !== state.killerId && a.id !== state.victimId);
        if (!others.length) {
            ui.notifications.warn(game.i18n.localize("DRPG.Murder.nobodyElse"));
            return openIncidentTracker();
        }
        const id = await DialogV2.wait({
            window: { title: game.i18n.localize("DRPG.Murder.addThird") },
            content: `<form><label>${game.i18n.localize("DRPG.Murder.whoWalkedIn")}
                <select name="who">${others.map(a =>
                    `<option value="${a.id}">${foundry.utils.escapeHTML(a.name)}</option>`
                ).join("")}</select></label></form>`,
            buttons: [
                {
                    action: "ok", label: game.i18n.localize("DRPG.Panel.apply"), default: true,
                    callback: (e, b, d) => d.element.querySelector("[name=who]").value
                },
                { action: "cancel", label: game.i18n.localize("DRPG.Advance.cancel") }
            ],
            rejectClose: false
        });
        if (id && id !== "cancel") await thirdPartyEnters(game.actors.get(id));
        return openIncidentTracker();
    }
    if (action === "end") {
        const sure = await DialogV2.confirm({
            window: { title: game.i18n.localize("DRPG.Murder.endMurder") },
            content: `<p>${game.i18n.localize("DRPG.Murder.endConfirm")}</p>`
        });
        if (sure) await endMurder();
    }
    return null;
}
