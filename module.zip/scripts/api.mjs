/**
 * Danganronpa RPG — public API.
 * ---------------------------------------------------------------------------
 * Everything macros and journal buttons are allowed to call hangs off
 * `game.drpg`. Treat this as the stable surface: internal files may be
 * reshuffled between stages, this object should not break.
 */

import { DRPG, MODULE_ID, TRAITS, TRAIT_BY_DH } from "./config.mjs";
import { SETTINGS, getSetting, setSetting } from "./settings.mjs";
import { SearchTokens } from "./search-tokens.mjs";
import { getUltimate, setUltimate, findDuplicateUltimates } from "./sheet.mjs";
import { openAdvancement, openAdvancementFor, applyAdvancement } from "./level-up.mjs";
import { auditAnonymity, explainOwnership } from "./anonymity.mjs";
import {
    getClock,
    setClock,
    clockSummary,
    timeOfDayLabel,
    phaseLabel,
    campaignName,
    setPhase,
    advanceTimeOfDay,
    rewindTimeOfDay,
    setTimeOfDay
} from "./clock.mjs";
import { renderHud } from "./hud.mjs";
import {
    monokumas,
    getDespair,
    setDespair,
    adjustDespair,
    fillAllDespair,
    spendDespairCall,
    despairMax,
    renderDespairBar,
    poolLabel,
    setPoolLabel,
    poolCandidates,
    addPool,
    removePool,
    convertDespairToHope
} from "./despair.mjs";
import {
    monokumaFor,
    studentsOf,
    students,
    assignments,
    assign,
    setAssignments,
    autoAssign,
    unassigned,
    pruneAssignments,
    feedsNobody,
    excludedStudents,
    NO_MONOKUMA
} from "./assignments.mjs";
import { diagnoseDice, diagnoseDespair, diagnoseStyles, diagnoseTruthBullets } from "./diagnostics.mjs";
import { performAction, currentRoom } from "./action-rolls.mjs";
import { installTables, drawItem, randomItem, tableName } from "./tables.mjs";
import { roomOfActor, roomOfToken, othersInRoom, allRooms, neighbouringRooms, occupantsOf } from "./movement.mjs";
import { applyAll as refreshRoomVisibility, visibleCharacters } from "./visibility.mjs";
import { remnantData, reportRemnants } from "./remnants.mjs";
import {
    allProjects, visibleProjects, canSee, projectsAvailableIn, addProgress, setProjectMeta,
    makeSecret, shareWith, unshareWith, revealProject, isSecret, viewersOf
} from "./projects.mjs";
import { openProjectManager, openShareDialog } from "./projects-ui.mjs";
import { callGm } from "./gm-bridge.mjs";
import { takeRest, roomAllows, restRooms, setRestRoom, openRestRoomsDialog } from "./rest.mjs";
import {
    dropRemnant, placeRemnant, remnantsOn, remnantsInRoom, rankForObserve,
    revealRemnant, removeRemnant, clearFaintRemnants,
    setRemnantFlags, openRemnantManager
} from "./remnants.mjs";
import { chooseObserveTarget, resolveObserve, clearPendingObserves } from "./observe.mjs";
import { resolveAnalyze } from "./analyze.mjs";
import { shareBullet, giveItem, shareBulletDialog, giveItemDialog } from "./handover.mjs";
import {
    presentBullet, presentDialog, presentedThisChapter, openObjectionLog, inClassTrial
} from "./trial.mjs";
import {
    isDeceased, deathRecord, livingStudents, killCharacter, reviveCharacter,
    discoverBody, revealAllBulletTypes, sweepTruthBullets,
    openDeathDialog, openBodyDiscoveryDialog, openChapterEndDialog
} from "./chapter.mjs";
import {
    keyPlan, setKeyPlan, keyPlanStatus, awardMissingKeyDespair,
    openKeyPlanner, openInvestigationDashboard
} from "./investigation.mjs";
import {
    trialQueue, speaker, secondsLeft, startFloor, nextSpeaker, seizeFloor, endFloor
} from "./trial-floor.mjs";
import { openVote, closeVote, applyVerdict, openVerdictDialog } from "./vote.mjs";
import {
    murderState, sideOf, isTheirTurn, availableCrisisActions,
    openMurder, resolveKillerOpening, resolveVictimOpening,
    takeCrisisAction, resolveCrisisAction, passTurn, thirdPartyEnters, endMurder,
    openMurderDialog, openIncidentTracker
} from "./murder.mjs";
import {
    isMonocub, monocubActors, eligibleForMonocub, setMonocub, setSilenced, isSilenced,
    meddleTargets, performMeddle, resolveMeddle, meddleDialog,
    openMonocubDialog
} from "./monocub.mjs";
import {
    mastermindActor, isMastermind, setMastermind, clearMastermind,
    finalTruthPlacedThisChapter, inFinalTrial, setFinalTrial,
    openMastermindDialog, openFinalVerdictDialog, applyFinalVerdict
} from "./mastermind.mjs";
import {
    grantItem, canCarry, countInCategory, itemsInCategory, carriedInCategory,
    inventorySummary, isStashed, locationOf
} from "./inventory.mjs";
import {
    vaultRoomFor, vaultOwnerOf, vaultContents, allVaults, isConcealed,
    roomTable, roomFavours, favoursCategory, setVaultRoom,
    stow, retrieve, stealFromVault, openRoomSetupDialog, openVaultInspector,
    openStashHere, rifleStashDialog
} from "./vault.mjs";
import {
    useItem, toggleEquipped, isUsable, isEquippable, isEquipped, equippedIn,
    grantItemEffect
} from "./use-items.mjs";
import { syncStates, syncAll as syncAllStates } from "./states.mjs";
import { openItemManager, issueAutopsyDialog } from "./gm-items.mjs";
import {
    createTruthBullet, truthBulletData, bulletsOf, isTruthBullet,
    isAnalysable, analysableBullets,
    issueAutopsy, migrateTruthBullets, secretOf, setSecret, dropSecret,
    exportLedger, importLedger
} from "./truth-bullets.mjs";
import { installHandbook } from "./handbook.mjs";
import {
    isMonokuma, setMonokuma, monokumaActors, studentActors,
    poolUserFor, poolFor, setPoolFor, monokumasWithoutPool
} from "./monokuma.mjs";
import { openGmTeamDialog } from "./gm-team-dialog.mjs";
import { spendHopeCall, spendDespairCallFor, hopeHeld, affordableHopeCalls, despairCallsFor } from "./calls.mjs";
import { openMessenger } from "./messenger-app.mjs";
import {
    sendMessage as sendMessengerMessage,
    threadMessages as messengerThreadMessages,
    totalUnread as messengerUnreadTotal
} from "./messenger.mjs";
import {
    scheduleReconcile as reconcileVoice,
    eavesdropRoom,
    stopEavesdropping,
    resetAllVoice,
    openEavesdropDialog as voiceEavesdropDialog
} from "./voice.mjs";
import { startEclipse, endEclipse, isEclipse, movesLeft, placementStatus } from "./eclipse.mjs";
import { createProject, deleteProject, updateProject } from "./projects.mjs";
import {
    actionBudget,
    actionsLeft,
    actionsMax,
    spendAction,
    refundAction,
    setActions,
    resetActionsFor,
    resetAllActions,
    hasFreeMove,
    takeMove,
    restoreFreeMove
} from "./actions.mjs";
import { openGmPanel, openClockDialog } from "./gm-panel.mjs";
import {
    initCharacter,
    resourceMax,
    resourceValue,
    remaining,
    isBrokenDown,
    isWounded,
    validateTraitSpread,
    listExperiences
} from "./character.mjs";
import {
    ownerOf,
    whisperToOwner,
    whisperToGms,
    gmIds,
    activeGmIds,
    isPrimaryGm,
    resolveThreshold,
    clamp,
    log
} from "./utils.mjs";

export const DrpgApi = {
    /** Static rules data straight from the guide. */
    config: DRPG,

    /** Module id, handy when writing flags from a macro. */
    id: MODULE_ID,

    /* ---- traits -------------------------------------------------------- */

    /** Map a DRPG trait key ("eye") to the Daggerheart key ("instinct"). */
    traitKey(drpgKey) {
        return TRAITS[drpgKey]?.dh ?? drpgKey;
    },

    /** Map a Daggerheart trait key ("instinct") back to DRPG ("eye"). */
    traitFromDh(dhKey) {
        return TRAIT_BY_DH[dhKey] ?? dhKey;
    },

    /** Current value of a DRPG trait on an actor. */
    traitValue(actor, drpgKey) {
        const dh = this.traitKey(drpgKey);
        return actor?.system?.traits?.[dh]?.value ?? 0;
    },

    /* ---- characters ---------------------------------------------------- */

    /** Write the guide's starting resources onto an actor: HP 4, Stress 6, Hope 2. */
    initCharacter,

    /** Read/write the Ultimate shown under the character's name. */
    getUltimate,
    setUltimate,

    /** Every Ultimate that appears on more than one character this season. */
    findDuplicateUltimates,

    /** Resource readers. HP and Stress are reverse resources — see character.mjs. */
    resourceMax,
    resourceValue,
    remaining,
    isBrokenDown,
    isWounded,

    /** Does this actor's trait spread match +2/+1/+1/0/0/-1? Reports only. */
    validateTraitSpread,
    listExperiences,

    /* ---- advancement --------------------------------------------------- */

    /** Open the Advancement dialog. kind: "standard" (pick 1) or "reinforced" (pick 3). */
    advance: openAdvancement,

    /** Ask which advancement was earned first. This is what the sheet button uses. */
    advanceFor: openAdvancementFor,
    applyAdvancement,

    /* ---- safety -------------------------------------------------------- */

    /** Report every character sheet that is visible to the wrong people. */
    auditAnonymity,

    /** Who can open this sheet, at what level, and with what user role. */
    explainOwnership,

    /* ---- clock --------------------------------------------------------- */

    /** Campaign name / chapter / phase / session / time of day. */
    getClock,
    setClock,
    clockSummary,
    timeOfDayLabel,
    phaseLabel,
    campaignName,

    /** Phase: "dailyLife" | "investigation" | "classTrial". */
    setPhase,

    /** Move to the next time of day: refills actions, free Moves, search tokens. */
    advanceTimeOfDay,

    /** Step back one time of day. A correction — refills nothing. */
    rewindTimeOfDay,
    setTimeOfDay,

    /** Open the GM panel (also on the token toolbar as a clock icon). */
    gmPanel: openGmPanel,

    /** Open the clock editor (also the gear on the HUD). */
    editClock: openClockDialog,

    /** Force the top-of-screen HUD to redraw. */
    renderHud,

    /* ---- despair ------------------------------------------------------- */

    /** Full Gamemasters only — Assistant GMs do not get a Monokuma pool. */
    monokumas,
    despairMax,
    getDespair,
    setDespair,
    adjustDespair,

    /** Top every Monokuma up to 12 — the guide does this after a wrong vote. */
    fillAllDespair,

    /** Pay for one of the guide's Despair Calls and announce it. */
    spendDespairCall,
    renderDespairBar,

    /** A pool's display label — custom if set, the account name otherwise —
     *  and the controls to rename a pool or grant/revoke one for an
     *  Assistant GM. Also on the GM team panel. */
    poolLabel,
    setPoolLabel,
    poolCandidates,
    addPool,
    removePool,

    /* ---- student division ---------------------------------------------- */

    /** Which Monokuma looks after this character (falls back to the first). */
    monokumaFor,

    /** Characters carried by one Monokuma. */
    studentsOf,
    students,
    assignments,
    assign,
    setAssignments,

    /** Split every student evenly between Monokumas, in name order. */
    autoAssign,
    unassigned,
    pruneAssignments,

    /** Assign an actor to NO_MONOKUMA to keep them out of every Despair pool. */
    NO_MONOKUMA,
    feedsNobody,
    excludedStudents,

    /* ---- actions as abilities ------------------------------------------ */

    /** Run one of the guide's actions end to end: roll, resolve, apply, report. */
    performAction,

    /** Which room region the character's token is standing in. */
    currentRoom,
    roomOfActor,
    roomOfToken,
    othersInRoom,
    allRooms,

    /** Rooms adjacent to this one — used by Listen. */
    neighbouringRooms,
    occupantsOf,

    /** Recompute who each player can see. GMs always see everything. */
    refreshRoomVisibility,
    visibleCharacters,

    /* ---- projects ------------------------------------------------------ */

    /** Countdowns, plus the room and secrecy Daggerheart does not model. */
    allProjects,

    /** The same list, minus every secret project this user may not know about.
        Anything shown to a player must come from here, never `allProjects`. */
    visibleProjects,
    canSee,
    projectsAvailableIn,
    addProgress,
    setProjectMeta,
    createProject,

    /** Rename, re-scale, re-room or re-portrait a project without losing its
     *  progress or its id — everything pointing at it keeps pointing at it. */
    updateProject,
    deleteProject,

    /** Indirect murder projects are secret by default. */
    makeSecret,
    revealProject,
    isSecret,
    viewersOf,
    shareProject: shareWith,
    unshareProject: unshareWith,

    /** Dialogs: rooms and secrecy, and letting a co-conspirator in. */
    manageProjects: openProjectManager,
    shareProjectDialog: openShareDialog,

    /** Whisper a ruling request to the GMs. */
    callGm,

    /* ---- rest ---------------------------------------------------------- */

    /** Short rest: 1 action, pick 1. Long rest: 2 actions, pick 2, bedroom only. */
    takeRest,
    roomAllows,
    restRooms,
    setRestRoom,

    /** Mark which rooms on this scene allow which rest. */
    manageRestRooms: openRestRoomsDialog,

    /* ---- remnants & inventory ------------------------------------------ */

    /** Drop a Remnant where a character stands: hidden, translucent, under tokens. */
    dropRemnant,
    placeRemnant,
    remnantsOn,
    remnantsInRoom,
    revealRemnant,
    removeRemnant,

    /** Everything recorded on a Remnant: type, visibility, who left it, when. */
    remnantData,
    reportRemnants,

    /** Chapter end: clear Faint Remnants that are neither reinforced nor tied to the crime. */
    clearFaintRemnants,

    /** Edit which Remnants survive the chapter. Also on the GM panel. */
    manageRemnants: openRemnantManager,
    setRemnantFlags,

    /** Give or take an item, as the GM. Also on the sheet and the GM panel. */
    manageItems: openItemManager,

    /** Put a found item on a character, respecting the guide's carry limits. */
    grantItem,
    canCarry,
    countInCategory,
    itemsInCategory,
    carriedInCategory,
    inventorySummary,

    /* ---- the stash --------------------------------------------------------
     * A stashed item is an ordinary item on its owner's sheet with a `location`
     * flag — which is why the death procedure empties stashes without knowing
     * they exist. Uncapped; the carry limit only measures what is in hand. */

    isStashed,
    locationOf,
    vaultRoomFor,
    vaultOwnerOf,
    vaultContents,
    allVaults,
    isConcealed,

    /** Free, no roll, and only from inside the room itself. */
    stow,
    retrieve,

    /** Search found somebody else's hiding place. GM-side. */
    stealFromVault,

    /** An UNCONCEALED stash in the room you are standing in is just a drawer:
     *  free to go through, no roll. A concealed one still needs a Search. */
    openStashHere,
    rifleStash: rifleStashDialog,

    /* ---- using what you carry ---------------------------------------------
     * Neither costs an action — the guide charges for finding and making
     * things, not for opening them. */

    /** Spend a Usable Item. Tier 1/2 ask HP or Stress; tier 3 gives all three;
     *  tier 0 is "open to creative use" and goes to the GM as a ruling. */
    useItem,

    /** Hold one Crime Tool or Cleaning Tool ready. One per category — this is
     *  what the incident engine reads before falling back to "the best you own". */
    toggleEquipped,
    equippedIn,
    isUsable,
    isEquippable,
    isEquipped,

    /** Finish a Tier 0 creative use the GM has agreed to. */
    grantItemEffect,

    /* ---- Breakdown and Wounded --------------------------------------------
     * The guide's two player states, replacing Daggerheart's Vulnerable and
     * Death Move. Applied automatically; these are for a manual re-check. */

    syncStates,
    syncAllStates,

    /* ---- what a room is ---------------------------------------------------
     * Which table it draws from, and what it is a sensible place to look for. */

    roomTable,
    roomFavours,
    favoursCategory,
    setVaultRoom,

    /** Owner, concealment, table and favoured categories, on one screen. */
    roomSetup: openRoomSetupDialog,
    inspectVaults: openVaultInspector,

    /* ---- Truth Bullets --------------------------------------------------
     * A bullet is split in two: the Item the player holds carries only what
     * they may know, and what it REALLY is lives in a GM-side ledger that is
     * never sent to a player's client. `truthBulletData` merges the halves the
     * caller is entitled to — for a player, that is one half. */

    /** The single creation path: Observe, the GM dialog and macro 03 all use it. */
    createTruthBullet,
    truthBulletData,
    bulletsOf,
    isTruthBullet,

    /** Hand the Autopsy bullet to everyone still alive (decision D2). */
    issueAutopsy,
    issueAutopsyDialog,

    /** The GM-side answer key. `secretOf` returns {} for anyone who is not a GM. */
    secretOf,
    setSecret,
    dropSecret,

    /** The ledger lives in browser storage, so it can be backed up and restored. */
    exportLedger,
    importLedger,

    /** Bring bullets made before Stage 1 up to the current shape. Idempotent. */
    migrateTruthBullets,

    /* ---- Observe --------------------------------------------------------
     * Resolved on the GM's client, never the observer's: the room's Remnants
     * and their difficulties are exactly what the player must not know. */

    /** The Remnants in a room as Observe ranks them: crime-tied first, then easiest. */
    rankForObserve,

    /** GM side: fix a target before the roll, then score the roll against it. */
    chooseObserveTarget,
    resolveObserve,
    clearPendingObserves,

    /* ---- Analyze --------------------------------------------------------
     * Also GM-side: the difficulty is read from what the bullet really is,
     * which is the very thing the roll is trying to buy. */

    /** Can this bullet still be worked on, or is it identified / locked this chapter? */
    isAnalysable,
    analysableBullets,

    /** GM side: convert the bullet, or lock it for the rest of the chapter. */
    resolveAnalyze,

    /* ---- passing things on ----------------------------------------------
     * Same room, no action. A Truth Bullet is copied — the giver keeps theirs;
     * an item is moved and the giver loses it. */

    shareBullet,
    giveItem,

    /** The pickers the inventory buttons open. */
    shareBulletDialog,
    giveItemDialog,

    /* ---- Class Trial ----------------------------------------------------
     * A presentation is one object seen two ways: a public ChatMessage that is
     * the trial's record, and a popup every client raises from it. */

    presentBullet,
    presentDialog,
    inClassTrial,

    /** Who put what in front of the table, newest first. Also on the GM panel. */
    presentedThisChapter,
    objectionLog: openObjectionLog,

    /* ---- the chapter's life -----------------------------------------------
     * None of these fire on a clock tick. Two of them delete things that do not
     * come back, and "the chapter has ended" is a judgement about the fiction,
     * not a number changing. Every one is a GM button. */

    /** The dead stay on the map but stop counting as being in the room. */
    isDeceased,
    deathRecord,
    livingStudents,

    /** D1 in one procedure: inventory and Truth Bullets destroyed, body marked. */
    killCharacter,

    /** Un-mark a mis-click. Does NOT bring the destroyed inventory back. */
    reviveCharacter,

    /** Promote the traces, call everyone in, switch to Investigation. */
    discoverBody,

    /** Chapter's end: every bullet gives up what it really was. */
    revealAllBulletTypes,

    /** New session: clear the evidence out, Faint excepted. */
    sweepTruthBullets,

    /** The dialogs behind the GM panel's entries. */
    deathDialog: openDeathDialog,
    bodyDiscoveryDialog: openBodyDiscoveryDialog,
    chapterEndDialog: openChapterEndDialog,

    /* ---- the GM's Investigation workshop -----------------------------------
     * Five clues, scaled trivial to desperate, and a read-out of who has
     * reached what. GM-only in the strongest sense: it reads the answer key in
     * bulk, and the answer key only exists on a GM's browser. */

    keyPlan,
    setKeyPlan,

    /** The plan scored against the map and the players' sheets. */
    keyPlanStatus,

    /** The guide's penalty for a case nobody could solve. A button, not a trigger. */
    awardMissingKeyDespair,

    keyPlanner: openKeyPlanner,
    investigationDashboard: openInvestigationDashboard,

    /* ---- the murder engine -------------------------------------------------
     * Two opening rolls, then a turn-based incident. The module owns the
     * numbers — thresholds, the drain, turn order, damage, which Remnants each
     * outcome leaves — and hands the prose to the GM. */

    murderState,
    sideOf,
    isTheirTurn,
    availableCrisisActions,

    openMurder,
    resolveKillerOpening,
    resolveVictimOpening,

    /** The participant's own roll, and the GM-side scoring behind it. */
    takeCrisisAction,
    resolveCrisisAction,

    passTurn,
    thirdPartyEnters,
    endMurder,

    murderDialog: openMurderDialog,
    incidentTracker: openIncidentTracker,

    /* ---- Monocub -----------------------------------------------------------
     * A dead student's player, opted in after their trial. Same actor, same
     * action budget, restricted to Move and Meddle. Meddle's flat 2d12 has no
     * trait behind it — the guide's own "Stat: —" — and its effect reuses the
     * same Call machinery Support and Obstacle already use. */

    isMonocub,
    monocubActors,
    eligibleForMonocub,

    /** Opt in or out. Only ever on a character already marked dead. */
    setMonocub,

    /** The guide's "stumbled onto the crime" ban, until the chapter ends. */
    setSilenced,
    isSilenced,

    /** GM-driven: spend a Monokuma's Despair to give somebody Hope, 1:1.
     *  Shared with the Mastermind below — the guide gives both the same trade. */
    convertDespairToHope,

    meddleTargets,
    meddleDialog,
    performMeddle,
    resolveMeddle,

    monocubDialog: openMonocubDialog,

    /* ---- the Mastermind -----------------------------------------------------
     * The one secret this module treats as more sensitive than a Truth
     * Bullet's real type: never an actor flag, never world data. It lives in a
     * client-scoped setting on GM browsers only — see the note on
     * SETTINGS.mastermind for why a flag would have been a real leak. */

    /** `null` for anyone who is not a GM. Never guess otherwise. */
    mastermindActor,
    isMastermind,
    setMastermind,
    clearMastermind,

    /** The guide's "co rozdział" cadence check — informational only. */
    finalTruthPlacedThisChapter,

    /** Flavour flag only: everyone already knows a Final Trial is happening. */
    inFinalTrial,
    setFinalTrial,

    mastermindDialog: openMastermindDialog,
    finalVerdictDialog: openFinalVerdictDialog,
    applyFinalVerdict,

    /* ---- the Class Trial ---------------------------------------------------
     * The floor is a shared clock in world data. The ballots are not: they are
     * addressed to the GMs over the socket and counted in memory, because
     * "wyniki jawne, głosy nie" and world data is not private (D6). */

    trialQueue,
    trialSpeaker: speaker,
    trialSecondsLeft: secondsLeft,
    startFloor,
    nextSpeaker,

    /** An OBJECTION calls this by itself — presenting evidence takes the floor. */
    seizeFloor,
    endFloor,

    openVote,
    closeVote,
    applyVerdict,
    verdictDialog: openVerdictDialog,

    /** Item pools and the RollTables built from them. */
    installTables,
    drawItem,
    randomItem,
    tableName,

    /* ---- diagnostics --------------------------------------------------- */

    /** Why are the dice unskinned? Why is no Despair being awarded? */
    diagnoseDice,
    diagnoseDespair,

    /** Why does the sheet look different here than on another install? */
    diagnoseStyles,

    /** Are the bullets and their answer key still in step, and do the rows render? */
    diagnoseTruthBullets,

    /* ---- Monokumas ----------------------------------------------------- */

    /** A Monokuma is a character actor with a flag: no actions, no Hope. */
    isMonokuma,
    setMonokuma,
    monokumaActors,
    studentActors,

    /** Which GM's Despair pool a Monokuma actor draws on. */
    poolUserFor,
    poolFor,
    setPoolFor,

    /** Monokumas nobody has pointed at a pool yet. */
    monokumasWithoutPool,

    /** Mark actors as Monokumas, say whose Despair each spends, and divide
     *  students between Monokumas — one combined panel, GM panel only. */
    gmTeamPanel: openGmTeamDialog,

    /* ---- calls --------------------------------------------------------- */

    /** Hope Calls for players, Despair Calls for Monokumas. */
    spendHopeCall,
    spendDespairCallFor,
    hopeHeld,
    affordableHopeCalls,
    despairCallsFor,

    /* ---- eclipse ------------------------------------------------------- */

    /** The placement window between two times of day. Never counts as a day. */
    startEclipse,
    endEclipse,
    isEclipse,
    eclipseMovesLeft: movesLeft,
    placementStatus,

    /* ---- documentation -------------------------------------------------- */

    /**
     * Build the in-world handbook: how to set up a season, where every control
     * lives, and how to add your own items. Also on the GM panel.
     */
    installHandbook,

    /* ---- actions ------------------------------------------------------- */

    /** 2 per time of day, or 1 while all HP is marked. */
    actionBudget,
    actionsLeft,
    actionsMax,
    spendAction,
    refundAction,
    setActions,
    resetActionsFor,
    resetAllActions,

    /** One free Move per time of day; further Moves cost an action. */
    hasFreeMove,
    takeMove,
    restoreFreeMove,

    /* ---- search tokens ------------------------------------------------- */

    searchTokens: SearchTokens,

    /** Shorthands kept for the existing GM macros. */
    tokensLeft: roomName => SearchTokens.left(roomName),
    useToken: roomName => SearchTokens.spend(roomName),
    resetTokens: () => SearchTokens.reset(),
    showTokens: () => SearchTokens.report(),

    /* ---- chat ---------------------------------------------------------- */

    ownerOf,
    whisperToOwner,
    whisperToGms,
    gmIds,
    activeGmIds,
    isPrimaryGm,

    /* ---- messenger ------------------------------------------------------
     * One shared thread per player: the player and every current GM read and
     * write into the same conversation. callGm() (above) posts its ruling
     * requests into these same threads. */

    /** Open (or focus) a player's GM-chat window. Defaults to your own. */
    openMessenger,
    sendMessengerMessage,
    messengerThreadMessages,
    messengerUnreadTotal,

    /* ---- voice ----------------------------------------------------------
     * Regions become LiveKit breakout rooms via avclient-livekit, if it is
     * installed, active, and the world setting is on. Every function here is
     * a safe no-op otherwise. */

    /** Re-check every player's room and reassign voice now, skipping the debounce. */
    reconcileVoice,

    /** Join a room's voice channel as a muted listener. `null` leaves it. */
    eavesdropRoom,
    stopEavesdropping,

    /** Send everyone currently assigned back to the main room. */
    resetAllVoice,

    /** Open the room picker (also on the GM panel's "More…" menu). */
    voiceEavesdropDialog,

    /* ---- misc ---------------------------------------------------------- */

    resolveThreshold,
    clamp,

    settings: {
        keys: SETTINGS,
        get: getSetting,
        set: setSetting
    }
};

export function registerApi() {
    game.drpg = DrpgApi;
    log(`API ready on game.drpg — system: ${game.system.id} ${game.system.version}, Foundry: ${game.version}`);
}
