/**
 * Danganronpa RPG — item tables.
 * ---------------------------------------------------------------------------
 * The guide gives one or two examples per tier and tells the GM to improvise
 * the rest. These lists are that improvisation done in advance, so a Search
 * never stalls waiting for someone to invent a mop.
 *
 * Everything here is deliberately mundane and school-shaped: the horror in a
 * killing game comes from what students do with ordinary objects.
 *
 * Installed into the world as RollTables by `installTables()`, which the GM can
 * then edit freely — once they exist, these definitions are only a fallback.
 */

import { MODULE_ID, ITEM_CATEGORIES, TIER_EFFECTS } from "./config.mjs";
import { log } from "./utils.mjs";

/** Table name pattern: "DRPG Usable Items — Tier 2", or "… (Healing) — Tier 2". */
export function tableName(category, tier, goal = null) {
    const base = ITEM_CATEGORIES[category]?.plural ?? category;
    const suffix = USABLE_GOALS[goal] ? ` (${USABLE_GOALS[goal].label})` : "";
    return `DRPG ${base}${suffix} — Tier ${tier}`;
}

/**
 * Usable items, split by what the player was looking for.
 *
 * The guide's tier text says an item "restores 1 point of HP *or* Stress" — one
 * object, either use. But the player declares which they want before rolling,
 * and handing someone chewing gum when they asked for something to patch a cut
 * reads as a bug even when it is rules-legal. So the guide's own examples are
 * sorted by which they obviously are: food and medicine mend the body, calming
 * things settle the nerves.
 *
 * Tier 3 appears in both because the guide's Tier 3 usable restores HP, Stress
 * and Hope at once.
 */
export const USABLE_GOALS = {
    healing: {
        label: "Healing",
        pool: {
            0: ["Spoiled cheese", "Half a sandwich"],
            1: ["Apple", "Cereal bar"],
            2: ["Canned soup", "First aid kit"],
            3: ["Candy floss"]
        }
    },
    stress: {
        label: "Stress Relief",
        pool: {
            0: ["Fidget spinner", "Torn magazine"],
            1: ["Chewing gum", "Cold tea"],
            2: ["Pills", "Music player"],
            3: ["Candy floss"]
        }
    }
};

/**
 * Item pools, keyed by category then tier.
 *
 * These are the guide's own examples, translated, and nothing else. The guide
 * is explicit that it "does not supply a list of items" and that the GM should
 * improvise — so this stays a short, faithful seed rather than an invented
 * catalogue. Add your own by editing the RollTables in the world; the module
 * reads those first.
 *
 * Tier 0 is "a random, seemingly useless object, open to creative use".
 */
export const ITEM_POOLS = {
    usable: {
        0: ["Spoiled cheese", "Fidget spinner"],
        1: ["Apple", "Chewing gum"],
        2: ["Canned soup", "Pills"],
        3: ["Candy floss"]
    },
    crimeTool: {
        0: ["Scissors"],
        1: ["Bent pipe"],
        2: ["Axe"],
        3: ["Handgun"]
    },
    cleaningTool: {
        0: ["Toilet paper"],
        1: ["Rope"],
        2: ["Mop"],
        3: ["Cleaning agent"]
    }
};

/**
 * Items the guide names as project results rather than search finds. Offered to
 * the GM as suggestions; not part of the Search tables.
 */
export const PROJECT_ITEMS = {
    3: [
        { name: "Sleeping draught", note: "Restores 3 Stress, or puts a victim to sleep." },
        { name: "Lethal poison", note: "A Desperate project." },
        { name: "Gift", note: "Must be handed over immediately. Grants the maker 3 Hope." }
    ]
};

/** One random item name for a category and tier. */
export function randomItem(category, tier, goal = null) {
    const goalPool = USABLE_GOALS[goal]?.pool;
    const pool = goalPool?.[tier] ?? goalPool?.[0]
        ?? ITEM_POOLS[category]?.[tier] ?? ITEM_POOLS[category]?.[0] ?? [];
    if (!pool.length) return null;
    return pool[Math.floor(Math.random() * pool.length)];
}

/**
 * Roll on the world's table if one exists, otherwise fall back to the built-in
 * pool. The GM editing a table has to actually change what Search produces.
 *
 * @returns {Promise<{name: string, fromTable: boolean}|null>}
 */
export async function drawItem(category, tier, { goal = null } = {}) {
    // A goal-specific table first, then the generic one for that category, so a
    // GM who never split their usable items still gets a result.
    const names = [tableName(category, tier, goal), tableName(category, tier)];

    for (const name of names) {
        const table = game.tables?.getName?.(name);
        if (!table) continue;
        try {
            const draw = await table.draw({ displayChat: false });
            const result = draw?.results?.[0];
            const drawn = result?.name ?? result?.text ?? result?.description;
            if (drawn) return { name: drawn, fromTable: true };
        } catch {
            // A broken table should not stop the action — fall through.
        }
    }

    const picked = randomItem(category, tier, goal);
    return picked ? { name: picked, fromTable: false } : null;
}

/**
 * Create the RollTables in the world. Idempotent: tables that already exist are
 * left alone, so a GM's edits are never overwritten.
 */
export async function installTables({ overwrite = false } = {}) {
    if (!game.user.isGM) {
        ui.notifications.warn(game.i18n.localize("DRPG.Panel.gmOnly"));
        return null;
    }

    let folder = game.folders.find(f => f.type === "RollTable" && f.name === "Danganronpa RPG");
    if (!folder) {
        folder = await Folder.create({ name: "Danganronpa RPG", type: "RollTable", color: "#9d4edd" });
    }

    const created = [];
    const skipped = [];

    // Crime tools, cleaning tools and the generic usable list, plus one table
    // per usable goal so a GM can curate "what mends you" separately from
    // "what calms you down".
    const jobs = [
        ...Object.entries(ITEM_POOLS).flatMap(([category, tiers]) =>
            Object.entries(tiers).map(([tier, names]) => ({ category, tier, names, goal: null }))),
        ...Object.entries(USABLE_GOALS).flatMap(([goal, { pool }]) =>
            Object.entries(pool).map(([tier, names]) => ({ category: "usable", tier, names, goal })))
    ];

    {
        for (const { category, tier, names, goal } of jobs) {
            const name = tableName(category, tier, goal);
            const existing = game.tables.getName(name);

            if (existing && !overwrite) {
                skipped.push(name);
                continue;
            }
            if (existing && overwrite) await existing.delete();

            await RollTable.create({
                name,
                folder: folder.id,
                description: `${ITEM_CATEGORIES[category]?.label ?? category}, Tier ${tier}. ${TIER_EFFECTS[category]?.[tier] ?? ""}`,
                formula: `1d${names.length}`,
                replacement: true,
                displayRoll: false,
                flags: { [MODULE_ID]: { category, tier: Number(tier), goal } },
                results: names.map((text, index) => ({
                    type: CONST.TABLE_RESULT_TYPES?.TEXT ?? "text",
                    text,
                    name: text,
                    range: [index + 1, index + 1],
                    weight: 1
                }))
            });
            created.push(name);
        }
    }

    log(`Item tables: ${created.length} created, ${skipped.length} left alone.`);
    ui.notifications.info(game.i18n.format("DRPG.Tables.installed", {
        created: created.length,
        skipped: skipped.length
    }));

    return { created, skipped };
}
