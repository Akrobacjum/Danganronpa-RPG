/**
 * Danganronpa RPG — the in-world handbook.
 * ---------------------------------------------------------------------------
 * Every feature this module adds is documented here, as a Journal the GM can
 * open at the table. Built from the live configuration, so the numbers in the
 * text are the numbers the code actually uses.
 *
 * Rebuild it after an update with: game.drpg.installHandbook({ overwrite: true })
 */

import {
    ACTIONS, ITEM_CATEGORIES, PROJECT_SCALE, STARTING, REST, HOPE_CALLS, DESPAIR_CALLS,
    REMNANT_TYPES, TRUTH_BULLET_TYPES, OBSERVE_DC, ANALYZE_DC, OBSERVE_FAIL_STRESS, KEY_REMNANTS,
    MURDER_OPENING, INCIDENT, CRISIS_ACTIONS, TRIAL, MONOCUB,
    RESOLUTION_STRESS_COST
} from "./config.mjs";
import { ITEM_POOLS } from "./tables.mjs";
import { log } from "./utils.mjs";

const JOURNAL_NAME = "Danganronpa RPG — Handbook";

/**
 * Create (or refresh) the handbook journal.
 * @param {object} [options]
 * @param {boolean} [options.overwrite]  Replace an existing handbook.
 */
export async function installHandbook({ overwrite = false } = {}) {
    if (!game.user.isGM) {
        ui.notifications.warn(game.i18n.localize("DRPG.Panel.gmOnly"));
        return null;
    }

    const existing = game.journal.getName(JOURNAL_NAME);
    if (existing && !overwrite) {
        existing.sheet.render(true);
        return existing;
    }
    if (existing && overwrite) await existing.delete();

    let folder = game.folders.find(f => f.type === "JournalEntry" && f.name === "Danganronpa RPG");
    if (!folder) {
        folder = await Folder.create({ name: "Danganronpa RPG", type: "JournalEntry", color: "#9d4edd" });
    }

    const journal = await JournalEntry.create({
        name: JOURNAL_NAME,
        folder: folder.id,
        ownership: { default: CONST.DOCUMENT_OWNERSHIP_LEVELS.NONE },
        pages: buildPages()
    });

    log("Handbook installed.");
    ui.notifications.info(game.i18n.localize("DRPG.Handbook.installed"));
    journal?.sheet.render(true);
    return journal;
}

function page(name, html) {
    return { name, type: "text", title: { show: true, level: 1 }, text: { content: html, format: 1 } };
}

function buildPages() {
    return [
        page("1 · Setting up a season", setupPage()),
        page("2 · Rooms and the map", roomsPage()),
        page("3 · The GM panel", panelPage()),
        page("4 · Actions", actionsPage()),
        page("5 · Items and where to add your own", itemsPage()),
        page("6 · Projects", projectsPage()),
        page("7 · Remnants and Truth Bullets", remnantsPage()),
        page("8 · The Investigation: Observe, Analyze, evidence", investigationLoopPage()),
        page("9 · The stash, and what a room is", vaultPage()),
        page("10 · Despair and dividing the students", despairPage()),
        page("11 · Hope Calls and Despair Calls", callsPage()),
        page("12 · Death, the body, and the chapter's end", chapterLifePage()),
        page("13 · The Investigation workshop", investigationWorkshopPage()),
        page("14 · The murder", murderPage()),
        page("15 · The Class Trial", trialPage()),
        page("16 · Monocub", monocubPage()),
        page("17 · Mastermind and the Final Trial", mastermindPage()),
        page("18 · Console reference", consolePage())
    ];
}

/* ==========================================================================
 * PAGES
 * ========================================================================== */

function setupPage() {
    return `
    <h2>Finding the GM panel</h2>
    <p>Almost every control in this module lives behind one button. Here is exactly where it is:</p>
    <ol>
        <li>Look at the <strong>left edge of the screen</strong>, at the vertical strip of icons — the
            scene controls, where you switch between tokens, walls, lighting and so on.</li>
        <li>Click the <strong>token icon</strong> at the top (a person's head and shoulders). That opens
            the token tools underneath it.</li>
        <li>In that list of tools you will find a <strong>clock face icon</strong>
            (<i class="fa-solid fa-clock"></i>). That is the <strong>GM panel</strong>. Only GMs see it.</li>
    </ol>
    <p>Throughout this handbook, "GM panel" always means that clock icon. It opens as six labelled
       groups of tiles: <em>Right now</em>, <em>The case</em>, <em>The trial</em>, <em>The season</em>,
       <em>People and things</em>, <em>Season setup</em>, and a dimmer <em>If something is stuck</em>
       at the bottom. See page 3 for what is in each.</p>

    <h2>Setting up a season, step by step</h2>
    <ol>
        <li><strong>Draw the rooms.</strong> In the same left-hand strip of icons, find the
            <strong>Regions</strong> layer. Draw a shape over each room and <strong>give it a name</strong>
            ("Library", "Kitchen", "Dormitory"). An unnamed region does not count as a room.
            <br><em>Why it matters:</em> the module works out which room someone is in from these shapes.
            Searching, resting, projects, movement and the stash all depend on them.
            <br>The guide suggests about <em>players × 1.5</em> rooms.</li>

        <li><strong>Set up each room.</strong> GM panel → <em>Season setup</em> → <em>Room setup</em>.
            One screen, per room: whose bedroom it is (for the stash), whether that stash is hidden,
            which item table it draws from instead of the global pool, and which categories it is a
            sensible place to search for — advantage follows automatically. See page 9.</li>

        <li><strong>Say which rooms allow rest.</strong> GM panel → <em>Season setup</em> →
            <em>Choose which rooms allow rest</em>. Two tick boxes per room: Short Rest for common rooms,
            Long Rest for bedrooms.</li>

        <li><strong>Create the item tables.</strong> GM panel → <em>Season setup</em> →
            <em>Create item tables</em>. Until you click this, no item tables exist. See page 5.</li>

        <li><strong>Divide the students between GMs.</strong> GM panel → <em>Season setup</em> →
            <em>GM team</em>. The same screen marks Monokumas, points each one at a Despair pool, and
            splits the roster. See page 10.</li>

        <li><strong>Pick the Mastermind, privately.</strong> GM panel → <em>The season</em> →
            <em>The Mastermind</em>. Do this away from a shared screen — the whole point of this screen
            is that nobody else ever sees it. Agree the choice with that player first. See page 17.</li>

        <li><strong>Set the clock.</strong> Below the Despair bar is the campaign HUD — campaign name,
            chapter, day, phase, time of day. Its <strong>gear icon</strong> edits all of it.</li>

        <li><strong>Prepare each character.</strong> Select the character's token, then press
            <strong>F12</strong> to open the browser console and paste:
            <br><code>game.drpg.initCharacter(canvas.tokens.controlled[0].actor)</code>
            <br>That sets HP ${STARTING.hp}, Stress ${STARTING.stress} and Hope ${STARTING.hope}.
            Then type their Ultimate in the field under their name on the sheet.</li>

        <li><strong>Before the first murder: plan the Key Remnants.</strong> GM panel → <em>The case</em>
            → <em>Investigation dashboard</em> → <em>Plan the Key Remnants</em>. Five clues, scaled
            trivial to desperate, each pointing at a Remnant you place on the map. See page 13.</li>
    </ol>`;
}

function roomsPage() {
    return `
    <h2>Rooms are Scene Regions</h2>
    <p>Everything room-related reads from the Regions layer: which room a character is in, where
       they can search, which projects they can work on, where they can rest, and whose stash a
       room holds.</p>
    <ol>
        <li>Open the scene, pick the <strong>Regions</strong> layer in the left toolbar.</li>
        <li>Draw a shape over the room and <strong>give it a name</strong> — "Library", "Kitchen",
            "Dormitory". Unnamed regions are ignored.</li>
        <li>Repeat per room. Overlapping regions are allowed but the first name wins.</li>
    </ol>
    <h3>Movement</h3>
    <p>Players just drag their token. Moving <em>inside</em> a room is free. Crossing into another room
       spends the free Move for that time of day; after that each crossing costs an action. Turn this
       off in module settings (<em>Crossing rooms costs a Move</em>) if you would rather do it by hand.</p>
    <h3>What a room IS, not just where it is</h3>
    <p>One screen sets everything else about a room: <strong>GM panel → Season setup → Room setup</strong>.
       Owner (whose stash it is), concealed (hidden stash — disadvantage searching it), which item
       table it draws from, and which categories it favours (advantage searching for those). See
       page 9 for the full picture.</p>
    <h3>Rest rooms</h3>
    <p>GM panel → <em>Season setup</em> → <em>Choose which rooms allow rest</em>. Two tick boxes per
       room: Short Rest, and Long Rest (bedrooms). A room with neither offers no rest.</p>
    <p><em>No regions on the scene?</em> The dialogs will say so — draw them first.</p>`;
}

function panelPage() {
    return `
    <h2>Where everything lives</h2>
    <p>Four places outside the panel itself, and that is all:</p>
    <table>
        <thead><tr><th>Where to look</th><th>What it is</th><th>What it does</th></tr></thead>
        <tbody>
            <tr><td><strong>Left edge</strong> → token tools → <strong>clock icon</strong></td>
                <td>GM panel (GM only)</td>
                <td>Everything below on this page.</td></tr>
            <tr><td><strong>Top centre of the screen</strong>, upper bar of purple skulls</td>
                <td>Despair</td>
                <td>One row per GM. Its gear opens the GM team screen.</td></tr>
            <tr><td><strong>Top centre</strong>, just below that</td>
                <td>Campaign HUD</td>
                <td>Campaign, chapter, day, phase, time of day. Arrows step the time of day; the gear edits everything.</td></tr>
            <tr><td><strong>Projects tray</strong> (the countdown tray)</td>
                <td>Projects</td>
                <td>Its gear creates projects and sets rooms and secrecy.</td></tr>
        </tbody>
    </table>

    <h2>The GM panel, tile by tile</h2>
    <p>Grouped by <em>when</em> you reach for something, not by when it was built. Click a tile and
       the panel closes before its own dialog opens — the two are never stacked.</p>

    <h3>Right now</h3>
    <ul>
        <li><strong>Eclipse</strong> — start or end the placement window between two times of day.</li>
        <li><strong>Listen in on a room's voice</strong> — join a region's voice channel muted, if
            <code>avclient-livekit</code> is active.</li>
        <li><strong>Edit campaign…</strong> — chapter, day, phase, time of day, campaign name.</li>
        <li><strong>Handbook</strong> — this journal.</li>
    </ul>

    <h3>The case</h3>
    <ul>
        <li><strong>Open a murder / Incident tracker</strong> — see page 14. Reopens the live tracker
            once a murder is running, instead of asking to start a new one.</li>
        <li><strong>Investigation dashboard</strong> — see page 13.</li>
        <li><strong>A body is discovered</strong> — see page 12.</li>
        <li><strong>Issue Autopsy Truth Bullet</strong> — see page 8.</li>
        <li><strong>Edit Remnant flags</strong> — every Remnant on the scene: faint, tied to the crime,
            reinforced.</li>
        <li><strong>Trial evidence log</strong> — who presented what, and how many were Objections.</li>
    </ul>

    <h3>The trial</h3>
    <ul>
        <li><strong>The floor</strong> — open the speaking queue, or drive the one already running.
            See page 15.</li>
        <li><strong>The vote</strong> — send ballots, then close and count. See page 15.</li>
        <li><strong>Verdict</strong> — the murder trial's consequences (execution, level-ups, the wrong
            guess's cost). See page 15.</li>
    </ul>

    <h3>The season</h3>
    <ul>
        <li><strong>The Mastermind</strong> — pick, clear, or top up their Hope. <strong>This screen
            names them — never open it on a shared view.</strong> See page 17.</li>
        <li><strong>Start or end the Final Trial</strong> — a public announcement, unlike the pick
            itself.</li>
        <li><strong>Final Trial verdict</strong> — its own consequences, not the murder trial's. See
            page 17.</li>
    </ul>

    <h3>People and things</h3>
    <ul>
        <li><strong>Give / take items</strong> — including Truth Bullets, with their own form.</li>
        <li><strong>Look inside the stashes</strong> — every stash's contents, read-only summary.</li>
        <li><strong>A character dies</strong> — see page 12.</li>
        <li><strong>End of chapter / new session</strong> — see page 12.</li>
    </ul>

    <h3>Season setup</h3>
    <ul>
        <li><strong>GM team</strong> — mark Monokumas, split students, name Despair pools.</li>
        <li><strong>Room setup</strong> — see page 9.</li>
        <li><strong>Choose which rooms allow rest</strong> — see page 2.</li>
        <li><strong>Create item tables</strong> — see page 5.</li>
    </ul>

    <h3>If something is stuck</h3>
    <p>Dimmer on purpose — reach for these only when a correction is needed, not during ordinary play.</p>
    <ul>
        <li><strong>Refill everyone's actions</strong> — normally automatic when the time of day advances.</li>
        <li><strong>Restock search tokens</strong> — likewise.</li>
        <li><strong>Show search tokens</strong> — which rooms have been searched out.</li>
        <li><strong>Clear Faint Remnants</strong> — normally run from the chapter-end screen instead.</li>
        <li><strong>Reset voice</strong> — send everyone back to the main room's channel.</li>
    </ul>

    <h3>What players can and cannot touch</h3>
    <p>Two module settings, both on by default (<em>Configure Settings → Module Settings →
       Danganronpa RPG</em>):</p>
    <ul>
        <li><strong>Players cannot edit Actions, Hope or traits.</strong> Those move through play — spend
            an action, take a rest, earn an advancement. HP and Stress stay editable, because players mark
            their own damage constantly.</li>
        <li><strong>Players only see who is in their room.</strong> Other characters' tokens are hidden
            unless they share a room region with you.</li>
    </ul>
    <p>Character sheets are private by design: each player owns only their own. Check it any time with
       <code>game.drpg.auditAnonymity()</code>.</p>
    <h3>Advancing the time of day</h3>
    <p>The <strong>▶</strong> arrow on the HUD refills every character's actions and free Move, and
       restocks every room's search tokens. Five times of day make one day, and the day counter rolls
       over on its own. Moving to a new <strong>session</strong> also reminds you, in a notification,
       that the Truth Bullet sweep from page 12 is waiting — it does not sweep anything by itself.</p>
    <p>The <strong>◀</strong> arrow is a correction for a misclick: it steps the clock back and
       deliberately refills <em>nothing</em>.</p>`;
}

function actionsPage() {
    const rows = Object.entries(ACTIONS).map(([key, def]) => `
        <tr>
            <td><i class="fa-solid ${def.icon}"></i> <strong>${def.label}</strong></td>
            <td>${def.cost === 0 ? "free" : `${def.cost} action${def.cost > 1 ? "s" : ""}`}</td>
            <td>${def.callsGm ? "scored on the GM's client" : "automatic"}</td>
            <td>${def.hint ?? ""}</td>
        </tr>`).join("");

    return `
    <h2>Actions</h2>
    <p>Players find these as a grid at the top of the <strong>Features</strong> tab on their sheet.
       Clicking one opens a briefing explaining what it does, what it costs and where they are standing,
       before anything is spent.</p>
    <p>Each character has <strong>${STARTING.actions} actions per time of day</strong>, plus one free Move.
       A character with all HP marked drops to one action — the lost one shows as a red locked circle.</p>
    <table>
        <thead><tr><th>Action</th><th>Cost</th><th>Resolved</th><th>What it does</th></tr></thead>
        <tbody>${rows}</tbody>
    </table>
    <h3>Why Observe and Analyze do not open the normal roll receipt</h3>
    <p>Their difficulty depends on what a Remnant or a Truth Bullet <em>really</em> is — the exact thing
       the roll is trying to find out. So the player's client only declares and throws the dice; the
       verdict is scored on a GM's client and whispered back. See page 8.</p>
    <h3>Two panels that replace this grid entirely</h3>
    <ul>
        <li><strong>An incident.</strong> The two people in a murder's Stage 5 get crisis-action tiles
            above the normal grid instead of it — see page 14.</li>
        <li><strong>A Monocub.</strong> Move and Meddle only, with a Hope readout underneath — see
            page 16.</li>
    </ul>
    <h3>Rest</h3>
    <p>One tile, two rests. Short: ${REST.short.actionCost} action, pick ${REST.short.picks}.
       Long: ${REST.long.actionCost} actions, pick ${REST.long.picks}, bedrooms only.
       The dialog shows whether the current room allows each.</p>`;
}

function itemsPage() {
    const tables = Object.entries(ITEM_POOLS).map(([cat, tiers]) => `
        <tr>
            <td><strong>${ITEM_CATEGORIES[cat]?.plural ?? cat}</strong><br>
                <small>limit ${ITEM_CATEGORIES[cat]?.limit ?? "none"}</small></td>
            ${[0, 1, 2, 3].map(t => `<td>${(tiers[t] ?? []).join("<br>") || "—"}</td>`).join("")}
        </tr>`).join("");

    return `
    <h2>Where the items live, and how to add your own</h2>

    <h3>First: create the tables</h3>
    <p>GM panel → <strong>Season setup</strong> → <strong>Create item tables</strong>.
       <strong>Nothing exists until you click this.</strong> That is why you could not find them.</p>
    <p>It creates twelve RollTables — one per category and tier — inside a folder called
       <strong>Danganronpa RPG</strong>.</p>

    <h3>Where to find them afterwards</h3>
    <ol>
        <li>Look at the <strong>right-hand sidebar</strong> (where Chat, Actors, Items and so on live).</li>
        <li>Click the <strong>Rollable Tables</strong> tab — the icon is a small table grid
            (<i class="fa-solid fa-table-list"></i>).</li>
        <li>Open the <strong>Danganronpa RPG</strong> folder. You will see:
            <br><code>DRPG Usable Items — Tier 0</code>, <code>… Tier 1</code>, <code>… Tier 2</code>,
            <code>… Tier 3</code>, then the same for <code>Crime Tools</code> and
            <code>Cleaning Tools</code>.</li>
    </ol>

    <h3>Adding an item</h3>
    <ol>
        <li>Double-click the table for the right category and tier — for a Tier 2 murder weapon, that is
            <code>DRPG Crime Tools — Tier 2</code>.</li>
        <li>Click the <strong>+</strong> at the top of the results list.</li>
        <li>Type the item's name into the text field of the new row.</li>
        <li>Click <strong>Normalize Results</strong> (the balance-scales icon) so the number ranges cover
            the whole die evenly. <em>Skip this and your new item may never come up.</em></li>
    </ol>
    <p>Search reads a <strong>room's own table first</strong> if one is set (see page 9), then your
       global tables above, then the built-in list as a last resort. <strong>Re-running "Create item
       tables" never overwrites a table that already exists</strong>, so your edits are safe.</p>

    <h3>What about Daggerheart's own compendiums?</h3>
    <p>You will still see Daggerheart's Classes, Domains, Weapons, Armor and Adversaries in the
       <em>Compendium Packs</em> tab. <strong>This module ignores all of them</strong> — it never reads
       from them and never puts anything in them.</p>
    <p>You can leave them alone; they do no harm. If the clutter bothers you, you can hide them:</p>
    <ol>
        <li>Open the <strong>Compendium Packs</strong> tab in the right sidebar.</li>
        <li>Right-click a pack you do not want and choose <strong>Toggle Visibility</strong>, or open its
            settings and set ownership so players cannot see it.</li>
    </ol>
    <p><strong>Do not delete the system's packs.</strong> Deleting them can break Daggerheart on the next
       update, and this module gains nothing by it.</p>
    <h3>What ships by default</h3>
    <p>Only the examples the guide itself gives — it says explicitly that it "does not supply a list of
       items" and expects the GM to improvise.</p>
    <table>
        <thead><tr><th>Category</th><th>Tier 0</th><th>Tier 1</th><th>Tier 2</th><th>Tier 3</th></tr></thead>
        <tbody>${tables}</tbody>
    </table>
    <h3>Carry limits</h3>
    <p>Enforced automatically, including on drag-and-drop:
       ${Object.entries(ITEM_CATEGORIES).filter(([k]) => k !== "truthBullet")
           .map(([, c]) => `${c.plural} ${c.limit ?? "unlimited"}`).join(" · ")}.
       <strong>An item that will not fit is not refused</strong> — if the owner has a stash (page 9)
       it goes there instead, with a whisper explaining why.</p>`;
}

function projectsPage() {
    const scale = Object.values(PROJECT_SCALE)
        .map(s => `<tr><td>${s.label}</td><td>${s.progress} progress</td></tr>`).join("");

    return `
    <h2>Projects</h2>
    <p>A project is a Daggerheart <em>Countdown</em>, renamed throughout the interface to
       <strong>Projects</strong>. Everything lives in one window: the <strong>gear on the Projects
       tray</strong>.</p>
    <h3>Creating one</h3>
    <p>Gear → <strong>Create project</strong>. You set the name, the scale, the room it belongs to, and
       whether it is a secret indirect murder. Progression is set to <em>custom</em>, which means it only
       advances when a player uses <strong>Work on Project</strong> — never from attacks or rests.</p>
    <table><thead><tr><th>Scale</th><th>Target</th></tr></thead><tbody>${scale}</tbody></table>
    <h3>Rooms</h3>
    <p>A project tied to a room can only be worked on, or sabotaged, by someone standing in it. Leave the
       room blank for "anywhere".</p>
    <h3>Secret projects</h3>
    <p><strong>An indirect murder project is secret automatically.</strong> Only the killer and the GMs see
       it — a progress bar named "Prepare the poison" in everyone's sidebar would end the plot before it
       began.</p>
    <p>Gear → <strong>Share…</strong> lets someone else in, or revokes it. Players can bring in a
       co-conspirator themselves; the write is applied by the GM behind the scenes.</p>
    <h3>What an indirect murder costs the killer</h3>
    <ul>
        <li>If another player is in the room: a <strong>Shadow roll against 16</strong> to hide their intent
            before the project roll. Alone in the room instead grants <strong>+1 progress</strong>.</li>
        <li>Every project action also rolls <strong>Shadow to hide the traces</strong>, which decides how
            visible the Remnant it leaves is.</li>
    </ul>`;
}

function remnantsPage() {
    const types = Object.entries(REMNANT_TYPES).map(([key, t]) => `
        <tr>
            <td><strong>${t.label}</strong></td>
            <td>${t.reinforced ? "yes" : "—"}</td>
            <td>${t.hint}</td>
        </tr>`).join("");

    return `
    <h2>Remnants</h2>
    <p>Remnants are dropped as <strong>tokens on the map, where the character was standing</strong>. They are
       half-transparent, sorted <em>below</em> character tokens, and hidden from players until an
       Observe copies one into an inventory as a Truth Bullet (page 8) — the Remnant itself always
       stays on the map.</p>
    <table>
        <thead><tr><th>Type</th><th>Reinforced</th><th>What it means</th></tr></thead>
        <tbody>${types}</tbody>
    </table>
    <h3>What leaves one</h3>
    <ul>
        <li><strong>Search</strong> — when looking for crime or cleaning tools. Searching for usable items
            leaves nothing.</li>
        <li><strong>Sabotage</strong> — always, success or failure.</li>
        <li><strong>Work on Project</strong> — when the project is an indirect murder.</li>
        <li><strong>A murder's Incident and Resolution stages</strong> — see page 14.</li>
    </ul>
    <p>The better the roll, the harder the trace is to find. Each token carries a note saying who left it
       and why — visible to you, not to players.</p>
    <h3>Revealing and removing</h3>
    <p>Select the token and un-hide it (or <code>game.drpg.revealRemnant(token.document)</code>).
       <strong>Reinforced Remnants refuse to be deleted</strong> — Key and Final Truth Remnants are
       reinforced automatically the moment they are placed.</p>
    <p>At the end of a chapter: <strong>GM panel → People and things → End of chapter / new session</strong>
       — see page 12. It clears Faint Remnants for you; the standalone <em>Clear Faint Remnants</em> tile
       under <em>If something is stuck</em> is only for running that one step on its own.</p>
    <h3>Search tokens</h3>
    <p>Each room has three search tokens per time of day. They are spent before the roll, so a
       searched-out room cannot be probed by rolling anyway. They restock when the time of day advances.</p>`;
}

/* --------------------------------------------------------------------------
 * The Investigation loop: Observe, Analyze, the answer key, and how evidence
 * moves once it exists.
 * ------------------------------------------------------------------------ */

function investigationLoopPage() {
    const observeRows = ["obvious", "evident", "subtle", "hidden"].map(v => `
        <tr><td>${v}</td>${["dailyLife", "key", "faint", "prep"].map(c =>
            `<td>${OBSERVE_DC[v]?.[c] ?? "—"}</td>`).join("")}</tr>`).join("");
    const analyzeRows = ["obvious", "evident", "subtle", "hidden"].map(v => `
        <tr><td>${v}</td>${["dailyLife", "faint", "prep"].map(c =>
            `<td>${ANALYZE_DC[v]?.[c] ?? "—"}</td>`).join("")}</tr>`).join("");
    const types = Object.entries(TRUTH_BULLET_TYPES).map(([key, t]) => `
        <tr><td><strong>${t.label}</strong></td><td>${t.hint}</td></tr>`).join("");

    return `
    <h2>Why this page exists on its own</h2>
    <p>The Investigation is the one place in this module where the number a roll is judged against is
       itself a secret — how visible a Remnant is, and what it really turns out to be, are both things
       the person rolling must not know in advance. So Observe and Analyze are the only two actions
       whose dice are scored on a <strong>GM's client</strong>, never the player's. Everything on this
       page follows from that one fact.</p>

    <h2>Observe: four ways to look</h2>
    <p>A player declares how they are searching before anything is rolled:</p>
    <ul>
        <li><strong>Look around</strong> — the easiest Remnant in the room.</li>
        <li><strong>Look for something specific</strong> — they describe it, and a dialog on YOUR screen
            (not theirs) lists every candidate Remnant, closest first, so you pick which one fits. You
            can refuse if nothing matches.</li>
        <li><strong>Look for the non-obvious</strong> — the hardest Remnant in the room.</li>
        <li><strong>Look at something else</strong> — not a Remnant at all: a room, a person, a machine.
            Straight to a GM ruling, same as the guide's "Daily Life" column always worked.</li>
    </ul>
    <p><strong>Traces tied to the crime always rank first</strong>, whichever declaration was used —
       the guide's own rule. A Remnant already copied by that same character is skipped, so nobody
       farms one trace into a stack of duplicate evidence; a different character can still find the
       same Remnant independently.</p>
    <h3>Observe difficulty</h3>
    <table><thead><tr><th>Visibility</th><th>Daily Life</th><th>Key</th><th>Faint</th>
        <th>Prep / Incident / Resolution</th></tr></thead><tbody>${observeRows}</tbody></table>
    <p>A miss costs <strong>${OBSERVE_FAIL_STRESS} Stress</strong>. A
       critical identifies the category outright and earns a substantial hint. Autopsy Remnants have no
       roll at all — see page 12.</p>

    <h2>Analyze: turning Neutral into the truth</h2>
    <p>Works on a Neutral Truth Bullet the character already holds. A <strong>failure locks that one
       copy</strong> for that player until the chapter ends — the bullet stays in their inventory,
       still unidentified, and the lock lifts by itself the moment the next chapter starts. A copy
       handed to somebody else is a different item and carries no lock at all.</p>
    <table><thead><tr><th>Visibility</th><th>Daily Life</th><th>Faint</th>
        <th>Prep / Incident / Resolution</th></tr></thead><tbody>${analyzeRows}</tbody></table>
    <p>Key, Autopsy and Final Truth Bullets never reach this table — they arrive already identified.</p>

    <h2>What a Truth Bullet really is</h2>
    <table><thead><tr><th>Type</th><th>What it means</th></tr></thead><tbody>${types}</tbody></table>
    <p><strong>The split that makes all of this safe:</strong> a Truth Bullet's public flags (what the
       holder currently sees, how visible the original was, the chapter) live on the Item itself. What
       it <em>really</em> is lives only in a ledger on GM browsers, synced GM-to-GM, never sent to a
       player's client. This is not a convenience — Foundry ships the whole world database to every
       client on join, so a world setting or even a hidden flag on the item would have been readable
       from any player's console. <code>game.drpg.exportLedger()</code> backs the ledger up to a file;
       do this before a Class Trial.</p>

    <h2>Sharing evidence</h2>
    <p>Two buttons on a Truth Bullet row, both same-room only and free:</p>
    <ul>
        <li><strong>Share</strong> (the gold icon) — <strong>copies</strong> it. The giver keeps their
            own. The copy carries the giver's identification state, but never a lock — burning your own
            analysis and then sharing the bullet is a real, useful move.</li>
        <li><strong>Present</strong> (the red gavel, Class Trial only) — posts it publicly to everyone
            at once and pops up on every screen. Choosing <strong>OBJECTION</strong> instead
            automatically takes the speaking floor — see page 15.</li>
    </ul>
    <p>An ordinary item has its own single button instead: <strong>Give</strong> <em>moves</em> it —
       the giver loses it, and the receiver's carry limit still applies.</p>`;
}

/* --------------------------------------------------------------------------
 * The Vault / stash, and what makes one room different from another.
 * ------------------------------------------------------------------------ */

function vaultPage() {
    return `
    <h2>The stash</h2>
    <p>Every student's own bedroom can hold an <strong>uncapped</strong> stash — the guide's answer to
       "what happens to everything you own that will not fit in your hands". Set the owner from
       <strong>GM panel → Season setup → Room setup</strong> (page 2).</p>
    <h3>Using it</h3>
    <ul>
        <li><strong>Putting something away or taking it back out</strong> costs no action and no roll,
            but only works while standing in that room. Buttons appear right on the inventory row.</li>
        <li><strong>Truth Bullets cannot be stashed.</strong> They are what a character knows, not an
            object in a drawer — hiding one would only hide it from the trial the whole game points at.</li>
        <li><strong>A carry limit that is full does not refuse a find</strong> — it goes straight into
            the stash instead, with a whisper explaining why.</li>
    </ul>
    <h3>Somebody else's stash</h3>
    <p>A Search in a room that belongs to another student checks their stash <strong>before</strong>
       the room's own table — nothing is drawn at random, the loot is whatever is actually sitting in
       there, preferring whatever category was declared. Tick <strong>"stash hidden"</strong> in Room
       setup (usually after a "build a hiding place" project) to add disadvantage to that search — but
       only while there is something in the stash worth finding.</p>
    <p>GM panel → <strong>People and things</strong> → <strong>Look inside the stashes</strong> shows
       every stash at a glance; take things out from <em>Give / take items</em>.</p>

    <h2>What a room draws from, and what it is good for</h2>
    <p>The same Room setup screen carries two more fields, unrelated to the stash:</p>
    <ul>
        <li><strong>Draws from</strong> — an item table this room uses instead of the global pool. A
            room can have its own version per category too (<code>Kitchen — Crime Tools</code>) if you
            want more precision than one flat list; a plain table name answers every category. A room
            with nothing set here falls straight through to the global tables from page 5, so partial
            setup is always safe.</li>
        <li><strong>Good place to look for</strong> — tick the categories this room makes sense for (the
            medic's office for usable items, say). Searching here for a ticked category grants
            <strong>advantage automatically</strong> — nothing to remember mid-session, the roll dialog
            locks it in the moment the room and the goal line up.</li>
    </ul>`;
}

function despairPage() {
    const hope = Object.values(HOPE_CALLS)
        .map(c => `<tr><td>${c.label}</td><td>${c.cost}</td><td>${c.effect}</td></tr>`).join("");
    const despair = Object.values(DESPAIR_CALLS)
        .map(c => `<tr><td>${c.label}</td><td>${c.cost}</td><td>${c.effect}</td></tr>`).join("");

    return `
    <h2>Despair, one pool per Monokuma</h2>
    <p>Daggerheart has a single shared Fear pool; the guide wants one per GM, capped at
       ${STARTING.despairMax}. The bar at the top of the screen shows a row per <strong>full
       Gamemaster</strong> — Assistant GMs deliberately get no pool unless granted one.</p>
    <h3>Dividing the students</h3>
    <p><strong>GM panel → Season setup → GM team.</strong> One screen: mark Monokumas, point each at a
       Despair pool, name the pools (so two GMs are never both "Monokuma" in the UI), grant an
       Assistant GM their own pool, and split the roster.</p>
    <p>This matters because <strong>a roll that lands with Despair feeds that student's Monokuma</strong>,
       automatically.</p>
    <h3>Hope Calls</h3>
    <table><thead><tr><th>Call</th><th>Hope</th><th>Effect</th></tr></thead><tbody>${hope}</tbody></table>
    <h3>Despair Calls</h3>
    <table><thead><tr><th>Call</th><th>Despair</th><th>Effect</th></tr></thead><tbody>${despair}</tbody></table>
    <p>Spend one with <code>game.drpg.spendDespairCall(userId, "obstacle")</code>, or just click the pips
       down by hand. After a wrong vote the guide fills every pool:
       <code>game.drpg.fillAllDespair()</code> — the Class Trial verdict screen does this for you (page
       15), and so does a wrong Investigation (page 13).</p>
    <h3>The same trade, twice</h3>
    <p>A Monokuma can convert their own Despair into Hope for somebody else, 1:1 —
       <code>game.drpg.convertDespairToHope(userId, actor, amount)</code>. The guide gives this exact
       exchange to a Monocub (page 16) and to the Mastermind (page 17), for different reasons; it is
       one function underneath both screens.</p>`;
}

/**
 * How the two spending menus behave now that they apply themselves. Written out
 * per Call, because "it is automated" is not an instruction — the table needs to
 * know which button they press and what will happen without them.
 */
function callsPage() {
    const row = ([key, c]) => `
        <tr>
            <td><strong>${c.label}</strong></td>
            <td>${c.cost}</td>
            <td>${effectOf(c)}</td>
        </tr>`;

    const hope = Object.entries(HOPE_CALLS).map(row).join("");
    const despair = Object.entries(DESPAIR_CALLS).map(row).join("");

    return `
    <h2>Where they are</h2>
    <p>A player opens their sheet and clicks <strong>Actions → Hope Calls</strong>. A Monokuma opens
       their own sheet and finds <strong>Despair Calls</strong> in the same place — a Monokuma has no
       action grid, because they have no action economy.</p>
    <p>Calls you cannot afford are greyed out. Clicking one you can afford asks what it is aimed at
       (a player, a project, a room, an item), shows the price, and only then charges you.</p>

    <h2>Nothing is left to the honour system</h2>
    <p>Every Call now carries out its own effect. There is no free-text box to explain what you meant,
       because the module does the thing rather than announcing an intention.</p>

    <h3>Calls that change a roll</h3>
    <p>Advantage, disadvantage, experiences and the free trait choice are <em>disabled</em> in the roll
       window at all times. A Call is the only thing that opens them — and when it does, it does not
       merely unlock the button, it <strong>presses it and locks it again</strong>. A player cannot
       decline a disadvantage a Monokuma paid for, and cannot forget to tick the advantage they bought.</p>
    <p>These last for <strong>one roll only</strong>. The moment the roll window is submitted the Call
       is spent, whether the roll came from an action or from clicking a trait on the sheet. Two other
       sources feed the same lock: a room's favoured category (page 9) and a Monocub's Meddle (page
       16) — all three add together and clamp to a single advantage or disadvantage, so they cancel
       fairly rather than one silently overriding another.</p>
    <p>The Hope cost block has been removed from the roll window entirely: spending Hope on an
       experience <em>is</em> the Experience Call, already paid for before the window opened.</p>

    <h3>Free Critical</h3>
    <p>The dice are still thrown — and both come up 12, for 24 and a guaranteed critical, visible in
       chat like any other roll. The guide calls it "no roll"; a roll that produces nothing to look at
       would leave the table with nothing to react to.</p>

    <h3>Reroll</h3>
    <p>This one looks backwards. It re-rolls the character's <strong>most recent roll and no other</strong>,
       rewrites that chat message in place, and reverses what the old result gave: Hope, Stress, and the
       Despair point that went to their Monokuma. If the roll was Work on Project, Observe, Analyze, or a
       murder crisis action, the effect it bought — progress, a Truth Bullet, an identification, a
       Remnant, damage — is taken back and the new roll's effect applied in its place, on whichever
       client actually owns that state (the GM's, for anything Observe/Analyze/murder touched).</p>
    <p>What it cannot take back, it says so in the receipt: an item already drawn into an inventory that
       Reroll does not cover, or a Remnant already on the map from an untracked source. Remove those
       yourself if the new result does not justify them.</p>

    <h3>Support</h3>
    <p>Aimed at another character in the same room. Flags live on the beneficiary's actor, which the buyer
       has no write access to, so the arming is routed through your client — you will see nothing, but the
       beneficiary is whispered what they have been given.</p>

    <h3>Public Announcement</h3>
    <p>Every student is teleported into the room you pick, at a random spot inside it. This is a
       teleport, not a walk: walls and doors do not apply, and nobody is charged a Move for it. The same
       teleport runs a body discovery's "everyone to the scene" step (page 12).</p>

    <h3>New Rule</h3>
    <p>Asks you to type the rule. It is then posted to chat, publicly, word for word.</p>

    <h2>Hope Calls</h2>
    <table><thead><tr><th>Call</th><th>Hope</th><th>What the module does</th></tr></thead>
    <tbody>${hope}</tbody></table>

    <h2>Despair Calls</h2>
    <table><thead><tr><th>Call</th><th>Despair</th><th>What the module does</th></tr></thead>
    <tbody>${despair}</tbody></table>

    <h2>If a Call ever does nothing</h2>
    <p>It will tell you. A Call that is paid for and whose effect fails now raises an error notification
       and prints the failure in its own receipt, instead of charging you and staying quiet.</p>`;
}

/** Plain-English description of what a Call's data actually makes happen. */
function effectOf(c) {
    const parts = [];
    if (c.grants === "advantage") parts.push("ticks and locks Advantage on the next roll");
    if (c.grants === "disadvantage") parts.push("ticks and locks Disadvantage on the next roll");
    if (c.grants === "experience") parts.push("ticks and locks every experience on the next roll");
    if (c.grants === "trait") parts.push("unlocks the trait picker for the next roll");
    if (c.grants === "critical") parts.push("forces the next roll to 12 + 12 = 24, a critical");
    if (c.reroll) parts.push("re-rolls the last roll and reverses what it gave");
    if (c.announces) parts.push("asks for the wording and posts it to chat");
    if (c.damage) {
        parts.push(`marks ${Object.entries(c.damage)
            .map(([r, n]) => `${n} ${r === "hitPoints" ? "HP" : "Stress"}`).join(" and ")}`);
    }
    if (c.progress) parts.push(`${c.progress > 0 ? "+" : ""}${c.progress} progress on a project`);
    if (c.wipesProgress) parts.push("empties a project's progress bar");
    if (c.sealsRoom) parts.push("seals a room until the clock advances");
    if (c.gathersEveryone) parts.push("teleports every student into one room");
    if (c.target === "item") parts.push("deletes the item from its owner's inventory");
    return parts.join("; ") || "—";
}

/* --------------------------------------------------------------------------
 * The chapter's life: death, the body being found, and closing the chapter.
 * ------------------------------------------------------------------------ */

function chapterLifePage() {
    return `
    <h2>Nothing here fires on its own</h2>
    <p>Every screen on this page is a GM button, never a clock trigger. Two of the three actions below
       delete things permanently, and "the chapter has ended" is a judgement about the fiction — after
       the verdict, after the execution, when the table is ready — not a number that happened to tick
       over.</p>

    <h2>A character dies</h2>
    <p><strong>GM panel → People and things → A character dies.</strong> One procedure: everything the
       character carried is destroyed, Truth Bullets included, and it cannot be undone. The token stays
       on the map — a body is usually the thing everyone is standing around looking at — but the dead
       no longer count as being in the room: they cannot witness, be handed anything, or block another
       murder happening in the same room later. <code>game.drpg.reviveCharacter(actor)</code> undoes the
       mark for a mis-click; it does not bring the destroyed inventory back.</p>

    <h2>A body is discovered</h2>
    <p><strong>GM panel → The case → A body is discovered.</strong> First offers every doubtful Faint
       Prep trace on the map so you can tick which ones belong to this murder — only you know that, since
       a Prep Remnant is left by anyone gathering tools and most of them mean nothing. Ticked traces stop
       being doubtful: they survive the chapter-end sweep and count as evidence tied to the crime.</p>
    <p>Then it announces the discovery, teleports every living student to the room you name, and switches
       the phase to <strong>Investigation</strong>.</p>

    <h2>End of chapter / new session</h2>
    <p><strong>GM panel → People and things → End of chapter / new session.</strong> Three independent
       ticks, with the numbers they will affect shown before anything happens:</p>
    <ul>
        <li><strong>Reveal what every Truth Bullet really is</strong> — run at the chapter's end.</li>
        <li><strong>Clear Faint Remnants from the map</strong> — reinforced and crime-tied ones are
            never touched, whichever screen you run this from.</li>
        <li><strong>Sweep Truth Bullets for the new session</strong> — run at the <em>start of the
            next session</em>, usually a different evening from the first two. Faint Truth Bullets
            survive; so does the Final Truth Remnant's bullet, all season, automatically (page 17).</li>
    </ul>
    <p>Moving the session counter forward (the HUD's ▶, once it rolls a day past Night) only reminds you
       that the sweep is waiting — it never deletes anything by itself.</p>`;
}

/* --------------------------------------------------------------------------
 * The Investigation workshop: planning and tracking the case.
 * ------------------------------------------------------------------------ */

function investigationWorkshopPage() {
    return `
    <h2>Two screens, two questions</h2>
    <p>Everything a GM needs mid-Investigation comes down to two things: <em>what are my five clues,
       and have I actually placed them</em>, and <em>who has found what, and is this case still
       solvable</em>. GM panel → <strong>The case</strong> → <strong>Investigation dashboard</strong>
       opens the second, with a button through to the first.</p>

    <h2>Plan the Key Remnants</h2>
    <p>The guide's own scale: ${KEY_REMNANTS.scale.join(" · ")} — five clues that together should
       narrow the suspects to <strong>${KEY_REMNANTS.suspectRange[0]}–${KEY_REMNANTS.suspectRange[1]}
       people</strong>. Write what each one tells the players, then point it at the actual Remnant you
       placed for it on the map. A clue with no Remnant chosen is exactly as useless as one you forgot
       to place — this screen makes both visible before the Investigation starts, not after a player
       asks why the case has no answer. The plan resets itself when the chapter changes, so last
       chapter's notes never masquerade as this one's case.</p>

    <h2>The dashboard</h2>
    <ul>
        <li><strong>Key Remnants</strong> — found, on the map, or missing, with who found each one.
            Below the floor of ${KEY_REMNANTS.minimum} reachable clues the screen warns you outright:
            the case cannot be solved, and the guide owes the Monokumas Despair for it.</li>
        <li><strong>Who has what</strong> — every living student's Truth Bullet count, how many are Key,
            how many are still unidentified, and a GM-only breakdown of what they really are.</li>
    </ul>
    <p><strong>Pay the Monokumas</strong> is its own button, deliberately not automatic: the guide gives
       <code>${KEY_REMNANTS.despairPerMissing} Despair</code> per missing Key Remnant to every Monokuma,
       but only once the GM decides the Investigation is actually over — a clue found in the last five
       minutes must not already have been paid for.</p>`;
}

/* --------------------------------------------------------------------------
 * The murder engine.
 * ------------------------------------------------------------------------ */

function murderPage() {
    const crisisRow = key => {
        const def = CRISIS_ACTIONS[key];
        return `<tr><td>${def.label}</td><td>${def.threshold ?? "5 × HP left"}</td>
            <td>${def.hint ?? ""}</td></tr>`;
    };
    const victimRows = ["leaveClue", "secureTrace", "selfDefence", "survive", "roleReversal"]
        .map(crisisRow).join("");
    const killerRows = ["strike", "pin", "keepDistance", "weaponAttack", "finishingBlow"]
        .map(crisisRow).join("");

    return `
    <h2>The module owns the numbers, you own the prose</h2>
    <p>Thresholds, the drain, turn order, damage, which Remnants each outcome leaves, who is hindered
       and for how long: all mechanical, all automatic. What is <em>not</em> automatic is the sentence
       under each outcome — "the victim takes something of the killer's and makes evidence of it" is
       something a person finishes, so every crisis action's text is whispered to you rather than
       invented here.</p>

    <h2>Starting one</h2>
    <p><strong>GM panel → The case → Open a murder.</strong> Pick the killer and the victim, and whether
       it is indirect (the drain doubles, since the victim is alone). The declaration and the table's
       consent to it happen away from this screen, before the session — this button is where they become
       mechanical.</p>

    <h2>Stage 4 — the two opening rolls</h2>
    <p><strong>Rolled on a GM's client, not the participants'.</strong> The whole point of an opening
       roll is that neither side knows the other's result yet — a roll window on the killer's own
       screen titled "opening roll" would tell them (and the table, if screens are shared) that
       something is about to happen. The incident tracker has its own two buttons for these.</p>
    <table><thead><tr><th></th><th>Threshold</th><th>Night</th></tr></thead><tbody>
        <tr><td>Killer</td><td>${MURDER_OPENING.killer.threshold}</td>
            <td>${MURDER_OPENING.killer.nightAdvantage ? "advantage" : "—"}</td></tr>
        <tr><td>Victim</td><td>${MURDER_OPENING.victim.threshold}</td>
            <td>${MURDER_OPENING.victim.nightDisadvantage ? "disadvantage" : "—"}</td></tr>
    </tbody></table>
    <p>The better the killer's roll, the <strong>fewer</strong> Key Remnants the case leaves — Hope
       leaves the most, a critical the fewest, always floored at the guide's minimum of
       ${KEY_REMNANTS.minimum} so a good roll can never make a case unsolvable.</p>

    <h2>Stage 5 — the incident</h2>
    <p>A turn-based exchange. The <strong>victim always goes first</strong>, and every one of their turns
       costs them — ${INCIDENT.drain.direct} Stress (direct) or ${INCIDENT.drain.indirect} (indirect,
       victim alone) — until Stress runs out and HP starts marking instead. Crisis-action tiles appear
       on each participant's own sheet, above their normal grid, and stay visible even when it is not
       their turn — "not your turn yet" is information the other player needs too.</p>
    <h3>Victim's crisis actions</h3>
    <table><thead><tr><th>Action</th><th>Threshold</th><th>What it does</th></tr></thead>
    <tbody>${victimRows}</tbody></table>
    <h3>Killer's crisis actions</h3>
    <table><thead><tr><th>Action</th><th>Threshold</th><th>What it does</th></tr></thead>
    <tbody>${killerRows}</tbody></table>
    <p><strong>Finishing Blow's</strong> threshold is five times the victim's <em>remaining</em> HP —
       free the moment they hit 0. Without it, the victim keeps taking turns at 0 HP and 0 Stress
       forever.</p>
    <p>Somebody walking in mid-incident (<strong>Somebody walks in</strong>, from the tracker) gets one
       free resolution action of their own: escape together with the victim, restoring their HP and
       Stress, or get caught up in it instead.</p>

    <h2>Stage 6 — resolution</h2>
    <p>Once the incident ends the killer can finally see the Remnants they left, and spend
       <strong>${RESOLUTION_STRESS_COST} Stress</strong> (not an action) per resolution attempt to clean
       up — reinforced traces refuse to be removed, and a crime tool that was used is destroyed once
       spent.</p>

    <h2>The tracker</h2>
    <p>GM panel → <strong>The case</strong> → the same tile reopens the live tracker once a murder is
       running: whose turn, what the victim has left, the Key Remnant count, and buttons to pass the
       turn, bring in a third party, or close the murder out.</p>`;
}

/* --------------------------------------------------------------------------
 * The Class Trial.
 * ------------------------------------------------------------------------ */

function trialPage() {
    return `
    <h2>The floor</h2>
    <p><strong>GM panel → The trial → The floor.</strong> Pick a volunteer to open; the order rotates
       from them through every living student. Everyone sees the same countdown, live —
       ${TRIAL.speakSeconds} seconds each, turning red once it runs over. You never have to move the
       floor for an Objection: <strong>presenting one takes it automatically</strong>, the instant the
       card is posted (page 8), exactly as the guide has it.</p>

    <h2>The vote</h2>
    <p><strong>GM panel → The trial → The vote.</strong> One tile, two moments: <em>Send the ballots</em>
       puts a private picker in front of every connected player, then <em>Close and count</em> tallies
       and publishes only the totals.</p>
    <p><strong>Votes never touch the world's data at all.</strong> "Wyniki są jawne, ale głosy - nie" —
       results are public, votes are not — and nothing in Foundry's own data is actually private from a
       determined console (see page 8's note on the Truth Bullet ledger). So a ballot is sent over a
       socket addressed to the GMs specifically, tallied in memory on whichever GM's screen collected
       them, and forgotten completely the moment the count is published. Nobody, including the GMs
       afterwards, can recover who voted for whom.</p>
    <p>A player may vote for Monokuma or for somebody already dead, never for themselves.
       <strong>A tie counts as a loss for the students</strong>, same as a wrong guess.</p>

    <h2>The verdict</h2>
    <p><strong>GM panel → The trial → Verdict.</strong> Only you know whether the vote actually named
       the Blackened — say who was executed and who the Blackened really was, then pick the outcome:</p>
    <ul>
        <li><strong>Correct.</strong> The Blackened is executed; every survivor's advancement dialog
            opens for a standard level-up.</li>
        <li><strong>Wrong</strong> (a tie counts as wrong). The accused is executed instead. The
            Blackened stays anonymous and in play, with a <strong>Reinforced</strong> level-up and one
            new rule of their choosing — every Monokuma's Despair fills to maximum.</li>
    </ul>
    <p>This is the murder trial's verdict specifically. The Final Trial has its own — see page 17.</p>`;
}

/* --------------------------------------------------------------------------
 * Monocub.
 * ------------------------------------------------------------------------ */

function monocubPage() {
    return `
    <h2>Opting in</h2>
    <p>"Po śmierci, gdy jego class trial się zakończy, gracz może dołączyć do DMów jako Monocub" —
       once a dead student's trial has concluded, ask if they want in. <strong>GM panel → People and
       things → Monocubs</strong> lists every dead student with a tick box; that judgement of timing is
       yours, the module only reminds you of the guide's condition rather than enforcing it.</p>
    <p>A Monocub is not a Monokuma. It stays the same actor, keeps the same action budget as any living
       student (refilled the same way, nothing special to configure), and keeps the same
       room-restricted vision every student has. Only the action panel changes.</p>

    <h2>Move and Meddle</h2>
    <p>The only two actions available. Meddle costs <strong>${MONOCUB.meddle.cost} action</strong> from
       the normal budget <em>and</em> <strong>${MONOCUB.meddle.hopeCost} Hope</strong> on top — and that
       Hope only ever exists because a GM converted some Despair into it (below). No Hope, no Meddle,
       however many actions are left.</p>
    <p>The roll itself has no trait behind it — the guide marks it "Stat: —" outright — so it is a flat
       2d12, crit on doubles, the same duality math with no modifier added. Pick Help or Hinder and a
       target in the same room:</p>
    <table><thead><tr><th>Roll</th><th>Help</th><th>Hinder</th></tr></thead><tbody>
        ${MONOCUB.meddle.thresholds.map(t =>
            `<tr><td>${t.min}+</td><td>${t.help}</td><td>${t.hinder}</td></tr>`).join("")}
        <tr><td>Critical</td><td>${MONOCUB.meddle.critical.help}</td>
            <td>${MONOCUB.meddle.critical.hinder}</td></tr>
        <tr><td>Miss</td><td colspan="2">${MONOCUB.meddle.failure}</td></tr>
    </tbody></table>
    <p>The lower tier's bonus and the upper tier's advantage both land on the target's very next roll —
       including an incident's crisis action, since it is the identical roll dialog. The target is told
       something happened; never who did it.</p>

    <h2>Giving them Hope</h2>
    <p>From the same Monocubs screen: pick a Monokuma, an amount, and <strong>Give</strong>. Real
       Despair leaves that pool and becomes real Hope on the Monocub's sheet — this is always a GM's
       ruling, never a button the Monocub presses themselves, matching the guide's "mogą poprosić DMa".</p>

    <h2>Stumbling onto a crime</h2>
    <p>The same screen has a <strong>"Silenced this chapter"</strong> tick, for a Monocub whose token
       happened to be in the room when an incident started. The guide bans them from discussing the
       crime until the chapter ends — a narrative rule this module reminds you of on their sheet, rather
       than one it could ever detect reliably itself. They can still Meddle on the incident's own crisis
       actions throughout.</p>`;
}

/* --------------------------------------------------------------------------
 * Mastermind and the Final Trial.
 * ------------------------------------------------------------------------ */

function mastermindPage() {
    return `
    <h2>The one secret treated more carefully than any other</h2>
    <p>Every other role in this module — Monokuma, Monocub, dead — is public knowledge at the table, so
       marking it as a flag on the character costs nothing. The Mastermind is the opposite: "Wśród
       graczy ukryty jest mastermind" is arguably the single most important secret the whole season
       runs on. A flag would have been a real leak — Foundry ships every actor to every client
       regardless of who owns it, so any other player reading the console could simply ask their own
       browser who it is. Instead, the Mastermind's identity lives only in your own browser's storage,
       quietly kept in step with your co-GMs over a private channel, and is never part of the world
       data at all.</p>
    <p><strong>Practical consequence: the "Mastermind" screen below names them on your screen.
       Never open it where a player might see it.</strong></p>

    <h2>Picking one</h2>
    <p><strong>GM panel → The season → The Mastermind.</strong> Chosen before the season starts, "w
       uzgodnieniu z samym graczem" — talk to that player first, this module cannot have that
       conversation for you. The same screen lets you top up their Hope by converting a Monokuma's
       Despair, 1:1 — the same trade a Monocub gets (page 16), just for a different, still-active
       character. Everything else about them plays completely normally: full action economy, full Hope
       Calls, nothing restricted.</p>
    <p>Private intel — "co się dzieje na mapie, czy morderstwo jest planowane" — travels over the
       existing messenger (each player already has one private thread to every GM). No new tool for
       that; it is exactly what the messenger is for.</p>

    <h2>The Final Truth Remnant</h2>
    <p>One per chapter, pointing at the Mastermind and the real reason for the killing game. Mechanically
       an ordinary Remnant — place it with the same tools as any other, type <strong>Final Truth
       Remnant</strong> — except it is reinforced automatically and <strong>excluded from the Truth
       Bullet sweep</strong> (page 12): it survives the whole season, not just one chapter's case. The
       chapter-end screen reminds you, gently, if this chapter has not had one placed yet.</p>

    <h2>The Final Trial</h2>
    <p>Mechanically the <strong>same</strong> floor, Present/OBJECTION and vote as any Class Trial (page
       15) — no separate machinery to learn. <strong>GM panel → The season → Start or end the Final
       Trial</strong> is a public announcement (everyone already knows the finale is happening; only the
       identity stays hidden) that adjusts nothing except the flavour text.</p>
    <p>Only the <strong>verdict</strong> is different, because the guide's consequences are a different
       shape from a murder trial's: a wrong guess here does not execute an innocent. <strong>GM panel →
       The season → Final Trial verdict</strong>:</p>
    <ul>
        <li><strong>They named the Mastermind</strong> (only offered while the Mastermind is still
            alive) — executed, and the killing game is over.</li>
        <li><strong>They did not</strong>, or the <strong>Mastermind already died earlier this
            season</strong> — nobody new is executed. The table is shown the truth instead: the game
            they were playing was never what it looked like.</li>
    </ul>
    <p>Either branch clears the Mastermind pick — a Final Trial is the season's ending, not one more
       chapter.</p>`;
}

function consolePage() {
    return `
    <h2>Console reference</h2>
    <p>Everything sits on <code>game.drpg</code>. Press F12 to open the console.
       <code>Object.keys(game.drpg).sort()</code> lists the full surface.</p>
    <h3>Setting up</h3>
    <ul>
        <li><code>game.drpg.initCharacter(actor)</code> — starting HP/Stress/Hope</li>
        <li><code>game.drpg.installHandbook({ overwrite: true })</code> — rebuild this journal</li>
        <li><code>game.drpg.installTables()</code> — create the item RollTables</li>
        <li><code>game.drpg.autoAssign()</code> — split students between Monokumas</li>
        <li><code>game.drpg.roomSetup()</code> — owner, concealment, table and favours per room</li>
    </ul>
    <h3>Running a session</h3>
    <ul>
        <li><code>game.drpg.advanceTimeOfDay()</code> · <code>game.drpg.rewindTimeOfDay()</code></li>
        <li><code>game.drpg.resetAllActions()</code></li>
        <li><code>game.drpg.getClock()</code> · <code>game.drpg.setClock({ chapter: 2 })</code></li>
        <li><code>game.drpg.performAction(actor, "search")</code> — run an action for someone</li>
    </ul>
    <h3>Investigation</h3>
    <ul>
        <li><code>game.drpg.dropRemnant(actor, { type: "key", visibility: "evident" })</code></li>
        <li><code>game.drpg.remnantsInRoom("Library")</code></li>
        <li><code>game.drpg.createTruthBullet(actor, { name, realType, visibility })</code></li>
        <li><code>game.drpg.keyPlanStatus()</code> — the Key Remnant plan, scored against reality</li>
        <li><code>game.drpg.clearFaintRemnants()</code></li>
        <li><code>game.drpg.grantItem(actor, { name: "Axe", category: "crimeTool", tier: 2 })</code></li>
        <li><code>game.drpg.stow(actor, item)</code> · <code>game.drpg.retrieve(actor, item)</code></li>
    </ul>
    <h3>The chapter's life</h3>
    <ul>
        <li><code>game.drpg.killCharacter(actor)</code> · <code>game.drpg.reviveCharacter(actor)</code></li>
        <li><code>game.drpg.discoverBody({ room: "Library", victim: actor })</code></li>
        <li><code>game.drpg.revealAllBulletTypes()</code> · <code>game.drpg.sweepTruthBullets()</code></li>
    </ul>
    <h3>Murder and trial</h3>
    <ul>
        <li><code>game.drpg.openMurder({ killerId, victimId, indirect: false })</code></li>
        <li><code>game.drpg.murderState()</code> — the live incident, if one is running</li>
        <li><code>game.drpg.startFloor(actorId)</code> · <code>game.drpg.nextSpeaker()</code></li>
        <li><code>game.drpg.openVote()</code> · <code>game.drpg.closeVote()</code></li>
        <li><code>game.drpg.applyVerdict({ correct, executedId, blackenedId })</code></li>
    </ul>
    <h3>Monocub and Mastermind</h3>
    <ul>
        <li><code>game.drpg.setMonocub(actor)</code> · <code>game.drpg.meddleTargets(actor)</code></li>
        <li><code>game.drpg.setMastermind(actor)</code> — GM-only; never readable by a player</li>
        <li><code>game.drpg.convertDespairToHope(userId, actor, amount)</code></li>
        <li><code>game.drpg.finalTruthPlacedThisChapter()</code></li>
        <li><code>game.drpg.applyFinalVerdict({ correct, accusedId })</code></li>
    </ul>
    <h3>When something looks wrong</h3>
    <ul>
        <li><code>game.drpg.diagnoseDice()</code> — why are the dice unskinned?</li>
        <li><code>game.drpg.diagnoseDespair()</code> — why is no Despair being awarded?</li>
        <li><code>game.drpg.diagnoseTruthBullets()</code> — bullets and the answer key, in step or not</li>
        <li><code>game.drpg.diagnoseStyles()</code> — why does the sheet look different here?</li>
        <li><code>game.drpg.auditAnonymity()</code> — who can read whose sheet?</li>
        <li><code>game.drpg.findDuplicateUltimates()</code> — two students with the same Ultimate</li>
    </ul>`;
}
