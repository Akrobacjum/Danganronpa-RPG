/**
 * Danganronpa RPG — forced private rolls.
 * ---------------------------------------------------------------------------
 * In a killing game nobody may read anyone else's dice. Every chat message a
 * player creates that carries a roll is rewritten into a whisper aimed at the
 * GMs plus the roller. The roller still sees their own result; nobody else
 * does. GM rolls are left alone.
 */

import { MODULE_ID } from "./config.mjs";
import { SETTINGS } from "./settings.mjs";
import { gmIds, error, debug } from "./utils.mjs";

export function registerPrivateRolls() {
    Hooks.on("preCreateChatMessage", onPreCreateChatMessage);
    // Foundry v13+ passes an HTMLElement; the older jQuery hook is kept as a
    // fallback for a build that still fires it.
    Hooks.on("renderChatMessageHTML", enforceContentVisibility);
    Hooks.on("renderChatMessage", enforceContentVisibility);
}

/**
 * Actually hide what the whisper only *marked* as hidden.
 *
 * The whisper above was working the whole time. What defeated it is a
 * collaboration between core and the system, and neither half is a bug on its
 * own:
 *
 *   Foundry:      `ChatMessage#visible` returns TRUE for any whispered message
 *                 that contains a roll — deliberately. The card is meant to be
 *                 seen ("somebody rolled") while the CONTENT is blanked, and
 *                 the blanking is a separate getter, `isContentVisible`.
 *   Daggerheart:  its chat template replaces core's and renders
 *                 `{{{message.content}}}` unconditionally. It never asks
 *                 `isContentVisible`.
 *
 * So every private roll was whispered correctly, rendered by the system's own
 * template, and read by the whole table.
 *
 * This closes it at the last possible moment — render time — which is also the
 * only place that works regardless of which template the system swaps in next.
 * The whole message is hidden rather than emptied: in a killing game "Kaede
 * rolled something" is itself information, and an empty card in the log is
 * worse than no card.
 */
function enforceContentVisibility(message, element) {
    try {
        const html = element instanceof HTMLElement ? element : element?.[0];
        if (!html) return;
        // Core's own rule, asked directly. It already accounts for the author,
        // blind rolls and GMs, so there is nothing to re-derive here.
        if (message.isContentVisible) return;
        html.classList.add("drpg-hidden-message");
    } catch (err) {
        // A message we cannot judge is left alone — better a visible roll than
        // a chat log that stops rendering.
        error("Could not apply private-roll visibility", err);
    }
}

function onPreCreateChatMessage(message, data, options, userId) {
    try {
        if (!game.settings.get(MODULE_ID, SETTINGS.forcePrivateRolls)) return;

        // Foundry v12+ exposes the creating user as `author`.
        const authorId = message.author?.id ?? message.user?.id ?? userId;
        const author = game.users.get(authorId);
        if (!author || author.isGM) return;

        const hasRoll = (message.rolls?.length ?? 0) > 0
            || !!data?.roll
            || (data?.rolls?.length ?? 0) > 0;
        if (!hasRoll) return;

        // Already a whisper — respect whatever aimed it there.
        if (message.whisper?.length) return;

        const recipients = gmIds();
        if (!recipients.length) return;

        // Set the roll mode flag as well as the recipients. Modules that style
        // or animate rolls (Dice So Nice among them) read `core.rollMode`, and
        // a message whose recipients say "private" while its flag still says
        // "public" is an inconsistent state we should not create.
        message.updateSource({
            whisper: Array.from(new Set([...recipients, author.id])),
            blind: false,
            "flags.core.rollMode": CONST.DICE_ROLL_MODES.PRIVATE
        });
        debug("Rewrote a player roll into a private whisper.", author.name);
    } catch (err) {
        error("preCreateChatMessage failed", err);
    }
}
