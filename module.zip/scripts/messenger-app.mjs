/**
 * Danganronpa RPG — messenger windows and launcher.
 * ---------------------------------------------------------------------------
 * Two pieces of UI:
 *
 *   DrpgMessengerApp   One conversation window per player. A player only
 *                      ever opens their own; a GM can have several open at
 *                      once, one per player, each remembering where it was
 *                      left on screen.
 *
 *   the launcher       A small persistent button, bottom-right. A player
 *                      clicks it to open their own thread. A GM clicks it to
 *                      open a roster — every player, an unread badge, a
 *                      one-line preview — and picks who to open.
 *
 * No Handlebars template: the rest of this module builds DOM by hand, so
 * ApplicationV2 is used here without the Handlebars mixin, for the same
 * reason — one way of building markup, not two.
 */

import { MODULE_ID } from "./config.mjs";
import { SETTINGS } from "./settings.mjs";
import { gmIds, error } from "./utils.mjs";
import { showPopup } from "./popup.mjs";
import {
    MESSENGER_FLAGS, THREAD_KIND,
    threadUsers, isThreadUser, threadMessages, lastMessage,
    unreadCount, totalUnread, markThreadRead, sendMessage
} from "./messenger.mjs";

const LAUNCHER_ID = "drpg-messenger-launcher";

export function registerMessengerUi() {
    Hooks.once("ready", renderLauncher);
    Hooks.on("canvasReady", () => renderLauncher());
    Hooks.on("drpgMessengerMessage", () => renderLauncher());
    Hooks.on("drpgMessengerRead", () => renderLauncher());

    // A quick way in from the Players sidebar, mirroring how avclient-livekit
    // adds its own breakout-room entries to the same context menu.
    Hooks.on("getUserContextOptions", (playersApp, contextOptions) => {
        contextOptions.push({
            name: game.i18n.localize("DRPG.Messenger.openChat"),
            icon: '<i class="fa-solid fa-comments"></i>',
            condition: li => {
                if (!game.user.isGM) return false;
                const userId = li?.dataset?.userId ?? "";
                return isThreadUser(userId);
            },
            callback: li => {
                const userId = li?.dataset?.userId ?? "";
                if (userId) openMessenger(userId);
            }
        });
    });
}

/* ==========================================================================
 * OPENING A THREAD
 * ========================================================================== */

/**
 * Open (or focus) a player's thread window.
 * @param {string} [playerUserId]  Defaults to the caller's own thread.
 */
export function openMessenger(playerUserId = game.user.id) {
    if (!game.user.isGM && playerUserId !== game.user.id) {
        ui.notifications.warn(game.i18n.localize("DRPG.Messenger.onlyOwnThread"));
        return null;
    }
    if (!isThreadUser(playerUserId)) {
        ui.notifications.warn(game.i18n.localize("DRPG.Messenger.notAPlayer"));
        return null;
    }

    const existing = DrpgMessengerApp.instances.get(playerUserId);
    if (existing) {
        existing.bringToFront();
        return existing;
    }

    const app = new DrpgMessengerApp(playerUserId);
    DrpgMessengerApp.instances.set(playerUserId, app);
    app.render({ force: true });
    return app;
}

/* ==========================================================================
 * THE CONVERSATION WINDOW
 * ========================================================================== */

export class DrpgMessengerApp extends foundry.applications.api.ApplicationV2 {
    /** One instance per player thread, so opening twice just refocuses it. */
    static instances = new Map();

    static DEFAULT_OPTIONS = {
        classes: ["drpg-messenger"],
        window: {
            icon: "fa-solid fa-comments",
            resizable: true,
            minimizable: true
        },
        position: {
            width: 360,
            height: 460
        }
    };

    constructor(playerUserId) {
        const options = { id: `drpg-messenger-${playerUserId}` };
        // Only set `position` when there is a saved one — passing `undefined`
        // through to ApplicationV2's option merge is not guaranteed to fall
        // back to DEFAULT_OPTIONS.position the way omitting the key does.
        const saved = readSavedPosition(playerUserId);
        if (saved) options.position = saved;
        super(options);
        this.playerUserId = playerUserId;
    }

    get title() {
        if (!game.user.isGM) return game.i18n.localize("DRPG.Messenger.playerWindowTitle");
        const player = game.users.get(this.playerUserId);
        return game.i18n.format("DRPG.Messenger.gmWindowTitle", { player: player?.name ?? "?" });
    }

    async _prepareContext(_options) {
        const player = game.users.get(this.playerUserId);
        const gms = gmIds().map(id => game.users.get(id)).filter(Boolean);
        return { player, gms, messages: threadMessages(this.playerUserId) };
    }

    async _renderHTML(context, _options) {
        const root = document.createElement("div");
        root.className = "drpg-messenger-body";

        const participants = document.createElement("div");
        participants.className = "drpg-messenger-participants";
        participants.textContent = participantsLine(context.player, context.gms);
        root.append(participants);

        const log = document.createElement("div");
        log.className = "drpg-messenger-log";
        if (!context.messages.length) {
            log.append(emptyNotice());
        } else {
            for (const message of context.messages) log.append(buildBubble(message));
        }
        root.append(log);

        const form = document.createElement("form");
        form.className = "drpg-messenger-input";
        form.innerHTML = `
            <textarea name="text" rows="1"
                placeholder="${foundry.utils.escapeHTML(game.i18n.localize("DRPG.Messenger.placeholder"))}"></textarea>
            <button type="submit" aria-label="${foundry.utils.escapeHTML(game.i18n.localize("DRPG.Messenger.send"))}">
                <i class="fa-solid fa-paper-plane"></i>
            </button>`;
        root.append(form);

        return root;
    }

    async _replaceHTML(result, content, _options) {
        content.replaceChildren(result);
    }

    _onRender(_context, _options) {
        const form = this.element.querySelector(".drpg-messenger-input");
        const textarea = form?.querySelector("textarea");

        form?.addEventListener("submit", async event => {
            event.preventDefault();
            const text = textarea.value;
            if (!text.trim()) return;
            textarea.value = "";
            textarea.disabled = true;
            try {
                await sendMessage(this.playerUserId, text);
            } finally {
                textarea.disabled = false;
                textarea.focus();
            }
        });

        textarea?.addEventListener("keydown", event => {
            if (event.key === "Enter" && !event.shiftKey) {
                event.preventDefault();
                form.requestSubmit();
            }
        });

        this._scrollToBottom();
        markThreadRead(this.playerUserId);
        textarea?.focus();
    }

    /** Called by the module-level createChatMessage hook — no re-render. */
    appendMessage(message) {
        const log = this.element?.querySelector(".drpg-messenger-log");
        if (!log) return;
        log.querySelector(".drpg-messenger-empty")?.remove();
        log.append(buildBubble(message));
        this._scrollToBottom();
        // The window is on screen — count it as read immediately rather than
        // leaving a badge for a conversation the user is looking straight at.
        markThreadRead(this.playerUserId);
    }

    _scrollToBottom() {
        const log = this.element?.querySelector(".drpg-messenger-log");
        if (log) log.scrollTop = log.scrollHeight;
    }

    async close(options) {
        savePosition(this.playerUserId, this.position);
        DrpgMessengerApp.instances.delete(this.playerUserId);
        return super.close(options);
    }
}

// The module-level hook lives here, not per instance: one listener regardless
// of how many windows are open, and nothing to leak when one closes.
Hooks.on("drpgMessengerMessage", (playerUserId, message) => {
    const instance = DrpgMessengerApp.instances.get(playerUserId);
    if (instance) {
        instance.appendMessage(message);
        return;
    }

    // The player's own window is not open — surface the reply the same way
    // every other message on their screen appears, with a click that jumps
    // straight to the conversation. GMs keep the roster badge for this; it
    // already tells them who wrote.
    if (game.user.isGM || game.user.id !== playerUserId) return;
    const authorId = message.author?.id ?? message.user?.id;
    if (authorId === game.user.id) return;

    showPopup(message.content, {
        title: game.i18n.localize("DRPG.Messenger.playerWindowTitle"),
        onClick: () => openMessenger(playerUserId)
    });
});

function participantsLine(player, gms) {
    const names = [player?.name, ...gms.map(g => g.name)].filter(Boolean);
    return names.join(" · ");
}

function emptyNotice() {
    const p = document.createElement("p");
    p.className = "drpg-messenger-empty";
    p.textContent = game.i18n.localize("DRPG.Messenger.noMessagesYet");
    return p;
}

function buildBubble(message) {
    const authorId = message.author?.id ?? message.user?.id;
    const author = game.users.get(authorId);
    const mine = authorId === game.user.id;
    const kind = message.getFlag(MODULE_ID, MESSENGER_FLAGS.kind);
    const isAction = kind === THREAD_KIND.action;

    const bubble = document.createElement("div");
    bubble.className = `drpg-messenger-bubble ${isAction ? "action" : mine ? "mine" : (author?.isGM ? "gm" : "player")}`;
    bubble.dataset.messageId = message.id;

    if (!isAction) {
        const name = document.createElement("div");
        name.className = "drpg-messenger-author";
        name.textContent = author?.name ?? "?";
        bubble.append(name);
    }

    const body = document.createElement("div");
    body.className = "drpg-messenger-text";
    // Both callers of createThreadMessage() already hand over safe HTML —
    // sendMessage() escapes free text before this ever runs, postToThread()
    // is fed the GM-bridge's own escaped ruling cards.
    body.innerHTML = message.content;
    bubble.append(body);

    const time = document.createElement("div");
    time.className = "drpg-messenger-time";
    time.textContent = new Date(message.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    bubble.append(time);

    return bubble;
}

/* ==========================================================================
 * POSITION MEMORY
 * ========================================================================== */

function readSavedPosition(playerUserId) {
    try {
        const all = game.settings.get(MODULE_ID, SETTINGS.messengerWindowPositions) ?? {};
        return all[playerUserId] ?? null;
    } catch {
        return null;
    }
}

function savePosition(playerUserId, position) {
    try {
        const all = game.settings.get(MODULE_ID, SETTINGS.messengerWindowPositions) ?? {};
        const { left, top, width, height } = position ?? {};
        game.settings.set(MODULE_ID, SETTINGS.messengerWindowPositions, {
            ...all,
            [playerUserId]: { left, top, width, height }
        });
    } catch (err) {
        error("Messenger: could not save window position.", err);
    }
}

/* ==========================================================================
 * THE LAUNCHER
 * --------------------------------------------------------------------------
 * Deliberately its own floating element rather than DOM injected into the
 * Players sidebar or the campaign HUD — both are foreign or shared territory
 * whose structure this module does not own. A self-built button in a fixed
 * corner cannot be broken by either one changing shape.
 * ========================================================================== */

export function renderLauncher() {
    try {
        document.getElementById(LAUNCHER_ID)?.remove();

        const button = document.createElement("button");
        button.type = "button";
        button.id = LAUNCHER_ID;
        button.dataset.tooltip = launcherTooltip();
        button.setAttribute("aria-label", launcherTooltip());
        button.innerHTML = `<i class="fa-solid fa-comments" inert></i>`;

        const unread = game.user.isGM
            ? threadUsers().reduce((sum, u) => sum + unreadCount(u.id), 0)
            : totalUnread();
        if (unread > 0) {
            const badge = document.createElement("span");
            badge.className = "drpg-messenger-badge";
            badge.textContent = unread > 99 ? "99+" : String(unread);
            button.append(badge);
        }

        button.addEventListener("click", event => {
            event.preventDefault();
            event.stopPropagation();
            if (game.user.isGM) toggleRoster(button);
            else openMessenger(game.user.id);
        });

        document.body.append(button);
    } catch (err) {
        error("Could not render the messenger launcher", err);
    }
}

function launcherTooltip() {
    return game.i18n.localize("DRPG.Messenger.launcherTooltip");
}

function toggleRoster(anchor) {
    const existing = document.getElementById("drpg-messenger-roster");
    if (existing) {
        existing.remove();
        return;
    }
    buildRoster(anchor);
}

function buildRoster(anchor) {
    const panel = document.createElement("div");
    panel.id = "drpg-messenger-roster";

    const title = document.createElement("h4");
    title.textContent = game.i18n.localize("DRPG.Messenger.rosterTitle");
    panel.append(title);

    const players = threadUsers();
    if (!players.length) {
        const empty = document.createElement("p");
        empty.className = "drpg-messenger-empty";
        empty.textContent = game.i18n.localize("DRPG.Messenger.rosterEmpty");
        panel.append(empty);
    } else {
        const list = document.createElement("ul");
        for (const user of players.sort((a, b) => a.name.localeCompare(b.name))) {
            list.append(rosterRow(user));
        }
        panel.append(list);
    }

    document.body.append(panel);

    // Close on an outside click, but not on the click that just opened it.
    setTimeout(() => document.addEventListener("click", onOutsideClick, { once: true }), 0);
    function onOutsideClick(event) {
        if (panel.contains(event.target) || event.target === anchor) return;
        panel.remove();
    }
}

function rosterRow(user) {
    const li = document.createElement("li");
    li.className = "drpg-messenger-roster-row";

    const last = lastMessage(user.id);
    const preview = last ? stripHtml(last.content) : game.i18n.localize("DRPG.Messenger.rosterNoMessages");
    const unread = unreadCount(user.id);

    const name = document.createElement("div");
    name.className = "drpg-messenger-roster-name";
    name.textContent = user.name;

    const snippet = document.createElement("div");
    snippet.className = "drpg-messenger-roster-preview";
    snippet.textContent = preview;

    const text = document.createElement("div");
    text.className = "drpg-messenger-roster-text";
    text.append(name, snippet);
    li.append(text);

    if (unread > 0) {
        const badge = document.createElement("span");
        badge.className = "drpg-messenger-badge";
        badge.textContent = unread > 99 ? "99+" : String(unread);
        li.append(badge);
    }

    li.addEventListener("click", () => {
        document.getElementById("drpg-messenger-roster")?.remove();
        openMessenger(user.id);
    });

    return li;
}

function stripHtml(html) {
    return String(html ?? "").replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
}
