/**
 * Danganronpa RPG — GM panel.
 * ---------------------------------------------------------------------------
 * The handful of things a GM does every time of day, behind one button in the
 * token toolbar: move the clock, refill actions, restock search tokens, check
 * where everyone stands.
 */

import { MODULE_ID, FLAGS, TIMES_OF_DAY, TIME_OF_DAY_LABELS, PHASES, CHAPTERS_PER_SEASON } from "./config.mjs";
import { getClock, setClock, setTimeOfDay, clockSummary, timeOfDayLabel, phaseLabel, campaignName } from "./clock.mjs";
import { resetAllActions, actionsLeft, actionsMax, hasFreeMove } from "./actions.mjs";
import { SearchTokens } from "./search-tokens.mjs";
import { dialogContent, error } from "./utils.mjs";

const DialogV2 = foundry.applications.api.DialogV2;

/** Add the panel button to the token toolbar, GM only. */
export function registerGmPanel() {
    Hooks.on("getSceneControlButtons", controls => {
        if (!game.user.isGM) return;
        const tokens = controls.tokens;
        if (!tokens?.tools) return;

        tokens.tools.drpgGmPanel = {
            name: "drpgGmPanel",
            title: "DRPG.Panel.title",
            icon: "fa-solid fa-clock",
            button: true,
            visible: true,
            onChange: () => openGmPanel()
        };
    });
}

/**
 * Everything the panel can do, grouped by WHEN a GM reaches for it.
 *
 * This used to be two flat rows of dialog buttons — one on the panel and one
 * behind "More…" — and by the time the murder engine landed the second row was
 * sixteen buttons long, in the order they happened to be written. Ordering by
 * moment instead means the answer to "where is that thing" is "when do I use
 * it", which is a question a GM can actually answer mid-session.
 *
 * `dim` marks the ones that are situational rather than part of the flow, so
 * they read as a toolbox rather than as steps.
 */
const PANEL_SECTIONS = [
    {
        key: "now",
        items: [
            { key: "eclipse", icon: "fa-moon", labelKey: "DRPG.Eclipse.button",
              run: () => toggleEclipse() },
            { key: "music", icon: "fa-music", labelKey: "DRPG.Music.title",
              run: () => import("./music.mjs").then(m => m.openMusicDialog()) },
            { key: "voiceEavesdrop", icon: "fa-headphones", labelKey: "DRPG.Panel.voiceEavesdrop",
              run: () => import("./voice.mjs").then(m => m.openEavesdropDialog()) },
            { key: "jump", icon: "fa-calendar-days", labelKey: "DRPG.Panel.jump",
              run: () => openClockDialog() },
            { key: "rules", icon: "fa-gavel", labelKey: "DRPG.Rules.manageTitle",
              run: () => import("./rules.mjs").then(m => m.openRulesManager()) }
        ]
    },
    {
        key: "case",
        items: [
            { key: "murder", icon: "fa-skull", labelKey: "DRPG.Murder.openTitle",
              run: () => import("./murder.mjs").then(m => m.openMurderDialog()) },
            { key: "investigation", icon: "fa-magnifying-glass-chart",
              labelKey: "DRPG.Investigation.dashboardTitle",
              run: () => import("./investigation.mjs").then(m => m.openInvestigationDashboard()) },
            { key: "bodyFound", icon: "fa-person-falling", labelKey: "DRPG.Chapter.bodyTitle",
              run: () => import("./chapter.mjs").then(m => m.openBodyDiscoveryDialog()) },
            { key: "autopsy", icon: "fa-notes-medical", labelKey: "DRPG.TruthBullet.autopsyTitle",
              run: () => import("./gm-items.mjs").then(m => m.issueAutopsyDialog()) },
            // `fa-hazard` is not a Font Awesome icon, so this tile rendered with
            // an empty square where every other one has a glyph.
            { key: "manageRemnants", icon: "fa-triangle-exclamation", labelKey: "DRPG.Remnant.manageTooltip",
              run: () => import("./remnants.mjs").then(m => m.openRemnantManager()) },
            { key: "objectionLog", icon: "fa-gavel", labelKey: "DRPG.Trial.logTitle",
              run: () => import("./trial.mjs").then(m => m.openObjectionLog()) }
        ]
    },
    {
        key: "trial",
        items: [
            { key: "floor", icon: "fa-microphone-lines", labelKey: "DRPG.Floor.manageTitle",
              run: () => import("./trial-floor-ui.mjs").then(m => m.openFloorDialog()) },
            { key: "vote", icon: "fa-check-to-slot", labelKey: "DRPG.Vote.openTitle",
              run: () => import("./trial-floor-ui.mjs").then(m => m.openVoteDialog()) },
            { key: "verdict", icon: "fa-scale-balanced", labelKey: "DRPG.Vote.verdictTitle",
              run: () => import("./vote.mjs").then(m => m.openVerdictDialog()) }
        ]
    },
    {
        key: "season",
        items: [
            { key: "mastermind", icon: "fa-user-secret", labelKey: "DRPG.Mastermind.dialogTitle",
              run: () => import("./mastermind.mjs").then(m => m.openMastermindDialog()) },
            { key: "finalTrialToggle", icon: "fa-flag-checkered", labelKey: "DRPG.Mastermind.toggleFinalTrial",
              run: () => toggleFinalTrial() },
            { key: "finalVerdict", icon: "fa-crown", labelKey: "DRPG.Mastermind.verdictTitle",
              run: () => import("./mastermind.mjs").then(m => m.openFinalVerdictDialog()) }
        ]
    },
    {
        key: "people",
        items: [
            { key: "items", icon: "fa-box-open", labelKey: "DRPG.Items.manage",
              run: () => import("./gm-items.mjs").then(m => m.openItemManager()) },
            { key: "vaultInspect", icon: "fa-box-archive", labelKey: "DRPG.Vault.inspectTitle",
              run: () => import("./vault.mjs").then(m => m.openVaultInspector()) },
            { key: "death", icon: "fa-skull-crossbones", labelKey: "DRPG.Chapter.deathTitle",
              run: () => import("./chapter.mjs").then(m => m.openDeathDialog()) },
            { key: "monocub", icon: "fa-ghost", labelKey: "DRPG.Monocub.manageTitle",
              run: () => import("./monocub.mjs").then(m => m.openMonocubDialog()) },
            { key: "chapterEnd", icon: "fa-flag-checkered", labelKey: "DRPG.Chapter.endTitle",
              run: () => import("./chapter.mjs").then(m => m.openChapterEndDialog()) }
        ]
    },
    {
        key: "setup",
        items: [
            { key: "gmTeam", icon: "fa-users-gear", labelKey: "DRPG.Panel.gmTeam",
              run: () => import("./gm-team-dialog.mjs").then(m => m.openGmTeamDialog()) },
            // Room Setup now carries the rest columns too, so the separate
            // "which rooms allow rest" entry would open the same window twice.
            { key: "roomSetup", icon: "fa-door-closed", labelKey: "DRPG.Vault.manageTitle",
              run: () => import("./vault.mjs").then(m => m.openRoomSetupDialog()) },
            { key: "installTables", icon: "fa-table-list", labelKey: "DRPG.Panel.installTables",
              run: () => import("./tables.mjs").then(m => m.installTables()) },
            // Two checks that were only ever reachable from the console, and both
            // of them answer a question you want answered BEFORE a session rather
            // than after: is everybody set up, and can anybody read a sheet they
            // should not.
            { key: "checkCharacters", icon: "fa-wand-sparkles", labelKey: "DRPG.Panel.checkCharacters",
              run: () => import("./diagnostics.mjs").then(m => m.diagnoseCharacters()) },
            { key: "auditAnonymity", icon: "fa-user-shield", labelKey: "DRPG.Panel.audit",
              run: () => import("./anonymity.mjs").then(m => m.auditAnonymity()) }
        ]
    },
    {
        key: "fixes",
        dim: true,
        items: [
            { key: "resetActions", icon: "fa-rotate-left", labelKey: "DRPG.Panel.resetActions",
              run: async () => {
                  const results = await resetAllActions();
                  ui.notifications.info(game.i18n.format("DRPG.Panel.actionsReset",
                      { count: results.length }));
              } },
            { key: "resetSearch", icon: "fa-arrows-rotate", labelKey: "DRPG.Panel.resetSearch",
              run: () => SearchTokens.reset() },
            { key: "showSearch", icon: "fa-list-check", labelKey: "DRPG.Panel.showSearch",
              run: () => SearchTokens.report() },
            // The only destructive tile in the panel, and it reaches every
            // scene at once. It used to delete on the first click and report
            // the count afterwards — which is the wrong order for tokens that
            // do not come back. Counted first, confirmed, then done.
            { key: "clearFaint", icon: "fa-broom", labelKey: "DRPG.Panel.clearFaint",
              run: async () => {
                  const { clearFaintRemnants, remnantsOn, remnantData } =
                      await import("./remnants.mjs");

                  let doomed = 0;
                  for (const scene of game.scenes) {
                      doomed += remnantsOn(scene).filter(t => {
                          const d = remnantData(t);
                          return d?.faint && !d.reinforced && !d.tiedToCrime;
                      }).length;
                  }

                  if (!doomed) {
                      ui.notifications.info(game.i18n.localize("DRPG.Panel.faintNone"));
                      return;
                  }

                  const sure = await DialogV2.confirm({
                      window: { title: game.i18n.localize("DRPG.Panel.clearFaint") },
                      classes: ["drpg-panel"],
                      content: `<p>${game.i18n.format("DRPG.Panel.faintConfirm", { n: doomed })}</p>
                                <p class="notes">${game.i18n.localize("DRPG.Panel.faintConfirmNote")}</p>`,
                      rejectClose: false
                  });
                  if (!sure) return;

                  ui.notifications.info(game.i18n.format("DRPG.Panel.faintCleared",
                      { n: await clearFaintRemnants() }));
              } },
            { key: "voiceReset", icon: "fa-tower-broadcast", labelKey: "DRPG.Panel.voiceReset",
              run: async () => {
                  const { resetAllVoice } = await import("./voice.mjs");
                  const n = await resetAllVoice();
                  // null means it refused: voice is off, or this is not the one
                  // GM client that runs it. Saying "0 sent back" for that is a
                  // report of success on a button that did nothing.
                  if (n === null) {
                      ui.notifications.warn(game.i18n.localize("DRPG.Voice.resetRefused"));
                      return;
                  }
                  ui.notifications.info(game.i18n.format("DRPG.Voice.resetDone", { n }));
              } }
        ]
    }
];

/** Open the panel. */
export async function openGmPanel() {
    if (!game.user.isGM) {
        ui.notifications.warn(game.i18n.localize("DRPG.Panel.gmOnly"));
        return;
    }

    const sections = PANEL_SECTIONS.map(section => `
        <div class="drpg-gmp-section${section.dim ? " dim" : ""}">
            <h4>${game.i18n.localize(`DRPG.Panel.section.${section.key}`)}</h4>
            <div class="drpg-gmp-grid">${section.items.map(item => `
                <button type="button" class="drpg-gmp-button" data-drpg-run="${item.key}">
                    <i class="fa-solid ${item.icon}" inert></i>
                    <span>${game.i18n.localize(item.labelKey)}</span>
                </button>`).join("")}</div>
        </div>`).join("");

    const body = dialogContent(`<div class="drpg-gm-panel">
        ${buildPanelContent()}
        ${sections}
    </div>`);

    const lookup = new Map(PANEL_SECTIONS.flatMap(s => s.items.map(i => [i.key, i])));

    await DialogV2.wait({
        window: { title: game.i18n.localize("DRPG.Panel.title") },
        classes: ["drpg-panel", "drpg-gm-panel-window"],
        content: body,
        buttons: [{ action: "close", label: game.i18n.localize("DRPG.Panel.close"), default: true }],
        // Each tile closes the panel, does its thing, and the panel comes BACK.
        //
        // Closing first has always mattered: most of these open a dialog of
        // their own, and stacking one on top of the panel it came from is how a
        // GM loses track of which window they are answering. What was missing
        // was the other half. A GM's work is rarely one tile — place a Remnant,
        // check the dashboard, advance the clock — and each of those meant
        // finding the panel again from the scene controls. The incident tracker
        // has always reopened itself after every action; this is the same idea,
        // applied to the screen that is opened more often than any other.
        //
        // Every tile here awaits a dialog of its own, so by the time `run()`
        // resolves the screen is clear again and the panel can come back.
        // Reopened only when a tile was actually used, never when the panel was
        // dismissed.
        render: (event, dialog) => {
            for (const button of dialog.element.querySelectorAll("[data-drpg-run]")) {
                button.addEventListener("click", async ev => {
                    ev.preventDefault();
                    const item = lookup.get(button.dataset.drpgRun);
                    if (!item) return;
                    await dialog.close();
                    try {
                        await item.run();
                    } catch (err) {
                        error(`GM panel action "${item.key}" failed`, err);
                        ui.notifications.error(game.i18n.localize("DRPG.Panel.failed"));
                    }
                    openGmPanel().catch(err =>
                        error("Could not reopen the GM panel", err));
                });
            }
        },
        rejectClose: false
    });
}

/**
 * Start the placement window, or close it and begin the time of day.
 * When closing, shows who has actually finished placing.
 */
/**
 * Announce (or end) the Final Trial. World-scoped and public on purpose — the
 * table already knows the endgame trial is happening the moment it starts;
 * only the Mastermind's identity stays hidden, and that lives elsewhere.
 */
async function toggleFinalTrial() {
    const { inFinalTrial, setFinalTrial } = await import("./mastermind.mjs");
    const next = !inFinalTrial();

    const sure = await DialogV2.confirm({
        window: { title: game.i18n.localize("DRPG.Mastermind.toggleFinalTrial") },
        content: `<p>${game.i18n.localize(
            next ? "DRPG.Mastermind.confirmStart" : "DRPG.Mastermind.confirmEnd")}</p>`
    });
    if (!sure) return;

    await setFinalTrial(next);
    ui.notifications.info(game.i18n.localize(
        next ? "DRPG.Mastermind.started" : "DRPG.Mastermind.ended"));
}

async function toggleEclipse() {
    const { isEclipse, startEclipse, endEclipse, placementStatus, ECLIPSE_MOVES } = await import("./eclipse.mjs");

    if (!isEclipse()) return startEclipse();

    const rows = placementStatus().map(s => `
        <tr${s.left === ECLIPSE_MOVES ? ' style="opacity:.55"' : ""}>
            <td>${foundry.utils.escapeHTML(s.actor.name)}</td>
            <td>${foundry.utils.escapeHTML(s.room ?? "—")}</td>
            <td style="text-align:center">${s.moved} / ${ECLIPSE_MOVES}</td>
        </tr>`).join("");

    const choice = await DialogV2.wait({
        window: { title: game.i18n.localize("DRPG.Eclipse.title") },
        classes: ["drpg-panel"],
        content: `<p>${game.i18n.localize("DRPG.Eclipse.endPrompt")}</p>
            <table><thead><tr>
                <th>${game.i18n.localize("DRPG.Panel.character")}</th>
                <th>${game.i18n.localize("DRPG.Project.room")}</th>
                <th>${game.i18n.localize("DRPG.Eclipse.movesColumn")}</th>
            </tr></thead><tbody>${rows}</tbody></table>`,
        buttons: [
            { action: "end", label: game.i18n.localize("DRPG.Eclipse.endAndAdvance"), default: true },
            { action: "endOnly", label: game.i18n.localize("DRPG.Eclipse.endOnly") },
            { action: "cancel", label: game.i18n.localize("DRPG.Panel.close") }
        ],
        rejectClose: false
    });

    if (choice === "end") return endEclipse({ advance: true });
    if (choice === "endOnly") return endEclipse({ advance: false });
    return null;
}

/** Current standing: where the clock is and what everyone has left. */
function buildPanelContent() {
    const clock = getClock();

    // The living cast, and only them.
    //
    // This listed every `character` actor, which meant the GM's own Monokumas
    // sat in the middle of it reading "0 / 0" — they have no action economy by
    // design — and so did every corpse. The one question this table answers is
    // "who still has actions left", and neither of those can have any. A
    // Monocub stays: they spend a real budget on Move and Meddle.
    const roster = game.actors.filter(a => {
        if (a.type !== "character") return false;
        if (a.getFlag(MODULE_ID, FLAGS.monokuma)) return false;
        if (a.getFlag(MODULE_ID, FLAGS.deceased) && !a.getFlag(MODULE_ID, FLAGS.monocub)) return false;
        return true;
    });

    const rows = roster
        .map(a => {
            const left = actionsLeft(a);
            const max = actionsMax(a);
            const move = hasFreeMove(a)
                ? `<i class="fa-solid fa-shoe-prints" title="free Move available"></i>`
                : "—";
            const cub = a.getFlag(MODULE_ID, FLAGS.monocub)
                ? ` <span class="notes">(${game.i18n.localize("DRPG.Monocub.isOne")})</span>` : "";
            const low = left === 0 ? ' style="opacity:.55"' : "";
            return `<tr${low}>
                        <td>${foundry.utils.escapeHTML(a.name)}${cub}</td>
                        <td style="text-align:center">${left} / ${max}</td>
                        <td style="text-align:center">${move}</td>
                    </tr>`;
        })
        .join("");

    const table = rows
        ? `<table>
             <thead><tr>
               <th>${game.i18n.localize("DRPG.Panel.character")}</th>
               <th style="text-align:center">${game.i18n.localize("DRPG.Actions.label")}</th>
               <th style="text-align:center">${game.i18n.localize("DRPG.Panel.freeMove")}</th>
             </tr></thead>
             <tbody>${rows}</tbody>
           </table>`
        : `<p>${game.i18n.localize("DRPG.Panel.noCharacters")}</p>`;

    return `<div>
                <h3>${foundry.utils.escapeHTML(campaignName(clock))}</h3>
                <p><strong>${game.i18n.format("DRPG.Hud.chapter", { n: clock.chapter })}
                   · ${phaseLabel(clock.phase)}
                   · ${timeOfDayLabel(clock.timeOfDay)}</strong></p>
                <p>${clockSummary(clock)}</p>
                ${table}
            </div>`;
}

/* ==========================================================================
 * SUB-DIALOGS
 * ========================================================================== */

/**
 * Edit everything the HUD shows: campaign name, chapter, phase, session and
 * time of day. Reachable only from the GM panel — deliberately not on the
 * HUD itself, which every player is looking at for the rest of the session.
 */
export async function openClockDialog() {
    if (!game.user.isGM) {
        ui.notifications.warn(game.i18n.localize("DRPG.Panel.gmOnly"));
        return;
    }

    const clock = getClock();

    const times = TIMES_OF_DAY
        .map(t => `<option value="${t}"${t === clock.timeOfDay ? " selected" : ""}>${TIME_OF_DAY_LABELS[t]}</option>`)
        .join("");

    const phases = Object.entries(PHASES)
        .map(([key, p]) => `<option value="${key}"${key === clock.phase ? " selected" : ""}>${p.label}</option>`)
        .join("");

    const chapters = Array.from({ length: CHAPTERS_PER_SEASON }, (_, i) => i + 1)
        .map(n => `<option value="${n}"${n === clock.chapter ? " selected" : ""}>${n}</option>`)
        .join("");

    const result = await DialogV2.wait({
        window: { title: game.i18n.localize("DRPG.Panel.jump") },
        classes: ["drpg-panel"],
        content: `<form>
                    <label>${game.i18n.localize("DRPG.Clock.campaignName")}
                        <input type="text" name="campaignName"
                               value="${foundry.utils.escapeHTML(clock.campaignName ?? "")}"
                               placeholder="${foundry.utils.escapeHTML(game.world?.title ?? "")}" />
                    </label>
                    <label>${game.i18n.localize("DRPG.Clock.chapter")}
                        <select name="chapter">${chapters}</select>
                    </label>
                    <label>${game.i18n.localize("DRPG.Clock.phase")}
                        <select name="phase">${phases}</select>
                    </label>
                    <label>${game.i18n.localize("DRPG.Clock.day")}
                        <input type="number" name="day" value="${clock.day ?? 1}" min="1" step="1" />
                    </label>
                    <label>${game.i18n.localize("DRPG.Clock.session")}
                        <input type="number" name="session" value="${clock.session}" min="1" step="1" />
                    </label>
                    <label>${game.i18n.localize("DRPG.Clock.timeOfDay")}
                        <select name="timeOfDay">${times}</select>
                    </label>
                    <hr />
                    <label class="drpg-checkbox">
                        <input type="checkbox" name="reset" />
                        ${game.i18n.localize("DRPG.Panel.alsoReset")}
                    </label>
                    <p class="notes">${game.i18n.localize("DRPG.Panel.resetHint")}</p>
                  </form>`,
        buttons: [
            {
                action: "ok",
                label: game.i18n.localize("DRPG.Panel.apply"),
                default: true,
                callback: (event, button, dialog) => {
                    const form = dialog.element.querySelector("form");
                    return {
                        campaignName: form.campaignName.value.trim(),
                        chapter: Number(form.chapter.value) || 1,
                        day: Number(form.day.value) || 1,
                        phase: form.phase.value,
                        session: Number(form.session.value) || 1,
                        timeOfDay: form.timeOfDay.value,
                        reset: form.reset.checked
                    };
                }
            },
            { action: "cancel", label: game.i18n.localize("DRPG.Panel.close") }
        ],
        rejectClose: false
    });

    if (!result || result === "cancel") return;

    await setClock({
        campaignName: result.campaignName,
        chapter: result.chapter,
        day: result.day,
        phase: result.phase,
        session: result.session,
        timeOfDay: result.timeOfDay
    });

    // Editing the clock is bookkeeping. Only refill when explicitly asked,
    // otherwise a typo correction would hand everyone fresh actions.
    if (result.reset) {
        await setTimeOfDay(result.timeOfDay, {
            resetActions: true,
            resetSearchTokens: true,
            announce: true
        });
    }
}
