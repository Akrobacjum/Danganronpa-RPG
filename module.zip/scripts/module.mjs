/**
 * Danganronpa RPG — module entry point.
 * ---------------------------------------------------------------------------
 * A thin layer on top of the Daggerheart system (Foundryborne) that turns it
 * into the Danganronpa RPG System described in the full guide.
 *
 * This file only wires things together. The actual work lives in:
 *   config.mjs         every rule, threshold and table from the guide
 *   settings.mjs       world settings
 *   private-rolls.mjs  players never see each other's dice
 *   search-tokens.mjs  three search tokens per room, per time of day
 *   api.mjs            game.drpg — the surface macros are allowed to call
 */

import { MODULE_ID } from "./config.mjs";
import { registerSettings } from "./settings.mjs";
import { registerPrivateRolls } from "./private-rolls.mjs";
import { registerSearchTokenSocket } from "./search-tokens.mjs";
import { registerSheetTweaks } from "./sheet.mjs";
import { registerAnonymity } from "./anonymity.mjs";
import { registerActionResource } from "./resources.mjs";
import { registerGmPanel } from "./gm-panel.mjs";
import { registerHud } from "./hud.mjs";
import { registerDespair } from "./despair.mjs";
import { registerDespairAwards } from "./despair-award.mjs";
import { registerMovement } from "./movement.mjs";
import { registerProjectsUi } from "./projects-ui.mjs";
import { registerGmBridge } from "./gm-bridge.mjs";
import { registerInventoryLimits } from "./inventory.mjs";
import { registerTruthBullets } from "./truth-bullets.mjs";
import { registerTrial } from "./trial.mjs";
import { registerMurder } from "./murder.mjs";
import { registerTrialFloor } from "./trial-floor.mjs";
import { registerVote } from "./vote.mjs";
import { registerMastermind } from "./mastermind.mjs";
import { registerResourceGuard } from "./resource-guard.mjs";
import { registerStates } from "./states.mjs";
import { registerVisibility } from "./visibility.mjs";
import { registerRollDialog } from "./roll-dialog.mjs";
import { registerForcedRolls } from "./forced-roll.mjs";
import { registerEclipse } from "./eclipse.mjs";
import { registerMonokuma } from "./monokuma.mjs";
import { registerMessenger } from "./messenger.mjs";
import { registerMessengerUi } from "./messenger-app.mjs";
import { registerVoice } from "./voice.mjs";
import { registerVoiceClient } from "./voice-client.mjs";
import { registerMusic } from "./music.mjs";
import { registerCameraView } from "./camera-view.mjs";
import { registerPopups } from "./popup.mjs";
import { registerDiceSync } from "./dice-sync.mjs";
import { registerSync } from "./sync.mjs";
import { SETTINGS, getSetting } from "./settings.mjs";
import { registerApi } from "./api.mjs";
import { log, error } from "./utils.mjs";

/** Minimum Daggerheart version this layer was written against. */
const REQUIRED_SYSTEM = "daggerheart";
const REQUIRED_SYSTEM_VERSION = "2.6.0";

/**
 * Register one subsystem without letting it take the others down.
 *
 * These used to run as a bare sequence, which made the list an accidental
 * dependency chain: anything that threw — a renamed hook, a system version that
 * builds a config table differently — silently prevented every registration
 * *after* it. The failure never looked like what it was, because the symptom
 * was whichever features happened to sit lower in the list.
 */
function safely(label, fn) {
    try {
        fn();
    } catch (err) {
        error(`Could not register ${label}; the rest of the module continues.`, err);
    }
}

Hooks.once("init", () => {
    log("Initialising the Danganronpa RPG layer.");

    // Settings first and unguarded: every other subsystem reads them, so if this
    // cannot run there is nothing worth continuing to.
    registerSettings();

    safely("private rolls", registerPrivateRolls);
    safely("sheet tweaks", registerSheetTweaks);
    safely("anonymity", registerAnonymity);
    safely("the GM panel", registerGmPanel);
    safely("the campaign HUD", registerHud);
    safely("Despair pools", registerDespair);
    safely("Despair awards", registerDespairAwards);
    safely("movement", registerMovement);
    safely("the projects tray", registerProjectsUi);
    safely("inventory limits", registerInventoryLimits);
    safely("the resource guard", registerResourceGuard);
    // Registers the Breakdown/Wounded conditions on `setup` and takes the two
    // equivalent automations off Daggerheart at `ready`.
    safely("Breakdown and Wounded", registerStates);
    safely("room visibility", registerVisibility);
    safely("the roll dialog lock", registerRollDialog);
    safely("forced rolls", registerForcedRolls);
    safely("the Eclipse", registerEclipse);
    safely("Monokumas", registerMonokuma);
    safely("the messenger", registerMessenger);
    safely("the messenger UI", registerMessengerUi);
    safely("regional voice", registerVoice);
    // The receiving half, on every client. Separate from the deciding half
    // above because a player has to be able to apply a room and to ask which
    // one they belong in — see voice-client.mjs.
    safely("the voice client", registerVoiceClient);
    // Playlists are world documents, so one client driving them is heard by
    // everyone — no socket, unlike voice. See music.mjs.
    safely("the music", registerMusic);
    safely("the camera dock", registerCameraView);
    safely("popups", registerPopups);
    // After popups: a presented Truth Bullet becomes one, so the container has
    // to exist by the time the first card lands.
    safely("the Class Trial", registerTrial);
    safely("the trial floor", registerTrialFloor);
    // Watches for somebody walking into an incident — the guide's "automatyczny,
    // darmowy wybór" for a third party, which until now waited on a GM noticing.
    safely("the murder watch", registerMurder);

    // The system builds CONFIG.DH during its own init hook. Systems load before
    // modules, so this normally succeeds here; `setup` is the safety net.
    safely("the Actions resource", registerActionResource);
});

Hooks.once("setup", () => {
    safely("the Actions resource", registerActionResource);
});

Hooks.once("ready", () => {
    safely("the API", registerApi);
    // Before the other socket listeners: this is the one that carries world-state
    // changes to the players. Without it `broadcast()` emits into a socket nobody
    // is listening on, and the clock, the Eclipse and every Despair Call
    // restriction advance on the GM's screen alone.
    safely("world-state sync", registerSync);
    safely("the search-token socket", registerSearchTokenSocket);
    safely("the GM bridge", registerGmBridge);
    // After the API, because the migration it kicks off reads the clock, and
    // after the other socket listeners for the same reason they are ordered:
    // the GM-to-GM ledger sync is a socket conversation like any other.
    safely("Truth Bullets", registerTruthBullets);
    // After the other socket listeners: a ballot is addressed to the GMs and
    // tallied in memory, so it needs the socket up and nothing else.
    safely("the vote", registerVote);
    // Same requirements as Truth Bullets: needs the socket and `game.users`
    // populated, and asks the other GMs for the pick if this browser has none.
    safely("the Mastermind", registerMastermind);
    safely("dice appearance sync", registerDiceSync);
    safely("body classes", applyBodyClasses);
    safely("the system check", verifySystem);
    safely("project secrecy", sealProjects);
});

/**
 * Re-apply secrecy to every project that claims to be secret.
 *
 * Two reasons this cannot be a one-off at creation. Projects made before the
 * ownership rules were understood carry a `default: 0` that Daggerheart ignores,
 * so they are still on show. And the ownership map only ever lists the users who
 * existed when it was written — a player added to the world later has no entry,
 * Daggerheart falls back to the world default of OBSERVER, and they can read
 * somebody's murder plan. Running this on load and whenever a user appears keeps
 * that window shut.
 */
function sealProjects() {
    if (!game.user.isGM) return;

    const reseal = () => import("./projects.mjs")
        .then(m => m.resealSecretProjects())
        .catch(err => error("Could not re-seal the secret projects", err));

    reseal();
    Hooks.on("createUser", reseal);
}

/**
 * Toggles that CSS keys off. Kept on `body` rather than on any one widget so a
 * UI module reshuffling the interface cannot detach them.
 */
function applyBodyClasses() {
    document.body.classList.toggle("drpg-hide-system-fear", getSetting(SETTINGS.hideSystemFear));
    document.body.classList.toggle("drpg-pixel-font", getSetting(SETTINGS.pixelFont));
    // CSS uses this to make Hope and traits display-only for players.
    document.body.classList.toggle("drpg-gm", game.user.isGM);
}

/**
 * Refuse to pretend everything is fine on the wrong system. The whole layer
 * assumes Daggerheart's duality roll, Hope/Fear pools and trait keys.
 */
function verifySystem() {
    if (game.system.id !== REQUIRED_SYSTEM) {
        const msg = game.i18n.format("DRPG.Errors.wrongSystem", { found: game.system.id });
        error(msg);
        if (game.user.isGM) ui.notifications.error(msg, { permanent: true });
        return;
    }

    const tooOld = foundry.utils.isNewerVersion(REQUIRED_SYSTEM_VERSION, game.system.version);
    if (tooOld && game.user.isGM) {
        ui.notifications.warn(game.i18n.format("DRPG.Errors.oldSystem", {
            required: REQUIRED_SYSTEM_VERSION,
            found: game.system.version
        }));
    }
}

export { MODULE_ID };
