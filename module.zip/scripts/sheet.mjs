/**
 * Danganronpa RPG — character sheet surgery.
 * ---------------------------------------------------------------------------
 * The guide's sheet has no class, subclass, ancestry or community. What sits
 * under the character's name is their Ultimate: "the thing this character does
 * best". Daggerheart renders that row as `.character-details`, so we replace
 * its contents with an editable Ultimate line.
 *
 * Everything else that gets removed (Loadout tab, armour, proficiency, damage
 * thresholds, the Daggerheart level pill) is handled in danganronpa.css. Only
 * the parts that need real behaviour live here.
 */

import { MODULE_ID, FLAGS, ACTIONS, STARTING, ITEM_CATEGORIES, MONOCUB, ECLIPSE_MOVES } from "./config.mjs";
import { actionsLeft, actionsMax, actionBudget, hasFreeMove, setActions } from "./actions.mjs";
import { isMonokuma, poolUserFor } from "./monokuma.mjs";
import { getDespair } from "./despair.mjs";
import { hopeHeld, hopeMax, affordableHopeCalls, despairCallsFor } from "./calls.mjs";
import { isEclipse, movesLeft as eclipseMovesLeft } from "./eclipse.mjs";
import { isTruthBullet, truthBulletData, isAnalysable } from "./truth-bullets.mjs";
import { inClassTrial } from "./trial.mjs";
import { vaultRoomFor, vaultContents, openStashHere } from "./vault.mjs";
import { availableCrisisActions, isTheirTurn } from "./murder.mjs";
import { isMonocub, isSilenced } from "./monocub.mjs";
import { isDeceased } from "./chapter.mjs";
import { isStashed } from "./inventory.mjs";
import { isUsable, isEquippable, isEquipped } from "./use-items.mjs";
import { debug, error } from "./utils.mjs";

export function registerSheetTweaks() {
    // ApplicationV2 fires a render hook per class in the inheritance chain,
    // so the concrete Daggerheart sheet class name is the precise target.
    Hooks.on("renderCharacterSheet", onRenderCharacterSheet);
}

function onRenderCharacterSheet(app, element) {
    try {
        if (app?.document?.type !== "character") return;
        // CSS keys off this to grey out the parts a Monokuma does not use.
        const root = element instanceof HTMLElement ? element : element?.[0];
        root?.classList?.toggle("drpg-monokuma", isMonokuma(app.document));

        frameTraits(element);
        injectUltimate(app, element);
        injectAdvanceButton(app, element);
        injectItemButton(app, element);
        injectActionBar(app, element);
        injectActionPanel(app, element);
        tidySidebar(element);
        tidyBiography(element);
        groupInventory(app, element);
    } catch (err) {
        error("Failed to render the Danganronpa sheet parts", err);
    }
}

/* ==========================================================================
 * TRAIT FRAMES
 * --------------------------------------------------------------------------
 * The purple rectangle around each trait value used to be pure CSS, hung off
 * Daggerheart's `.trait-value-area`. That worked on one install and not on
 * another with the identical stylesheet, which means the selector — not the
 * rule — is what varies: a system build, a UI module or a sheet replacement
 * that renders the trait block under different class names leaves the CSS with
 * nothing to match and no way to say so.
 *
 * So the frame is claimed here instead. The element is found by several routes,
 * tagged with our own class, and styled off that. A class this file puts there
 * cannot be renamed by anyone else, and the fallback below means even a sheet
 * that has no `.trait-value-area` at all still gets framed around whatever holds
 * the number.
 * ========================================================================== */

const TRAIT_AREA_SELECTORS = [
    ".character-header-sheet .character-traits .trait .trait-value-area",
    ".character-traits .trait .trait-value-area",
    ".character-traits .trait-value-area",
    ".trait .trait-value-area"
];

function frameTraits(element) {
    for (const selector of TRAIT_AREA_SELECTORS) {
        const areas = element.querySelectorAll(selector);
        if (!areas.length) continue;
        areas.forEach(area => area.classList.add("drpg-trait-frame"));
        return;
    }

    // Nothing named `trait-value-area` on this sheet. Frame the box the trait
    // number sits in, whatever it is called.
    const values = element.querySelectorAll(".character-traits .trait-value, .trait .trait-value");
    for (const value of values) {
        (value.closest(".trait") ?? value.parentElement ?? value).classList.add("drpg-trait-frame");
    }
}

/* ==========================================================================
 * ACTION BAR + TIME OF DAY
 * --------------------------------------------------------------------------
 * Daggerheart only shows extra resources inside a pop-out tooltip, which is no
 * good for something spent twice per time of day. This draws the budget right
 * next to Hope, with the current time of day beside it.
 * ========================================================================== */

function injectActionBar(app, element) {
    const row = element.querySelector(".character-header-sheet .character-row");
    if (!row || row.querySelector(".drpg-actions-section")) return;

    const actor = app.document;
    const left = actionsLeft(actor);
    const max = actionsMax(actor);
    const { wounded } = actionBudget(actor);

    const section = document.createElement("div");
    section.className = "drpg-actions-section";

    /* ---- action pips ---- */
    const actions = document.createElement("div");
    actions.className = "drpg-actions";

    const label = document.createElement("h4");
    label.textContent = game.i18n.localize("DRPG.Actions.label");
    if (wounded) {
        label.classList.add("drpg-wounded");
        label.dataset.tooltip = game.i18n.localize("DRPG.Actions.woundedTooltip");
    }
    actions.append(label);

    // Always draw the full base budget. A wounded character keeps both circles,
    // but the one they have lost shows as a locked red slot — clearer than
    // silently rendering "1 / 1", which reads like an action already spent.
    const budget = Math.max(max, 1);
    for (let i = 1; i <= Math.max(STARTING.actions, budget); i++) {
        const locked = i > budget;
        const filled = !locked && i <= left;

        const pip = document.createElement("span");
        pip.className = `drpg-action-pip${filled ? " filled" : ""}${locked ? " locked" : ""}`;
        pip.dataset.value = String(i);
        pip.innerHTML = `<i class="fa-${filled ? "solid" : "regular"} fa-circle" inert></i>`;

        if (locked) {
            pip.dataset.tooltip = game.i18n.localize("DRPG.Actions.lockedTooltip");
        } else if (game.user.isGM) {
            // GM only: players spend actions by taking actions, not by clicking.
            pip.classList.add("gm-editable");
            pip.dataset.tooltip = game.i18n.format("DRPG.Actions.pipTooltip", { n: i });
            pip.addEventListener("click", () => setActions(actor, i === left ? i - 1 : i));
        } else {
            pip.dataset.tooltip = game.i18n.format("DRPG.Actions.pipReadOnly", { left, max: budget });
        }
        actions.append(pip);
    }

    /* ---- free move ---- */
    const move = document.createElement("span");
    const freeMove = hasFreeMove(actor);
    move.className = `drpg-free-move${freeMove ? " available" : " spent"}`;
    move.dataset.tooltip = game.i18n.localize(
        freeMove ? "DRPG.Actions.freeMoveAvailable" : "DRPG.Actions.freeMoveSpent"
    );
    move.innerHTML = `<i class="fa-solid fa-shoe-prints" inert></i>`;
    actions.append(move);

    section.append(actions);

    /* ---- a Call waiting on the next roll ---- */
    //
    // Until now the only place an armed Call was visible was inside the roll
    // window. That is too late twice over: a player who has banked a Free
    // Critical forgets it is there, and a player a Monokuma has just saddled
    // with Obstacle has no idea until the dice are already in front of them.
    const pending = actor.getFlag(MODULE_ID, FLAGS.pendingCall);
    if (pending?.grants) {
        const badge = document.createElement("div");
        badge.className = `drpg-pending-call drpg-pending-${pending.kind === "despair" ? "despair" : "hope"}`;
        badge.dataset.tooltip = game.i18n.format("DRPG.Calls.pendingTooltip", {
            what: game.i18n.localize(`DRPG.Calls.grants.${pending.grants}`)
        });
        badge.innerHTML = `<i class="fa-solid ${pending.kind === "despair" ? "fa-skull" : "fa-hand-sparkles"}" inert></i>
                           <span>${foundry.utils.escapeHTML(
                               game.i18n.localize(`DRPG.Calls.grants.${pending.grants}`)
                           )}</span>`;
        section.append(badge);
    }

    // Sit right after Hope, before the domains/downtime buttons.
    const hope = row.querySelector(".resource-section");
    if (hope) hope.after(section);
    else row.prepend(section);
}

/* ==========================================================================
 * ADVANCEMENT BUTTON
 * --------------------------------------------------------------------------
 * The Daggerheart level pill is hidden, so advancement needs its own way in.
 * A button on the sheet beats a macro the GM has to install by hand.
 * ========================================================================== */

function injectAdvanceButton(app, element) {
    if (!game.user.isGM) return;

    const nameRow = element.querySelector(".character-header-sheet .name-row");
    if (!nameRow || nameRow.querySelector("[data-drpg-advance]")) return;

    const button = document.createElement("button");
    button.type = "button";
    button.className = "drpg-advance-button";
    button.dataset.drpgAdvance = "";
    button.dataset.tooltip = game.i18n.localize("DRPG.Advance.buttonTooltip");
    button.setAttribute("aria-label", game.i18n.localize("DRPG.Advance.buttonTooltip"));
    button.innerHTML = `<i class="fa-solid fa-angles-up" inert></i>`;

    button.addEventListener("click", async () => {
        const { openAdvancementFor } = await import("./level-up.mjs");
        await openAdvancementFor(app.document);
    });

    nameRow.append(button);
}

/* ==========================================================================
 * GIVE / TAKE ITEMS
 * --------------------------------------------------------------------------
 * Right where the GM is already looking when they decide somebody should have
 * something — or should stop having it.
 * ========================================================================== */

function injectItemButton(app, element) {
    if (!game.user.isGM) return;
    if (isMonokuma(app.document)) return;

    const nameRow = element.querySelector(".character-header-sheet .name-row");
    if (!nameRow || nameRow.querySelector("[data-drpg-items]")) return;

    const button = document.createElement("button");
    button.type = "button";
    button.className = "drpg-advance-button drpg-items-button";
    button.dataset.drpgItems = "";
    button.dataset.tooltip = game.i18n.localize("DRPG.Items.buttonTooltip");
    button.setAttribute("aria-label", game.i18n.localize("DRPG.Items.buttonTooltip"));
    button.innerHTML = `<i class="fa-solid fa-box-open" inert></i>`;

    button.addEventListener("click", async () => {
        const { openItemManager } = await import("./gm-items.mjs");
        await openItemManager(app.document);
    });

    nameRow.append(button);
}

/* ==========================================================================
 * ULTIMATE
 * ========================================================================== */

function injectUltimate(app, element) {
    const details = element.querySelector(".character-header-sheet .character-details");
    if (!details) return;

    const actor = app.document;
    const ultimate = actor.getFlag(MODULE_ID, FLAGS.ultimate) ?? "";
    const editable = app.isEditable;

    details.classList.add("drpg-ultimate");
    details.replaceChildren(buildUltimateRow(ultimate, editable));

    if (!editable) return;

    const field = details.querySelector("[data-drpg-ultimate]");
    if (!field) return;

    // Commit on blur, and let Enter mean "done" rather than "new line".
    field.addEventListener("blur", () => commitUltimate(actor, field));
    field.addEventListener("keydown", event => {
        if (event.key === "Enter") {
            event.preventDefault();
            field.blur();
        } else if (event.key === "Escape") {
            event.preventDefault();
            field.textContent = actor.getFlag(MODULE_ID, FLAGS.ultimate) ?? "";
            field.blur();
        }
    });
}

function buildUltimateRow(ultimate, editable) {
    const row = document.createElement("div");
    row.className = "drpg-ultimate-row";

    const label = document.createElement("span");
    label.className = "drpg-ultimate-label";
    label.textContent = game.i18n.localize("DRPG.Sheet.ultimateLabel");
    row.append(label);

    const value = document.createElement("span");
    value.className = "drpg-ultimate-value";
    // textContent, never innerHTML — this string is player-supplied.
    value.textContent = ultimate;
    value.dataset.drpgUltimate = "";
    value.dataset.placeholder = game.i18n.localize("DRPG.Sheet.ultimatePlaceholder");

    if (editable) {
        value.contentEditable = "plaintext-only";
        value.spellcheck = false;
        value.setAttribute("role", "textbox");
        value.setAttribute("aria-label", game.i18n.localize("DRPG.Sheet.ultimateLabel"));
    }

    row.append(value);
    return row;
}

async function commitUltimate(actor, field) {
    const next = field.textContent.trim();
    const current = actor.getFlag(MODULE_ID, FLAGS.ultimate) ?? "";
    if (next === current) return;

    try {
        await actor.setFlag(MODULE_ID, FLAGS.ultimate, next);
        debug(`Ultimate for ${actor.name} set to "${next}".`);
    } catch (err) {
        error("Could not save the Ultimate", err);
        field.textContent = current;
    }
}

/* ==========================================================================
 * SIDEBAR
 * --------------------------------------------------------------------------
 * "Equipment" becomes "Equipped" — in this game the word equipment means the
 * whole inventory, and the sidebar block only lists what is in hand. Loadout is
 * removed outright: it holds domain cards, which do not exist here.
 * ========================================================================== */

function tidySidebar(element) {
    const sidebar = element.querySelector(".character-sidebar-sheet");
    if (!sidebar) return;

    // Structural selectors first — the template's own `.equipment-section` and
    // `.loadout-section` wrappers, not the English caption text they happen to
    // render today. Matching by text meant a language pack translating
    // "Equipment"/"Loadout" would silently stop this from finding either block;
    // the system has only ever shipped English, so that never surfaced, but it
    // was one `lang/*.json` away from failing quietly. The text match is kept
    // as a fallback for a template that renders without those wrapper classes.
    const equipment = sidebar.querySelector(".equipment-section h3")
        ?? findHeadingByText(sidebar, "equipment");
    if (equipment && !equipment.dataset.drpgRenamed) {
        equipment.textContent = game.i18n.localize("DRPG.Sheet.equipped");
        equipment.dataset.drpgRenamed = "1";
    }

    const loadoutHeading = sidebar.querySelector(".loadout-section h3") ?? findHeadingByText(sidebar, "loadout");
    const loadoutBlock = loadoutHeading?.closest(".loadout-section, section, fieldset") ?? loadoutHeading?.parentElement;
    loadoutBlock?.classList.add("drpg-hidden-block");
}

/** Fallback when the structural class cannot be found: match the caption text. */
function findHeadingByText(root, text) {
    for (const heading of root.querySelectorAll("h3, .title h3, .title")) {
        if (heading.textContent.trim().toLowerCase() === text) return heading;
    }
    return null;
}

/**
 * Biography: the guide asks for three sentences of backstory. Pronouns, Age,
 * Faith and Connections belong to a different game.
 *
 * Structural first: pronouns/age/faith are `system.biography.characteristics.*`
 * fields and connections is `system.biography.connections`, so every one of
 * them can be found by its `name` attribute regardless of what language the
 * caption next to it is rendered in. That match climbs to `.input` — the actual
 * wrapper the characteristics fields sit in — rather than the `fieldset`/
 * `.form-group` this used to look for and never found there, which is exactly
 * how "hiding the input alone left the word floating on its own" happened: the
 * caption's wrapper was never being hidden at all, only whatever `.closest()`
 * happened to land on.
 *
 * The caption-text match stays as a fallback for a template that renders these
 * fields under different names.
 */
const BIOGRAPHY_CUTS = ["pronouns", "age", "faith", "connections"];
const BIOGRAPHY_ANCESTORS = "fieldset, .form-group, .biography-field, .input, label";

function tidyBiography(element) {
    const tab = element.querySelector('section[data-application-part="biography"]');
    if (!tab) return;

    // Every characteristics field, plus connections, found by name.
    for (const field of tab.querySelectorAll('[name*="characteristics"], [name*="connections"]')) {
        (field.closest(BIOGRAPHY_ANCESTORS) ?? field).classList.add("drpg-hidden-block");
    }

    // Fallback: anything whose own text is one of the unwanted captions, for a
    // template shape the name-based pass above did not anticipate.
    for (const node of tab.querySelectorAll("h1, h2, h3, h4, label, legend, span, div")) {
        const text = node.textContent?.trim().toLowerCase().replace(/[:*]/g, "");
        if (!text || text.length > 12) continue;
        if (!BIOGRAPHY_CUTS.includes(text)) continue;

        // Take the labelled block, not just the caption.
        const block = node.closest(BIOGRAPHY_ANCESTORS) ?? node;
        block.classList.add("drpg-hidden-block");
        // The input usually sits next to the caption rather than inside it.
        const sibling = block.nextElementSibling;
        if (sibling && sibling.querySelector?.("input, select, textarea, [contenteditable]")) {
            sibling.classList.add("drpg-hidden-block");
        }
    }
}

/* ==========================================================================
 * INVENTORY GROUPS
 * --------------------------------------------------------------------------
 * The guide's inventory is three capped categories, not one flat list. Items
 * carry their category as a flag, so they are sorted into labelled groups with
 * the carry limit shown — a player should be able to see "Weapons 1/1" without
 * counting.
 * ========================================================================== */

const INVENTORY_GROUPS = [
    { key: "usable", labelKey: "DRPG.Sheet.groupUsables" },
    { key: "crimeTool", labelKey: "DRPG.Sheet.groupWeapons" },
    { key: "cleaningTool", labelKey: "DRPG.Sheet.groupCleaners" },
    { key: "truthBullet", labelKey: "DRPG.Sheet.groupTruthBullets" }
];

function groupInventory(app, element) {
    const tab = element.querySelector('section[data-application-part="inventory"]');
    if (!tab) return;

    tab.querySelector(".drpg-inventory-groups")?.remove();

    const actor = app.document;
    const box = document.createElement("div");
    box.className = "drpg-inventory-groups";

    for (const group of INVENTORY_GROUPS) {
        const cat = ITEM_CATEGORIES[group.key];
        // Carried only. What is in the stash gets its own section below, or the
        // counts would say "Crime Tools 3 / 1" for somebody obeying the rules.
        const items = actor.items.filter(i =>
            i.getFlag(MODULE_ID, "category") === group.key && !isStashed(i));
        const limit = cat?.limit;

        const section = document.createElement("div");
        section.className = "drpg-inventory-group";
        section.dataset.category = group.key;

        const head = document.createElement("h4");
        head.innerHTML = `<span>${game.i18n.localize(group.labelKey)}</span>
                          <span class="drpg-group-count${limit && items.length >= limit ? " full" : ""}">${
                              items.length}${limit ? ` / ${limit}` : ""}</span>`;
        section.append(head);

        const list = document.createElement("ul");
        list.className = "drpg-inventory-list";

        if (!items.length) {
            const empty = document.createElement("li");
            empty.className = "drpg-inventory-empty";
            empty.textContent = game.i18n.localize("DRPG.Sheet.groupEmpty");
            list.append(empty);
        } else {
            for (const item of items) {
                const li = document.createElement("li");
                li.dataset.itemUuid = item.uuid;

                if (isTruthBullet(item)) {
                    buildBulletRow(li, item, app);
                } else {
                    const tier = item.getFlag(MODULE_ID, "tier");
                    const ready = isEquipped(item);
                    if (ready) li.classList.add("drpg-item-equipped");
                    li.innerHTML = `<img src="${item.img}" alt="" />
                                    <span class="drpg-item-name">${foundry.utils.escapeHTML(item.name)}</span>
                                    ${ready ? `<span class="drpg-item-ready" data-tooltip="${
                                        foundry.utils.escapeHTML(game.i18n.localize("DRPG.Items.readyTooltip"))
                                    }"><i class="fa-solid fa-hand-fist" inert></i></span>` : ""}
                                    ${tier !== undefined && tier !== null
                                        ? `<span class="drpg-item-tier">T${tier}</span>` : ""}`;
                    addUseButton(li, item, app);
                    addEquipButton(li, item, app);
                    addHandoverButton(li, item, app, { copying: false });
                    if (vaultRoomFor(actor)) addStashButton(li, item, app, { stowing: true });
                }

                // The row's buttons live inside the row, and the row itself opens
                // the item sheet — so each button has to be able to say "not me".
                li.addEventListener("click", event => {
                    if (event.target.closest("[data-drpg-row-action]")) return;
                    item.sheet?.render(true);
                });
                list.append(li);
            }
        }

        section.append(list);
        box.append(section);
    }

    buildStashSection(box, actor, app);
    buildOpenStashSection(box, actor, app);
    tab.prepend(box);
}

/**
 * "There is somebody else's stash in this room, and it is not hidden."
 *
 * Only drawn when all of that is true, so it is not a permanent control — it
 * appears because of where the character is standing, which is the point. A
 * concealed stash does not show up here at all: finding one of those is what
 * the Search action's own stash branch is for.
 */
function buildOpenStashSection(box, actor, app) {
    if (!app.isEditable || isMonokuma(actor)) return;
    if (isDeceased(actor) && !isMonocub(actor)) return;

    const here = openStashHere(actor);
    if (!here?.items.length) return;

    const section = document.createElement("div");
    section.className = "drpg-inventory-group drpg-open-stash-group";
    section.dataset.category = "openStash";

    const head = document.createElement("h4");
    head.innerHTML = `<span>${game.i18n.format("DRPG.Vault.openStashSection", {
        who: foundry.utils.escapeHTML(here.owner.name),
        room: foundry.utils.escapeHTML(here.room)
    })}</span><span class="drpg-group-count">${here.items.length}</span>`;
    section.append(head);

    const note = document.createElement("p");
    note.className = "notes";
    note.textContent = game.i18n.localize("DRPG.Vault.openStashNote");
    section.append(note);

    const button = document.createElement("button");
    button.type = "button";
    button.className = "drpg-action-button drpg-rifle-button";
    button.innerHTML = `<i class="fa-solid fa-hand" inert></i>
        <span class="drpg-action-name">${game.i18n.localize("DRPG.Vault.rifle")}</span>`;
    button.addEventListener("click", async () => {
        const { rifleStashDialog } = await import("./vault.mjs");
        await rifleStashDialog(actor);
        app.render(false);
    });
    section.append(button);

    box.append(section);
}

/**
 * "Stash — <room>", under the carried groups.
 *
 * Only drawn when this character actually has a bedroom assigned. Uncapped, so
 * there is no count to show — what matters is which room it is in, because that
 * is where they have to be standing to reach it.
 */
function buildStashSection(box, actor, app) {
    const room = vaultRoomFor(actor);
    if (!room) return;

    const items = vaultContents(actor);

    const section = document.createElement("div");
    section.className = "drpg-inventory-group drpg-stash-group";
    section.dataset.category = "vault";

    const head = document.createElement("h4");
    head.innerHTML = `<span>${game.i18n.format("DRPG.Vault.section", {
        room: foundry.utils.escapeHTML(room)
    })}</span><span class="drpg-group-count">${items.length}</span>`;
    section.append(head);

    const list = document.createElement("ul");
    list.className = "drpg-inventory-list";

    if (!items.length) {
        const empty = document.createElement("li");
        empty.className = "drpg-inventory-empty";
        empty.textContent = game.i18n.localize("DRPG.Sheet.groupEmpty");
        list.append(empty);
    } else {
        for (const item of items) {
            const li = document.createElement("li");
            li.dataset.itemUuid = item.uuid;
            const tier = item.getFlag(MODULE_ID, "tier");
            li.innerHTML = `<img src="${item.img}" alt="" />
                            <span class="drpg-item-name">${foundry.utils.escapeHTML(item.name)}</span>
                            ${tier !== undefined && tier !== null
                                ? `<span class="drpg-item-tier">T${tier}</span>` : ""}`;
            addStashButton(li, item, app, { stowing: false });
            li.addEventListener("click", event => {
                if (event.target.closest("[data-drpg-row-action]")) return;
                item.sheet?.render(true);
            });
            list.append(li);
        }
    }

    section.append(list);
    box.append(section);
}

/**
 * Drink it, eat it, apply it.
 *
 * Only on Usable Items, and only for somebody who can act — a corpse's first
 * aid kit is not a first aid kit. Free: the guide charges actions for finding
 * and making things, not for opening what you already carry.
 */
function addUseButton(li, item, app) {
    if (!app.isEditable || isMonokuma(app.document)) return;
    if (!isUsable(item)) return;
    if (isDeceased(app.document) && !isMonocub(app.document)) return;

    const tip = game.i18n.localize("DRPG.Items.useTooltip");

    const button = document.createElement("button");
    button.type = "button";
    button.className = "drpg-row-button drpg-row-use";
    button.dataset.drpgRowAction = "use";
    button.dataset.tooltip = tip;
    button.setAttribute("aria-label", tip);
    button.innerHTML = `<i class="fa-solid fa-flask" inert></i>`;

    button.addEventListener("click", async () => {
        const { useItem } = await import("./use-items.mjs");
        await useItem(app.document, item);
        app.render(false);
    });

    li.append(button);
}

/**
 * Hold this one ready.
 *
 * The incident engine asks "which weapon" and, without this, could only answer
 * "the highest tier you happen to own" — which is wrong the moment a killer is
 * carrying a Tier 3 axe they mean to frame somebody with and a Tier 1 pipe they
 * mean to swing.
 */
function addEquipButton(li, item, app) {
    if (!app.isEditable || isMonokuma(app.document)) return;
    if (!isEquippable(item)) return;

    const ready = isEquipped(item);
    const tip = game.i18n.localize(ready ? "DRPG.Items.unequipTooltip" : "DRPG.Items.equipTooltip");

    const button = document.createElement("button");
    button.type = "button";
    button.className = `drpg-row-button drpg-row-equip${ready ? " active" : ""}`;
    button.dataset.drpgRowAction = "equip";
    button.dataset.tooltip = tip;
    button.setAttribute("aria-label", tip);
    button.innerHTML = `<i class="fa-${ready ? "solid" : "regular"} fa-hand-fist" inert></i>`;

    button.addEventListener("click", async () => {
        const { toggleEquipped } = await import("./use-items.mjs");
        await toggleEquipped(app.document, item);
        app.render(false);
    });

    li.append(button);
}

/**
 * Put away, or take back out. Free, and only from the room itself — the check
 * that matters lives in vault.mjs, this just offers the button.
 */
function addStashButton(li, item, app, { stowing }) {
    if (!app.isEditable || isMonokuma(app.document)) return;

    const tip = game.i18n.localize(stowing ? "DRPG.Vault.stowTooltip" : "DRPG.Vault.takeTooltip");

    const button = document.createElement("button");
    button.type = "button";
    button.className = "drpg-row-button drpg-row-stash";
    button.dataset.drpgRowAction = "stash";
    button.dataset.tooltip = tip;
    button.setAttribute("aria-label", tip);
    button.innerHTML = `<i class="fa-solid fa-${stowing ? "box-archive" : "hand-back-fist"}" inert></i>`;

    button.addEventListener("click", async () => {
        const { stow, retrieve } = await import("./vault.mjs");
        if (stowing) await stow(app.document, item);
        else await retrieve(app.document, item);
        app.render(false);
    });

    li.append(button);
}

/**
 * One Truth Bullet, as a row.
 *
 * A bullet has no tier — the old `T2` pill was a visibility index the previous
 * macro smuggled through the tier field. What matters instead is what the player
 * currently believes it is, how hard the original was to spot (the number Analyze
 * will be rolled against), and which chapter it belongs to.
 *
 * The GM reading the same sheet gets one extra badge: the truth. It is drawn
 * from `truthBulletData`, which returns it only to a GM — a player's client
 * never had it to begin with.
 */
function buildBulletRow(li, item, app) {
    const data = truthBulletData(item);
    if (!data) return;

    li.classList.add("drpg-truth-bullet");
    li.dataset.bulletType = data.shownType;

    const badge = (text, cls, tooltip = "") =>
        `<span class="drpg-tb-badge ${cls}"${
            tooltip ? ` data-tooltip="${foundry.utils.escapeHTML(tooltip)}"` : ""
        }>${foundry.utils.escapeHTML(text)}</span>`;

    const badges = [
        badge(data.shownLabel, `type ${data.shownType}`, data.shownHint),
        badge(data.visibilityLabel, "visibility",
            game.i18n.localize("DRPG.TruthBullet.visibilityTooltip"))
    ];

    if (data.chapter !== null) {
        badges.push(badge(game.i18n.format("DRPG.TruthBullet.chapterShort", { n: data.chapter }),
            "chapter"));
    }
    if (data.faint) {
        badges.push(badge(game.i18n.localize("DRPG.TruthBullet.faint"), "faint",
            game.i18n.localize("DRPG.TruthBullet.faintTooltip")));
    }
    // A burned attempt is worth showing rather than silently removing the
    // button: "I already tried this one" is information the player needs when
    // deciding what to spend the next action on.
    if (data.lockedChapter !== null && data.lockedChapter === data.chapterNow) {
        badges.push(badge(game.i18n.localize("DRPG.TruthBullet.locked"), "locked",
            game.i18n.localize("DRPG.TruthBullet.lockedTooltip")));
    }
    // GM only, and only worth showing while it still differs from what the
    // player sees — once a bullet is identified the two badges say the same thing.
    if (game.user.isGM && data.realType && data.realType !== data.shownType) {
        badges.push(badge(game.i18n.format("DRPG.TruthBullet.really", { type: data.realLabel }),
            "real", data.gmNote || game.i18n.localize("DRPG.TruthBullet.reallyTooltip")));
    }

    li.innerHTML = `<img src="${item.img}" alt="" />
                    <span class="drpg-item-name">${foundry.utils.escapeHTML(item.name)}</span>
                    <span class="drpg-tb-badges">${badges.join("")}</span>`;

    if (!app.isEditable || isMonokuma(app.document)) return;

    // Evidence is worth passing on whatever state it is in — an unidentified
    // copy is exactly what you hand to somebody whose analysis has not been
    // burned yet. So this button is offered regardless of the lock.
    addHandoverButton(li, item, app, { copying: true });
    addPresentButton(li, item, app);

    // Nothing to analyse once the type is confirmed — a Key or Autopsy bullet
    // arrives identified, an analysed one is resolved, and one this character
    // already failed on this chapter is closed to them until the next.
    if (!isAnalysable(item, data.chapterNow)) return;

    const button = document.createElement("button");
    button.type = "button";
    button.className = "drpg-row-button drpg-tb-analyze";
    button.dataset.drpgRowAction = "analyze";
    button.dataset.tooltip = game.i18n.localize("DRPG.TruthBullet.analyzeTooltip");
    button.setAttribute("aria-label", game.i18n.localize("DRPG.TruthBullet.analyzeTooltip"));
    button.innerHTML = `<i class="fa-solid fa-brain" inert></i>`;

    button.addEventListener("click", async () => {
        const { performAction } = await import("./action-rolls.mjs");
        await performAction(app.document, "analyze", { bulletId: item.id });
    });

    li.append(button);
}

/**
 * "Put this in front of everyone."
 *
 * Only during a Class Trial. It reaches the whole table at once, and outside
 * the trial the cast is spread across rooms that are meant to stay separate —
 * the same-room Share button covers those phases instead.
 */
function addPresentButton(li, item, app) {
    if (!inClassTrial()) return;

    const tip = game.i18n.localize("DRPG.Trial.presentTooltip");

    const button = document.createElement("button");
    button.type = "button";
    button.className = "drpg-row-button drpg-row-present";
    button.dataset.drpgRowAction = "present";
    button.dataset.tooltip = tip;
    button.setAttribute("aria-label", tip);
    button.innerHTML = `<i class="fa-solid fa-gavel" inert></i>`;

    button.addEventListener("click", async () => {
        const { presentDialog } = await import("./trial.mjs");
        await presentDialog(app.document, item);
    });

    li.append(button);
}

/**
 * "Hand this to somebody standing here."
 *
 * One button, two meanings, and the tooltip says which: a Truth Bullet is
 * copied and an item changes hands.
 *
 * Shown to the GM as well. They have Give / take items, which is the stronger
 * tool, but this one obeys the fiction's rules — same room, carry limits — and
 * a GM running a character or testing the table needs the same door the players
 * use, not a different one.
 */
function addHandoverButton(li, item, app, { copying }) {
    if (!app.isEditable || isMonokuma(app.document)) return;

    const tip = game.i18n.localize(copying ? "DRPG.Handover.shareTooltip" : "DRPG.Handover.giveTooltip");

    const button = document.createElement("button");
    button.type = "button";
    button.className = "drpg-row-button drpg-row-handover";
    button.dataset.drpgRowAction = "handover";
    button.dataset.tooltip = tip;
    button.setAttribute("aria-label", tip);
    button.innerHTML = `<i class="fa-solid fa-${copying ? "share-nodes" : "hand-holding"}" inert></i>`;

    button.addEventListener("click", async () => {
        const { shareBulletDialog, giveItemDialog } = await import("./handover.mjs");
        if (copying) await shareBulletDialog(app.document, item);
        else await giveItemDialog(app.document, item);
    });

    li.append(button);
}

/* ==========================================================================
 * ACTION PANEL
 * --------------------------------------------------------------------------
 * The guide's actions, as buttons at the top of the Features tab. Clicking one
 * rolls the right trait, resolves the threshold and reports back privately —
 * no GM required for the repeatable ones.
 * ========================================================================== */

function injectActionPanel(app, element) {
    if (!app.isEditable) return;

    // Must be the CONTENT section, never the navigation link.
    //
    // `[data-tab="features"]` also matches the <a> in the tab bar, which comes
    // first in the DOM — so a looser selector put the whole panel inside a
    // navigation link. That made it collapse to the link's width and, worse,
    // silently swallowed every click: ApplicationV2 treats clicks inside
    // `[data-tab]` as "switch to this tab" and never reached our handler.
    const tab = element.querySelector('section[data-application-part="features"]')
        ?? element.querySelector('section.tab[data-tab="features"]')
        ?? element.querySelector('.tab[data-tab="features"]');
    if (!tab || tab.matches("a, nav, .sheet-tabs")) return;

    // Panels are rebuilt every render so costs and affordability stay current.
    tab.querySelectorAll(".drpg-action-panel, .drpg-calls-panel").forEach(p => p.remove());

    const actor = app.document;
    const monokuma = isMonokuma(actor);

    // A Monokuma has no action economy at all. Their sheet is Despair Calls.
    if (monokuma) {
        injectCallsPanel(tab, actor, true);
        attachActionDelegate(app, element);
        return;
    }

    // A Monocub keeps the normal action budget but only two things to spend it
    // on. Its own panel entirely, not a filtered version of the student grid —
    // Meddle targets another actor and has no place in the generic delegate.
    if (isMonocub(actor)) {
        injectMonocubPanel(tab, actor);
        attachActionDelegate(app, element);
        return;
    }

    // Dead, and not promoted to a Monocub. Both branches above are about what
    // somebody IS; this one is about somebody who has stopped.
    //
    // Nothing used to catch this case, so a student who had been executed or
    // murdered kept the whole living grid — Search, Rest, Work on Project, even
    // Direct Murder — plus their Hope Calls, and `resetActionsFor` refilled the
    // budget every time of day because it only ever skipped Monokumas. Becoming
    // a Monocub is a separate GM step that may come a whole trial later, or
    // never, and that gap is exactly where a corpse could keep taking turns.
    if (isDeceased(actor)) {
        const note = document.createElement("div");
        note.className = "drpg-action-panel drpg-dead-panel";
        const heading = document.createElement("h3");
        heading.className = "drpg-keep";
        heading.textContent = game.i18n.localize("DRPG.Chapter.deadPanelTitle");
        const body = document.createElement("p");
        body.className = "notes";
        body.textContent = game.i18n.localize("DRPG.Chapter.deadPanelNote");
        note.append(heading, body);
        tab.prepend(note);
        return;
    }

    const panel = document.createElement("div");
    panel.className = "drpg-action-panel";

    const title = document.createElement("h3");
    // `drpg-keep` exempts it from the rule that hides Daggerheart's own section
    // headings from players — see styles/danganronpa.css.
    title.className = "drpg-keep";
    title.textContent = game.i18n.localize("DRPG.Action.panelTitle");
    panel.append(title);

    const grid = document.createElement("div");
    grid.className = "drpg-action-grid";

    for (const [key, def] of Object.entries(ACTIONS)) {
        if (def.kind !== "universal") continue;
        grid.append(actionButton(actor, key, def));
    }

    // Dynamic actions are the guide's catch-all: describe it, the GM sets a
    // threshold, and the reward scale is deliberately gentler.
    grid.append(actionButton(actor, "dynamic", {
        label: game.i18n.localize("DRPG.Action.dynamicLabel"),
        hint: game.i18n.localize("DRPG.Action.dynamicHint"),
        icon: "fa-wand-magic-sparkles",
        cost: 1
    }));

    panel.append(grid);
    tab.prepend(panel);

    // An incident replaces the ordinary economy for the two people in it, so
    // their crisis actions sit ABOVE the normal grid while one is running.
    injectCrisisPanel(tab, actor);

    // Hope Calls sit underneath the actions, in the colour of the Hope die.
    injectCallsPanel(tab, actor, false);
    attachActionDelegate(app, element);
}

/**
 * Move and Meddle. Move reuses the normal action button and the generic
 * delegate — its click just shows the same briefing every player gets, since
 * the guide's Move is applied when a token crosses a room, not when a button
 * is pressed. Meddle is bespoke: it needs a target and a Help/Hinder choice
 * before there is anything to roll.
 */
function injectMonocubPanel(tab, actor) {
    const panel = document.createElement("div");
    panel.className = "drpg-action-panel drpg-monocub-panel";

    const title = document.createElement("h3");
    title.className = "drpg-keep";
    title.textContent = game.i18n.localize("DRPG.Monocub.panelTitle");
    panel.append(title);

    // No Hope read-out here. The Hope pips are already on the sheet header,
    // right next to this panel, and the Meddle tile's own price line says what
    // it costs — a third copy of the same number, plus a sentence about who is
    // allowed to top it up, was telling the player something they can see and
    // something they cannot act on.

    const grid = document.createElement("div");
    grid.className = "drpg-action-grid";
    grid.append(actionButton(actor, "move", ACTIONS.move));
    grid.append(meddleButton(actor));
    panel.append(grid);

    if (isSilenced(actor)) {
        const note = document.createElement("p");
        note.className = "notes drpg-monocub-silenced";
        note.textContent = game.i18n.localize("DRPG.Monocub.silencedNoteShort");
        panel.append(note);
    }

    tab.prepend(panel);
}

function meddleButton(actor) {
    const def = MONOCUB.meddle;
    const held = hopeHeld(actor);
    const affordable = actionsLeft(actor) >= def.cost && held >= def.hopeCost;

    const button = document.createElement("button");
    button.type = "button";
    button.className = `drpg-action-button${affordable ? "" : " unaffordable"}`;
    button.dataset.tooltip = `${game.i18n.format("DRPG.Monocub.meddleCost", {
        actions: def.cost, hope: def.hopeCost
    })}${affordable ? "" : `<br><em>${game.i18n.localize("DRPG.Monocub.cannotMeddle")}</em>`}`;
    button.innerHTML = `
        <i class="fa-solid ${def.icon} drpg-action-icon" inert></i>
        <span class="drpg-action-name">${foundry.utils.escapeHTML(def.label)}</span>
        <span class="drpg-action-cost">${def.cost} · ${def.hopeCost}◆</span>`;

    button.addEventListener("click", async () => {
        const { meddleDialog } = await import("./monocub.mjs");
        await meddleDialog(actor);
    });

    return button;
}

/**
 * The crisis actions, while an incident is running.
 *
 * Only for the two people in it (and anyone who walked in), and only their own
 * side's actions. Whose turn it is decides whether the buttons do anything —
 * they stay visible either way, because "it is not your turn" is information
 * the other player needs as much as the buttons themselves.
 */
function injectCrisisPanel(tab, actor) {
    const options = availableCrisisActions(actor);
    if (!options.length) return;

    const yours = isTheirTurn(actor);

    const panel = document.createElement("div");
    panel.className = `drpg-action-panel drpg-crisis-panel${yours ? " active" : ""}`;

    const title = document.createElement("h3");
    title.className = "drpg-keep";
    title.textContent = game.i18n.localize(
        yours ? "DRPG.Murder.yourTurn" : "DRPG.Murder.theirTurn");
    panel.append(title);

    const grid = document.createElement("div");
    grid.className = "drpg-action-grid";

    for (const { key, def, hindered, blocked, locked, spent, lockedBy } of options) {
        const button = document.createElement("button");
        button.type = "button";
        button.className = `drpg-action-button${blocked ? " drpg-locked" : ""}${
            hindered ? " drpg-hindered" : ""}`;
        button.disabled = !yours || blocked;
        // Say WHICH kind of shut this is. "Blocked" covers three different
        // situations now — a Pin, a gate Self-defence has not opened yet, and
        // an attempt already spent — and a player staring at a grey button
        // needs to know which of the three they are looking at.
        button.dataset.tooltip = locked
            ? game.i18n.format("DRPG.Murder.actionLocked", { name: lockedBy ?? "?" })
            : spent
                ? game.i18n.localize("DRPG.Murder.actionSpent")
                : blocked
                    ? game.i18n.localize("DRPG.Murder.actionBlocked")
                    : hindered
                        ? game.i18n.localize("DRPG.Murder.actionHindered")
                        : def.hint ?? def.label;
        button.innerHTML = `<i class="fa-solid ${def.icon ?? "fa-burst"}" inert></i>
                            <span>${foundry.utils.escapeHTML(def.label)}</span>`;

        button.addEventListener("click", async () => {
            const { takeCrisisAction } = await import("./murder.mjs");
            await takeCrisisAction(actor, key);
        });

        grid.append(button);
    }

    panel.append(grid);
    tab.prepend(panel);
}

/* ==========================================================================
 * HOPE CALLS  /  DESPAIR CALLS
 * --------------------------------------------------------------------------
 * The same grid as the actions, in the colour of the die that pays for it:
 * gold for Hope, purple for Despair. Calls you cannot afford stay visible but
 * dimmed — half the point of the menu is seeing what you are saving towards.
 * ========================================================================== */

function injectCallsPanel(tab, actor, monokuma) {
    const panel = document.createElement("div");
    panel.className = `drpg-calls-panel ${monokuma ? "drpg-despair-panel" : "drpg-hope-panel"}`;

    const held = monokuma ? monokumaPool(actor) : hopeHeld(actor);
    const max = monokuma ? STARTING.despairMax : hopeMax(actor);

    const title = document.createElement("h3");
    title.className = "drpg-keep";
    title.innerHTML = `<span>${game.i18n.localize(
        monokuma ? "DRPG.Calls.despairTitle" : "DRPG.Calls.hopeTitle"
    )}</span><span class="drpg-calls-pool">${held} / ${max}</span>`;
    panel.append(title);

    const grid = document.createElement("div");
    grid.className = "drpg-action-grid";

    // A Call is not a room crossing either — see spendHopeCall/spendDespairCallFor
    // in calls.mjs, which refuse it outright while the Eclipse is running.
    const locked = isEclipse();

    const calls = monokuma ? despairCallsFor(held) : affordableHopeCalls(actor);
    for (const call of calls) grid.append(callButton(call, monokuma, locked));

    panel.append(grid);
    tab.append(panel);
}

/**
 * A Call tile, built to exactly the same template as an action tile: icon on
 * top, name, price underneath. Only the colour and the icon differ, so a player
 * reads the whole sheet the same way rather than learning two layouts.
 */
function callButton(call, monokuma, locked = false) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = `drpg-action-button drpg-call-button${(call.affordable && !locked) ? "" : " unaffordable"}`;
    button.dataset.drpgCall = call.key;
    button.dataset.drpgCallKind = monokuma ? "despair" : "hope";

    const costLabel = game.i18n.format(
        monokuma ? "DRPG.Calls.costsDespairShort" : "DRPG.Calls.costsHopeShort",
        { cost: call.cost }
    );
    const note = locked ? `<br><em>${game.i18n.localize("DRPG.Eclipse.actionsLocked")}</em>` : "";
    button.dataset.tooltip = `${foundry.utils.escapeHTML(call.effect)}<br><em>${costLabel}</em>${note}`;

    button.innerHTML = `
        <i class="fa-solid ${call.icon ?? "fa-circle"} drpg-action-icon" inert></i>
        <span class="drpg-action-name">${foundry.utils.escapeHTML(call.label)}</span>
        <span class="drpg-action-cost">${costLabel}</span>`;

    return button;
}

/** The Despair pool backing a Monokuma actor. */
function monokumaPool(actor) {
    try {
        const user = poolUserFor(actor);
        return user ? getDespair(user.id) : 0;
    } catch {
        return 0;
    }
}

/**
 * One delegated listener on the sheet root, instead of one per button.
 *
 * Per-button listeners were being lost: ApplicationV2 replaces the innerHTML of
 * a part when it re-renders, so any node we had attached to was discarded while
 * a visually identical one took its place. Delegation survives that, and the
 * `capture` phase means the sheet's own handlers cannot swallow the click
 * first.
 */
function attachActionDelegate(app, element) {
    if (element.dataset.drpgActionDelegate) return;
    element.dataset.drpgActionDelegate = "1";

    element.addEventListener("click", async event => {
        const button = event.target.closest?.("[data-drpg-action], [data-drpg-call]");
        if (!button || !element.contains(button)) return;

        event.preventDefault();
        event.stopPropagation();
        if (button.disabled) return;

        button.disabled = true;
        try {
            if (button.dataset.drpgCall) {
                await runCall(app.document, button.dataset.drpgCall, button.dataset.drpgCallKind);
            } else {
                const { performAction } = await import("./action-rolls.mjs");
                await performAction(app.document, button.dataset.drpgAction);
            }
        } catch (err) {
            error("Action failed", err);
            ui.notifications.error(game.i18n.localize("DRPG.Action.failed"));
        } finally {
            button.disabled = false;
        }
    }, { capture: true });
}

/** Confirm and pay for a Hope Call or a Despair Call. */
async function runCall(actor, key, kind) {
    const { HOPE_CALLS, DESPAIR_CALLS } = await import("./config.mjs");
    const { confirmCall, spendHopeCall, spendDespairCallFor, hopeHeld } = await import("./calls.mjs");

    const despair = kind === "despair";
    const call = despair ? DESPAIR_CALLS[key] : HOPE_CALLS[key];
    if (!call) return;

    const held = despair ? monokumaPool(actor) : hopeHeld(actor);
    if (held < call.cost) {
        ui.notifications.warn(game.i18n.format(
            despair ? "DRPG.Calls.costsDespair" : "DRPG.Calls.costsHope",
            { cost: call.cost, held }
        ));
        return;
    }

    // Silence closes the whole Hope menu. Checked here rather than inside
    // `spendHopeCall`, which only reached it after the target picker and the
    // confirmation — three dialogs to be told the menu was shut all along.
    if (!despair) {
        const { isSilenced } = await import("./call-effects.mjs");
        if (isSilenced(actor)) {
            ui.notifications.warn(game.i18n.localize("DRPG.Calls.silencedNotice"));
            return;
        }
    }

    // Experience buys the use of an experience. With none written on the sheet
    // there is nothing to buy, and the Call would have been paid for, armed, and
    // then met a roll window with no chips to tick.
    if (call.grants === "experience" && !Object.keys(actor.system?.experiences ?? {}).length) {
        ui.notifications.warn(game.i18n.localize("DRPG.Calls.noExperiences"));
        return;
    }

    // Point it at something first: a player, a project, a room, an item.
    const { pickTarget } = await import("./call-effects.mjs");
    const choice = await pickTarget(actor, call, despair ? "despair" : "hope");
    if (choice === null) return;

    const note = await confirmCall(call, { kind: despair ? "despair" : "hope", held, choice });
    if (note === null) return;

    if (despair) await spendDespairCallFor(actor, key, { note, choice });
    else await spendHopeCall(actor, key, { note, choice });

    actor.sheet?.render(false);
}

function actionButton(actor, key, def) {
    const button = document.createElement("button");
    button.type = "button";

    // An action the budget cannot pay for is dimmed exactly the way an
    // unaffordable Hope Call is — same class, same look. The tile stays visible
    // and still opens its briefing, because knowing what an action would do is
    // half of deciding whether to save an action for it.
    const cost = costOf(actor, key, def);
    const affordable = cost === 0 || actionsLeft(actor) >= cost;
    // The Eclipse is placement-only — see the guard in action-rolls.mjs's
    // `performAction`. Move is exempt there and stays exempt here, since it is
    // the one thing the Eclipse actually is for.
    const locked = key !== "move" && isEclipse();
    button.className = `drpg-action-button${(affordable && !locked) ? "" : " unaffordable"}`;

    // NOT `data-action`: ApplicationV2 claims that attribute for its own action
    // dispatch and swallows the click looking for a handler it does not have.
    button.dataset.drpgAction = key;

    const costLabel = costLabelFor(actor, key, def);
    const note = locked
        ? `<br><em>${game.i18n.localize("DRPG.Eclipse.actionsLocked")}</em>`
        : affordable
            ? ""
            : `<br><em>${game.i18n.format("DRPG.Action.cannotAfford", { left: actionsLeft(actor), needed: cost })}</em>`;
    button.dataset.tooltip = `${foundry.utils.escapeHTML(def.hint ?? "")}<br><em>${costLabel}</em>${note}`;

    button.innerHTML = `
        <i class="fa-solid ${def.icon ?? "fa-circle"} drpg-action-icon" inert></i>
        <span class="drpg-action-name">${foundry.utils.escapeHTML(def.label)}</span>
        <span class="drpg-action-cost">${costLabel}</span>`;

    return button;
}

/**
 * What this action would cost right now.
 *
 * During an Eclipse the action economy is suspended entirely — crossings come
 * out of the two the placement window grants, not out of actions — so Move is
 * free regardless of whether the ordinary free Move has been spent.
 */
function costOf(actor, key, def) {
    if (key !== "move") return def.cost ?? 1;
    if (isEclipse()) return 0;
    return hasFreeMove(actor) ? 0 : 1;
}

/**
 * Move shows its live state; everything else shows a flat price.
 *
 * In an Eclipse "Free" is true but useless — the number that decides whether
 * you can still get where you are going is how many of the two crossings are
 * left, and it was only visible in a whisper after each one.
 */
function costLabelFor(actor, key, def) {
    if (key === "move" && isEclipse()) {
        return game.i18n.format("DRPG.Action.costCrossings", {
            left: eclipseMovesLeft(actor),
            max: ECLIPSE_MOVES
        });
    }

    const cost = costOf(actor, key, def);
    return cost === 0
        ? game.i18n.localize("DRPG.Action.costFree")
        : game.i18n.format("DRPG.Action.costActions", { n: cost });
}

/* ==========================================================================
 * PUBLIC HELPERS
 * ========================================================================== */

/** Read a character's Ultimate. */
export function getUltimate(actor) {
    return actor?.getFlag(MODULE_ID, FLAGS.ultimate) ?? "";
}

/** Set a character's Ultimate. */
export function setUltimate(actor, value) {
    return actor?.setFlag(MODULE_ID, FLAGS.ultimate, String(value ?? "").trim());
}

/**
 * Ultimates must be unique for a season. Returns every character whose
 * Ultimate collides with another, so the GM can catch duplicates at creation.
 */
export function findDuplicateUltimates() {
    const seen = new Map();
    for (const actor of game.actors) {
        if (actor.type !== "character") continue;
        const ultimate = getUltimate(actor).trim().toLowerCase();
        if (!ultimate) continue;
        if (!seen.has(ultimate)) seen.set(ultimate, []);
        seen.get(ultimate).push(actor);
    }
    return Array.from(seen.entries())
        .filter(([, actors]) => actors.length > 1)
        .map(([ultimate, actors]) => ({ ultimate, actors }));
}
