/**
 * Danganronpa RPG — voice per region.
 * ---------------------------------------------------------------------------
 * Rooms are private conversations. Text already enforces that — see
 * visibility.mjs (you cannot see who is not in your room) and
 * private-rolls.mjs (your dice are nobody else's business) — this does the
 * same for voice: every Scene Region becomes its own LiveKit breakout room,
 * and a player's voice client follows the moment their token crosses into a
 * different one.
 *
 * Built on avclient-livekit's own Breakout Rooms feature — not a fork of it,
 * not a patch to it. Everything here goes through its public surface: the
 * world-scoped `breakoutRoomRegistry` setting and its own socket channel, the
 * same two things a GM right-clicking "Start A/V breakout" in the Players
 * list already uses. Confirmed live on Forge before this was written: an
 * assigned client actually reconnects into an arbitrarily-named LiveKit room
 * (see macros/06-voice-spike.js).
 *
 * Entirely optional. Without avclient-livekit installed and active, and
 * without the world setting turned on, every function below is a no-op —
 * nothing else in this module depends on any of it.
 *
 * A Monokuma follows the same rule as a student: wherever the token stands is
 * whose voice they hear. Which GM that is comes from the SAME map the Despair
 * panel already uses (`poolUserFor` in monokuma.mjs) — a Monokuma spends one
 * GM's Despair and speaks with that GM's voice, not two separate assignments
 * to keep in sync. A token dragged off every mapped room sends that GM back
 * to the main room, free to use the eavesdrop dialog below on whatever they
 * like without their own token dragging them back out of it.
 */

import { SETTINGS, getSetting } from "./settings.mjs";
import { roomOfActor, allRooms } from "./movement.mjs";
import { isMonokuma, poolUserFor } from "./monokuma.mjs";
import { isPrimaryGm, debug, error } from "./utils.mjs";

const AV_MODULE = "avclient-livekit";
const REGISTRY_SETTING = "breakoutRoomRegistry";

/** Coalesces a burst of token moves (a drag, several players placing at once)
 *  into a single reassignment pass rather than reconnecting mid-drag. */
const RECONCILE_DEBOUNCE_MS = 1500;

export function registerVoice() {
    Hooks.on("updateToken", (doc, changes) => {
        if (changes.x !== undefined || changes.y !== undefined) scheduleReconcile();
    });
    Hooks.on("canvasReady", () => scheduleReconcile({ immediate: true }));
    Hooks.on("drpgTimeOfDayChanged", () => scheduleReconcile({ immediate: true }));
    // An Eclipse is a placement window: everyone repositions at once. Reconciling
    // on every intermediate move would mean each client reconnecting to LiveKit
    // over and over while the table is still shuffling tokens, so this waits
    // for it to end and applies the result in a single pass.
    Hooks.on("drpgEclipseChanged", active => {
        if (!active) scheduleReconcile({ immediate: true });
    });
}

/* ==========================================================================
 * AVCLIENT-LIVEKIT — reading and writing ITS state, not ours
 * ========================================================================== */

function avclientActive() {
    return Boolean(game.modules.get(AV_MODULE)?.active);
}

function readRegistry() {
    try {
        return game.settings.get(AV_MODULE, REGISTRY_SETTING) ?? {};
    } catch {
        return {};
    }
}

/**
 * Point one user's LiveKit client at a breakout room, or clear it (pass
 * `null`) to send them back to the world's configured main room. Mirrors
 * avclient-livekit's own `setBreakoutRoom()` + socket emit exactly — this is
 * what "Start A/V breakout" in the Players list already does, aimed at
 * whichever room a Scene Region maps to instead of a random id.
 *
 * @returns {Promise<boolean>} true if anything actually changed — callers use
 *   this to avoid reassigning (and reconnecting) players who did not move.
 */
async function assignUser(userId, breakoutRoom) {
    const registry = { ...readRegistry() };
    if ((registry[userId] ?? null) === (breakoutRoom ?? null)) return false;

    registry[userId] = breakoutRoom;
    await game.settings.set(AV_MODULE, REGISTRY_SETTING, registry);
    game.socket.emit(`module.${AV_MODULE}`, {
        action: "breakout",
        userId,
        breakoutRoom
    }, { recipients: [userId] });
    return true;
}

/**
 * Point one user's voice at a room, whoever they are. The registry+socket
 * path above only works on OTHER clients — there is nobody to receive a
 * socket message aimed at yourself with any confidence, so the primary GM's
 * own assignment (when their own Monokuma is the one being reconciled) goes
 * through the direct, local path instead. See "THE GM'S OWN VOICE" below.
 *
 * @returns {Promise<boolean>} true if anything actually changed.
 */
async function assignUserToRoom(userId, breakoutRoom) {
    if (userId === game.user.id) {
        const result = await applyLocalBreakout(breakoutRoom);
        return result === "changed";
    }
    return assignUser(userId, breakoutRoom);
}

/* ==========================================================================
 * ROOM NAMES
 * ========================================================================== */

/**
 * A DRPG room name -> a stable LiveKit room name for this scene. `null` when
 * the character is not in any mapped room, which clears the assignment and
 * sends them back to the main room rather than inventing a "lobby" nobody
 * asked for.
 */
function liveKitRoomFor(sceneId, drpgRoom) {
    if (!sceneId || !drpgRoom) return null;
    return `drpg-${sceneId}-${slug(drpgRoom)}`;
}

function slug(name) {
    return String(name ?? "")
        .toLowerCase()
        .normalize("NFKD").replace(/[̀-ͯ]/g, "") // strip accents (ą, ę, ć…)
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/^-+|-+$/g, "") || "room";
}

/* ==========================================================================
 * RECONCILING
 * --------------------------------------------------------------------------
 * The primary GM's client watches every player's room and keeps LiveKit in
 * step. Has to be one client, and has to be a GM: `breakoutRoomRegistry` is a
 * world-scoped setting, which only a GM can write at all, and two GMs both
 * reassigning the same player on the same move would be a race, not a
 * feature — the same reasoning movement.mjs already applies to who pays for a
 * room crossing.
 * ========================================================================== */

let reconcileTimer = null;

/**
 * True while the primary GM has manually chosen a room from the eavesdrop
 * dialog. Suppresses auto-follow for their OWN voice only, and only while
 * their own Monokuma token is off every mapped room — dragging it INTO a room
 * always wins over a stale manual choice. Cleared by `stopEavesdropping()` and
 * by `resetAllVoice()`.
 */
let manualEavesdrop = false;

export function scheduleReconcile({ immediate = false } = {}) {
    if (reconcileTimer) {
        clearTimeout(reconcileTimer);
        reconcileTimer = null;
    }
    if (immediate) {
        reconcileNow();
        return;
    }
    reconcileTimer = setTimeout(() => {
        reconcileTimer = null;
        reconcileNow();
    }, RECONCILE_DEBOUNCE_MS);
}

async function reconcileNow() {
    try {
        if (!isPrimaryGm()) return;
        if (!getSetting(SETTINGS.voiceEnabled)) return;
        if (!avclientActive()) return;

        const { isEclipse } = await import("./eclipse.mjs");
        if (isEclipse()) return; // batched reconcile fires when it ends

        const sceneId = canvas?.scene?.id;
        if (!sceneId) return;

        let changed = 0;
        for (const actor of game.actors.filter(a => a.type === "character")) {
            const monokuma = isMonokuma(actor);
            // A student's voice follows their active owner; a Monokuma's
            // follows whichever GM its Despair pool is pointed at — the same
            // relationship, read from the same setting, not a second one.
            const user = monokuma ? poolUserFor(actor) : activeOwnerOf(actor);
            if (!user?.active) continue;

            const room = roomOfActor(actor);
            const isSelf = user.id === game.user.id;

            // Your own Monokuma, off the map, while you are manually
            // listening to a room you picked from the dialog: leave it alone.
            if (monokuma && isSelf && !room && manualEavesdrop) continue;
            // Dragging the token INTO a room always wins over a stale choice.
            if (monokuma && isSelf && room) manualEavesdrop = false;

            const target = liveKitRoomFor(sceneId, room);
            const didChange = await assignUserToRoom(user.id, target);
            if (!didChange) continue;
            changed += 1;

            // Walking your own Monokuma INTO a room means "let me talk to
            // these players" — undo the mute an earlier eavesdrop left you in,
            // so arriving does not silently leave you unheard. Only on the
            // actual transition, not on every later pass while you are still
            // standing there — a mute you choose mid-conversation must stick.
            if (monokuma && isSelf && room) {
                try {
                    await game.webrtc.client.toggleAudio(true);
                } catch {
                    // Not fatal — the room switch itself already succeeded.
                }
            }
        }
        if (changed) debug(`Voice: reassigned ${changed} participant(s).`);
    } catch (err) {
        error("Voice reconcile failed", err);
    }
}

/** Active owner only — an offline player has no AV client to move. */
function activeOwnerOf(actor) {
    return game.users.find(u => !u.isGM && u.active && actor.testUserPermission(u, "OWNER")) ?? null;
}

/* ==========================================================================
 * THE GM'S OWN VOICE — eavesdropping on a room
 * --------------------------------------------------------------------------
 * A player's client is moved by remote control: write the registry, emit a
 * socket aimed at their user id, their own client reconnects on receipt.
 * There is no equivalent remote control for your OWN client — you already
 * have it open. This reaches directly into avclient-livekit's LiveKitClient,
 * setting the same `breakoutRoom` property its own exported `breakout()`
 * function sets (see LiveKitBreakout.ts), then calls the public
 * `game.webrtc.connect()`.
 *
 * Unlike the registry+socket path above, this exact mechanism was not part of
 * the live Forge test — it is grounded in the same decompiled source, not
 * independently confirmed. Worth one manual check before relying on it.
 * ========================================================================== */

function liveKitClient() {
    return game.webrtc?.client?._liveKitClient ?? null;
}

/**
 * Move THIS client's voice to a room, or clear it (`null`) for the main room.
 * Used both by the eavesdrop dialog and by reconcileNow() when the room being
 * assigned happens to belong to the client running it.
 *
 * @returns {Promise<"changed"|"unchanged"|"no-client"|"failed">}
 */
async function applyLocalBreakout(breakoutRoom) {
    const client = liveKitClient();
    if (!client) return "no-client";

    const current = client.breakoutRoom ?? null;
    if (current === (breakoutRoom ?? null)) return "unchanged";

    try {
        client.breakoutRoom = breakoutRoom ?? undefined;
        await game.webrtc.connect();
        return "changed";
    } catch (err) {
        error("Could not switch this client's voice room", err);
        return "failed";
    }
}

/**
 * Join a room's LiveKit channel as a listener, muted on entry. Pass `null` to
 * leave, return to the main room, and hand control back to your own
 * Monokuma's token position.
 */
export async function eavesdropRoom(drpgRoom) {
    if (!game.user.isGM) return false;
    if (!avclientActive()) {
        ui.notifications.warn(game.i18n.localize("DRPG.Voice.notActive"));
        return false;
    }

    const sceneId = canvas?.scene?.id;
    const target = liveKitRoomFor(sceneId, drpgRoom);
    const result = await applyLocalBreakout(target);

    if (result === "no-client") {
        ui.notifications.warn(game.i18n.localize("DRPG.Voice.notActive"));
        return false;
    }
    if (result === "failed") {
        ui.notifications.error(game.i18n.localize("DRPG.Voice.eavesdropFailed"));
        return false;
    }

    manualEavesdrop = Boolean(drpgRoom);

    // Politeness, not a guarantee: mute on entry, only when a reconnect
    // actually happened. A GM who wants to talk can unmute as always.
    if (drpgRoom && result === "changed") {
        try {
            await game.webrtc.client.toggleAudio(false);
        } catch {
            // Not fatal — the room switch itself already succeeded.
        }
    }
    return true;
}

export function stopEavesdropping() {
    return eavesdropRoom(null);
}

/* ==========================================================================
 * RESET
 * ========================================================================== */

/** Send every currently-assigned participant back to the main room. */
export async function resetAllVoice() {
    if (!game.user.isGM || !avclientActive()) return 0;
    let n = 0;
    for (const userId of Object.keys(readRegistry())) {
        if (await assignUser(userId, null)) n += 1;
    }

    // The calling GM's own client never goes through the registry — see
    // assignUserToRoom — so it needs resetting directly, and any manual
    // eavesdrop choice should not survive a full reset.
    manualEavesdrop = false;
    if (await applyLocalBreakout(null) === "changed") n += 1;

    return n;
}

/* ==========================================================================
 * GM DIALOG
 * ========================================================================== */

export async function openEavesdropDialog() {
    if (!game.user.isGM) return;
    if (!avclientActive()) {
        ui.notifications.warn(game.i18n.localize("DRPG.Voice.notActive"));
        return;
    }

    const rooms = allRooms();
    if (!rooms.length) {
        ui.notifications.warn(game.i18n.localize("DRPG.Voice.noRooms"));
        return;
    }

    const options = rooms
        .map(r => `<option value="${foundry.utils.escapeHTML(r)}">${foundry.utils.escapeHTML(r)}</option>`)
        .join("");

    const DialogV2 = foundry.applications.api.DialogV2;
    const choice = await DialogV2.wait({
        window: { title: game.i18n.localize("DRPG.Voice.eavesdropTitle") },
        classes: ["drpg-panel"],
        content: `<form>
            <p>${game.i18n.localize("DRPG.Voice.eavesdropPrompt")}</p>
            <label>${game.i18n.localize("DRPG.Voice.room")}
                <select name="room">${options}</select></label>
        </form>`,
        buttons: [
            {
                action: "join", label: game.i18n.localize("DRPG.Voice.join"), default: true,
                callback: (event, button, dialog) => dialog.element.querySelector("[name=room]").value
            },
            { action: "stop", label: game.i18n.localize("DRPG.Voice.stopEavesdrop") },
            { action: "cancel", label: game.i18n.localize("DRPG.Panel.close") }
        ],
        rejectClose: false
    });

    if (!choice || choice === "cancel") return;

    if (choice === "stop") {
        await stopEavesdropping();
        ui.notifications.info(game.i18n.localize("DRPG.Voice.stopped"));
        return;
    }

    if (await eavesdropRoom(choice)) {
        ui.notifications.info(game.i18n.format("DRPG.Voice.joined", { room: choice }));
    }
}
