/**
 * Danganronpa RPG — voice per region.
 * ---------------------------------------------------------------------------
 * Rooms are private conversations. Text already enforces that — see
 * visibility.mjs (you cannot see who is not in your room) and
 * private-rolls.mjs (your dice are nobody else's business) — this does the
 * same for voice: every Scene Region becomes its own LiveKit breakout room,
 * and a player's voice client follows the moment their token crosses into a
 * different one.
 *
 * Built on avclient-livekit's own Breakout Rooms feature — not a fork of it,
 * not a patch to it. Everything here goes through its public surface: the
 * world-scoped `breakoutRoomRegistry` setting and its own socket channel, the
 * same two things a GM right-clicking "Start A/V breakout" in the Players
 * list already uses. Confirmed live on Forge before this was written: an
 * assigned client actually reconnects into an arbitrarily-named LiveKit room
 * (see macros/06-voice-spike.js).
 *
 * Entirely optional. Without avclient-livekit installed and active, and
 * without the world setting turned on, every function below is a no-op —
 * nothing else in this module depends on any of it.
 */

import { SETTINGS, getSetting } from "./settings.mjs";
import { roomOfActor, allRooms } from "./movement.mjs";
import { isMonokuma } from "./monokuma.mjs";
import { isPrimaryGm, debug, error } from "./utils.mjs";

const AV_MODULE = "avclient-livekit";
const REGISTRY_SETTING = "breakoutRoomRegistry";

/** Coalesces a burst of token moves (a drag, several players placing at once)
 *  into a single reassignment pass rather than reconnecting mid-drag. */
const RECONCILE_DEBOUNCE_MS = 1500;

export function registerVoice() {
    Hooks.on("updateToken", (doc, changes) => {
        if (changes.x !== undefined || changes.y !== undefined) scheduleReconcile();
    });
    Hooks.on("canvasReady", () => scheduleReconcile({ immediate: true }));
    Hooks.on("drpgTimeOfDayChanged", () => scheduleReconcile({ immediate: true }));
    // An Eclipse is a placement window: everyone repositions at once. Reconciling
    // on every intermediate move would mean each client reconnecting to LiveKit
    // over and over while the table is still shuffling tokens, so this waits
    // for it to end and applies the result in a single pass.
    Hooks.on("drpgEclipseChanged", active => {
        if (!active) scheduleReconcile({ immediate: true });
    });
}

/* ==========================================================================
 * AVCLIENT-LIVEKIT — reading and writing ITS state, not ours
 * ========================================================================== */

function avclientActive() {
    return Boolean(game.modules.get(AV_MODULE)?.active);
}

function readRegistry() {
    try {
        return game.settings.get(AV_MODULE, REGISTRY_SETTING) ?? {};
    } catch {
        return {};
    }
}

/**
 * Point one user's LiveKit client at a breakout room, or clear it (pass
 * `null`) to send them back to the world's configured main room. Mirrors
 * avclient-livekit's own `setBreakoutRoom()` + socket emit exactly — this is
 * what "Start A/V breakout" in the Players list already does, aimed at
 * whichever room a Scene Region maps to instead of a random id.
 *
 * @returns {Promise<boolean>} true if anything actually changed — callers use
 *   this to avoid reassigning (and reconnecting) players who did not move.
 */
async function assignUser(userId, breakoutRoom) {
    const registry = { ...readRegistry() };
    if ((registry[userId] ?? null) === (breakoutRoom ?? null)) return false;

    registry[userId] = breakoutRoom;
    await game.settings.set(AV_MODULE, REGISTRY_SETTING, registry);
    game.socket.emit(`module.${AV_MODULE}`, {
        action: "breakout",
        userId,
        breakoutRoom
    }, { recipients: [userId] });
    return true;
}

/* ==========================================================================
 * ROOM NAMES
 * ========================================================================== */

/**
 * A DRPG room name -> a stable LiveKit room name for this scene. `null` when
 * the character is not in any mapped room, which clears the assignment and
 * sends them back to the main room rather than inventing a "lobby" nobody
 * asked for.
 */
function liveKitRoomFor(sceneId, drpgRoom) {
    if (!sceneId || !drpgRoom) return null;
    return `drpg-${sceneId}-${slug(drpgRoom)}`;
}

function slug(name) {
    return String(name ?? "")
        .toLowerCase()
        .normalize("NFKD").replace(/[̀-ͯ]/g, "") // strip accents (ą, ę, ć…)
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/^-+|-+$/g, "") || "room";
}

/* ==========================================================================
 * RECONCILING
 * --------------------------------------------------------------------------
 * The primary GM's client watches every player's room and keeps LiveKit in
 * step. Has to be one client, and has to be a GM: `breakoutRoomRegistry` is a
 * world-scoped setting, which only a GM can write at all, and two GMs both
 * reassigning the same player on the same move would be a race, not a
 * feature — the same reasoning movement.mjs already applies to who pays for a
 * room crossing.
 * ========================================================================== */

let reconcileTimer = null;

export function scheduleReconcile({ immediate = false } = {}) {
    if (reconcileTimer) {
        clearTimeout(reconcileTimer);
        reconcileTimer = null;
    }
    if (immediate) {
        reconcileNow();
        return;
    }
    reconcileTimer = setTimeout(() => {
        reconcileTimer = null;
        reconcileNow();
    }, RECONCILE_DEBOUNCE_MS);
}

async function reconcileNow() {
    try {
        if (!isPrimaryGm()) return;
        if (!getSetting(SETTINGS.voiceEnabled)) return;
        if (!avclientActive()) return;

        const { isEclipse } = await import("./eclipse.mjs");
        if (isEclipse()) return; // batched reconcile fires when it ends

        const sceneId = canvas?.scene?.id;
        if (!sceneId) return;

        let changed = 0;
        for (const actor of game.actors.filter(a => a.type === "character")) {
            if (isMonokuma(actor)) continue;

            const owner = activeOwnerOf(actor);
            if (!owner) continue; // nobody connected to move

            const target = liveKitRoomFor(sceneId, roomOfActor(actor));
            if (await assignUser(owner.id, target)) changed += 1;
        }
        if (changed) debug(`Voice: reassigned ${changed} player(s).`);
    } catch (err) {
        error("Voice reconcile failed", err);
    }
}

/** Active owner only — an offline player has no AV client to move. */
function activeOwnerOf(actor) {
    return game.users.find(u => !u.isGM && u.active && actor.testUserPermission(u, "OWNER")) ?? null;
}

/* ==========================================================================
 * THE GM'S OWN VOICE — eavesdropping on a room
 * --------------------------------------------------------------------------
 * A player's client is moved by remote control: write the registry, emit a
 * socket aimed at their user id, their own client reconnects on receipt.
 * There is no equivalent remote control for your OWN client — you already
 * have it open. This reaches directly into avclient-livekit's LiveKitClient,
 * setting the same `breakoutRoom` property its own exported `breakout()`
 * function sets (see LiveKitBreakout.ts), then calls the public
 * `game.webrtc.connect()`.
 *
 * Unlike the registry+socket path above, this exact mechanism was not part of
 * the live Forge test — it is grounded in the same decompiled source, not
 * independently confirmed. Worth one manual check before relying on it.
 * ========================================================================== */

function liveKitClient() {
    return game.webrtc?.client?._liveKitClient ?? null;
}

/**
 * Join a room's LiveKit channel as a listener, muted on entry. Pass `null` to
 * leave and return to the main room.
 */
export async function eavesdropRoom(drpgRoom) {
    if (!game.user.isGM) return false;
    if (!avclientActive()) {
        ui.notifications.warn(game.i18n.localize("DRPG.Voice.notActive"));
        return false;
    }

    const client = liveKitClient();
    if (!client) {
        ui.notifications.warn(game.i18n.localize("DRPG.Voice.notActive"));
        return false;
    }

    const sceneId = canvas?.scene?.id;
    const target = liveKitRoomFor(sceneId, drpgRoom);

    try {
        client.breakoutRoom = target ?? undefined;
        await game.webrtc.connect();
        // Politeness, not a guarantee: mute on entry. A GM who wants to talk
        // in the room can unmute from the same controls as always.
        try {
            await game.webrtc.client.toggleAudio(false);
        } catch {
            // Not fatal — the room switch itself already succeeded.
        }
        return true;
    } catch (err) {
        error("Could not join the eavesdrop room", err);
        ui.notifications.error(game.i18n.localize("DRPG.Voice.eavesdropFailed"));
        return false;
    }
}

export function stopEavesdropping() {
    return eavesdropRoom(null);
}

/* ==========================================================================
 * RESET
 * ========================================================================== */

/** Send every currently-assigned player back to the main room. */
export async function resetAllVoice() {
    if (!game.user.isGM || !avclientActive()) return 0;
    let n = 0;
    for (const userId of Object.keys(readRegistry())) {
        if (await assignUser(userId, null)) n += 1;
    }
    return n;
}

/* ==========================================================================
 * GM DIALOG
 * ========================================================================== */

export async function openEavesdropDialog() {
    if (!game.user.isGM) return;
    if (!avclientActive()) {
        ui.notifications.warn(game.i18n.localize("DRPG.Voice.notActive"));
        return;
    }

    const rooms = allRooms();
    if (!rooms.length) {
        ui.notifications.warn(game.i18n.localize("DRPG.Voice.noRooms"));
        return;
    }

    const options = rooms
        .map(r => `<option value="${foundry.utils.escapeHTML(r)}">${foundry.utils.escapeHTML(r)}</option>`)
        .join("");

    const DialogV2 = foundry.applications.api.DialogV2;
    const choice = await DialogV2.wait({
        window: { title: game.i18n.localize("DRPG.Voice.eavesdropTitle") },
        classes: ["drpg-panel"],
        content: `<form>
            <p>${game.i18n.localize("DRPG.Voice.eavesdropPrompt")}</p>
            <label>${game.i18n.localize("DRPG.Voice.room")}
                <select name="room">${options}</select></label>
        </form>`,
        buttons: [
            {
                action: "join", label: game.i18n.localize("DRPG.Voice.join"), default: true,
                callback: (event, button, dialog) => dialog.element.querySelector("[name=room]").value
            },
            { action: "stop", label: game.i18n.localize("DRPG.Voice.stopEavesdrop") },
            { action: "cancel", label: game.i18n.localize("DRPG.Panel.close") }
        ],
        rejectClose: false
    });

    if (!choice || choice === "cancel") return;

    if (choice === "stop") {
        await stopEavesdropping();
        ui.notifications.info(game.i18n.localize("DRPG.Voice.stopped"));
        return;
    }

    if (await eavesdropRoom(choice)) {
        ui.notifications.info(game.i18n.format("DRPG.Voice.joined", { room: choice }));
    }
}
