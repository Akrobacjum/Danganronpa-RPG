/**
 * Danganronpa RPG — voice per region.
 * ---------------------------------------------------------------------------
 * Rooms are private conversations. Text already enforces that — see
 * visibility.mjs (you cannot see who is not in your room) and
 * private-rolls.mjs (your dice are nobody else's business) — this does the
 * same for voice: every Scene Region becomes its own LiveKit breakout room,
 * and a player's voice client follows the moment their token crosses into a
 * different one.
 *
 * Built on avclient-livekit's own Breakout Rooms feature — not a fork of it,
 * not a patch to it. Everything here goes through its public surface: the
 * `breakoutRoomRegistry` setting and its own socket channel, the same two
 * things a GM right-clicking "Start A/V breakout" in the Players list already
 * uses. Confirmed live on Forge before this was written: an assigned client
 * actually reconnects into an arbitrarily-named LiveKit room (see
 * macros/06-voice-spike.js).
 *
 * `breakoutRoomRegistry` is `scope: "client"` in avclient-livekit's own
 * registration, not world-scoped as an earlier pass here assumed — every
 * user's copy is private to their own client. That is harmless for what this
 * file uses it for: avclient-livekit's own reference implementation
 * (`startAVBreakout` in its LiveKitBreakout.ts) writes it purely as the GM's
 * own bookkeeping for the Players-list context menu, and reads it back only
 * on the GM's own client — the actual room switch travels entirely through
 * the socket message below, whose payload the receiving client applies
 * directly, never through the setting. `readRegistry()`/`assignUser()` mirror
 * that same write-your-own/read-your-own pattern; they must not be read as a
 * shared, cross-client source of truth.
 *
 * Entirely optional. Without avclient-livekit installed and active, and
 * without the world setting turned on, every function below is a no-op —
 * nothing else in this module depends on any of it.
 *
 * A Monokuma follows the same rule as a student: wherever the token stands is
 * whose voice they hear. Which GM that is comes from the SAME map the Despair
 * panel already uses (`poolUserFor` in monokuma.mjs) — a Monokuma spends one
 * GM's Despair and speaks with that GM's voice, not two separate assignments
 * to keep in sync. A token dragged off every mapped room sends that GM back
 * to the main room, free to use the eavesdrop dialog below on whatever they
 * like without their own token dragging them back out of it.
 */

import { MODULE_ID, FLAGS } from "./config.mjs";
import { SETTINGS, getSetting } from "./settings.mjs";
// `allRooms` only — the per-actor lookup is `locateActor`, imported lazily in
// `reconcileNow`, because it is the one that does not depend on which scene
// this GM happens to be looking at.
import { allRooms } from "./movement.mjs";
import { isMonokuma, poolUserFor } from "./monokuma.mjs";
import { isPrimaryGm, debug, error } from "./utils.mjs";

const AV_MODULE = "avclient-livekit";
const REGISTRY_SETTING = "breakoutRoomRegistry";

/** Coalesces a burst of token moves (a drag, several players placing at once)
 *  into a single reassignment pass rather than reconnecting mid-drag. */
const RECONCILE_DEBOUNCE_MS = 1500;

export function registerVoice() {
    Hooks.on("updateToken", (doc, changes) => {
        if (changes.x !== undefined || changes.y !== undefined) scheduleReconcile();
    });
    Hooks.on("canvasReady", () => scheduleReconcile({ immediate: true, force: true }));
    Hooks.on("drpgTimeOfDayChanged", () => scheduleReconcile({ immediate: true }));

    /**
     * A client that has just (re)connected starts in the main room.
     *
     * Their LiveKit client is brand new, so whatever we last told them is void
     * — and the old equality guard would have compared against exactly that
     * stale value and decided there was nothing to do. Forgetting them and
     * forcing a pass is what actually puts a returning player back in the room
     * their token is standing in, which is the single most common way this
     * subsystem was observed to "stop working".
     */
    Hooks.on("userConnected", (user, connected) => {
        if (!isPrimaryGm()) return;
        intended.delete(user.id);
        if (!connected) return;
        // Their AV client needs a moment to come up before it can be told
        // where to go; the debounce is doing that job here.
        scheduleReconcile({ force: true });
    });
    // Dying takes a voice away and opting in as a Monocub gives it back, and
    // neither of those moves a token — so without this the change would not
    // land until the next time somebody happened to walk somewhere.
    Hooks.on("updateActor", (actor, changes) => {
        const flags = changes?.flags?.[MODULE_ID];
        if (!flags) return;
        if (!(FLAGS.deceased in flags) && !(FLAGS.monocub in flags)) return;
        scheduleReconcile({ immediate: true });
    });
    // An Eclipse is a placement window: everyone repositions at once. Reconciling
    // on every intermediate move would mean each client reconnecting to LiveKit
    // over and over while the table is still shuffling tokens, so this waits
    // for it to end and applies the result in a single pass.
    Hooks.on("drpgEclipseChanged", active => {
        if (!active) scheduleReconcile({ immediate: true });
    });

    Hooks.once("ready", suppressBreakoutToasts);
}

/**
 * Silence avclient-livekit's own room-change chatter.
 *
 * A room auto-follows every token crossing here, so three of its notices — all
 * written for the rare manual right-click breakout — fire on every single
 * crossing, for every player, all session:
 *
 *   "Joining A/V breakout room"                        info
 *   "Leaving A/V breakout room"                        info
 *   "Disconnected from LiveKit A/V Server: CLIENT_..."  warn
 *
 * The last one is the loudest and the most misleading: switching rooms IS a
 * disconnect and a reconnect, so a perfectly healthy crossing announces itself
 * as a failure in a warning banner. `onDisconnected` appends the reason to the
 * localized string, so that one is matched by PREFIX — an exact-match set would
 * miss every variant of it.
 *
 * There is no setting for any of this and no hook to cancel a notification, so
 * the two methods are filtered at the source. Nothing else routed through them
 * is touched, and a genuine connection failure still reaches `error()`.
 */
function suppressBreakoutToasts() {
    if (!avclientActive()) return;

    const exact = new Set([
        game.i18n.localize("LIVEKITAVCLIENT.joiningAVBreakout"),
        game.i18n.localize("LIVEKITAVCLIENT.leavingAVBreakout")
    ]);
    // `${onDisconnected}: ${reason}` — see LiveKitAVClient#onDisconnected.
    const prefixes = [game.i18n.localize("LIVEKITAVCLIENT.onDisconnected")];

    const muted = message => {
        const text = String(message ?? "");
        return exact.has(text) || prefixes.some(p => p && text.startsWith(p));
    };

    for (const level of ["info", "warn"]) {
        const current = ui.notifications[level];
        if (current?.__drpgVoicePatched) continue;   // idempotent — safely() may retry

        const original = current.bind(ui.notifications);
        const patched = function drpgFilteredNotification(message, options) {
            if (muted(message)) return;
            return original(message, options);
        };
        patched.__drpgVoicePatched = true;
        ui.notifications[level] = patched;
    }
}

/* ==========================================================================
 * AVCLIENT-LIVEKIT — reading and writing ITS state, not ours
 * ========================================================================== */

function avclientActive() {
    return Boolean(game.modules.get(AV_MODULE)?.active);
}

function readRegistry() {
    try {
        return game.settings.get(AV_MODULE, REGISTRY_SETTING) ?? {};
    } catch {
        return {};
    }
}

/**
 * Point one user's LiveKit client at a breakout room, or clear it (pass
 * `null`) to send them back to the world's configured main room. Mirrors
 * avclient-livekit's own `setBreakoutRoom()` + socket emit exactly — this is
 * what "Start A/V breakout" in the Players list already does, aimed at
 * whichever room a Scene Region maps to instead of a random id.
 *
 * @returns {Promise<boolean>} true if anything actually changed — callers use
 *   this to avoid reassigning (and reconnecting) players who did not move.
 */
async function assignUser(userId, breakoutRoom, { force = false } = {}) {
    // What we last TOLD this client, not what a setting remembers.
    //
    // The old guard compared against `breakoutRoomRegistry`, and that is the
    // GM's own client-scoped bookkeeping — a note to itself, not a report from
    // the player. It goes stale the moment the player's own `breakoutRoom`
    // resets underneath it, which happens on a refresh, on a reconnect, and in
    // avclient-livekit's own failure path (`connect().catch` sets it back to
    // undefined). After that the GM believes they are still in the Kitchen and
    // never sends another assignment, so the player sits in the main room until
    // they happen to walk into a DIFFERENT room. That is the "it works once and
    // then stops" shape of this bug.
    if (!force && intended.get(userId) === (breakoutRoom ?? null)) return false;

    const registry = { ...readRegistry() };
    registry[userId] = breakoutRoom;
    try {
        await game.settings.set(AV_MODULE, REGISTRY_SETTING, registry);
        // The key is OMITTED rather than set to null when clearing, so the
        // payload is byte-for-byte what avclient-livekit's own "end breakout"
        // sends (`breakoutRoom: void 0`). Its receiver compares with `!==`
        // against a client whose idle value is `undefined`.
        const payload = { action: "breakout", userId };
        if (breakoutRoom) payload.breakoutRoom = breakoutRoom;

        game.socket.emit(`module.${AV_MODULE}`, payload, { recipients: [userId] });
        intended.set(userId, breakoutRoom ?? null);
        return true;
    } catch (err) {
        intended.delete(userId);   // unknown state — re-send next pass
        // Callers loop over several users in one pass (reconcileNow,
        // resetAllVoice) — an unguarded throw here used to abort that whole
        // pass, leaving everyone after this user in iteration order
        // unassigned until the next trigger. One user's failure must not cost
        // everyone else theirs.
        error(`Could not point ${userId}'s voice at "${breakoutRoom ?? "the main room"}"`, err);
        return false;
    }
}

/**
 * Point one user's voice at a room, whoever they are. The registry+socket
 * path above only works on OTHER clients — there is nobody to receive a
 * socket message aimed at yourself with any confidence, so the primary GM's
 * own assignment (when their own Monokuma is the one being reconciled) goes
 * through the direct, local path instead. See "THE GM'S OWN VOICE" below.
 *
 * @returns {Promise<boolean>} true if anything actually changed.
 */
async function assignUserToRoom(userId, breakoutRoom, options = {}) {
    if (userId === game.user.id) {
        // Self-correcting by construction: this reads the LIVE client rather
        // than any bookkeeping, so it cannot go stale the way the remote path
        // could. No `force` needed.
        const result = await applyLocalBreakout(breakoutRoom);
        return result === "changed";
    }
    return assignUser(userId, breakoutRoom, options);
}

/**
 * What we last told each client, by user id. `null` means the main room.
 *
 * Module-level and deliberately NOT persisted: it describes what this GM
 * browser has said during this session, and a fresh session should re-assert
 * everything rather than trust a note left by a previous one. Cleared for a
 * user whenever they reconnect, since their client starts over in the main
 * room and anything we think we told them is void.
 */
const intended = new Map();

/* ==========================================================================
 * ROOM NAMES
 * ========================================================================== */

/**
 * A DRPG room name -> a stable LiveKit room name for this scene. `null` when
 * the character is not in any mapped room, which clears the assignment and
 * sends them back to the main room rather than inventing a "lobby" nobody
 * asked for.
 */
function liveKitRoomFor(sceneId, drpgRoom) {
    if (!sceneId || !drpgRoom) return null;
    return `drpg-${sceneId}-${slug(drpgRoom)}`;
}

function slug(name) {
    return String(name ?? "")
        .toLowerCase()
        .normalize("NFKD").replace(/[̀-ͯ]/g, "") // strip accents (ą, ę, ć…)
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/^-+|-+$/g, "") || "room";
}

/* ==========================================================================
 * RECONCILING
 * --------------------------------------------------------------------------
 * The primary GM's client watches every player's room and keeps LiveKit in
 * step. Has to be one client, and has to be a GM: writing `breakoutRoomRegistry`
 * and emitting the breakout socket message are both GM-only, and two GMs both
 * reassigning the same player on the same move would be a race — two socket
 * messages telling one client to switch, in whatever order they happen to
 * arrive — not a feature. The same reasoning movement.mjs already applies to
 * who pays for a room crossing.
 * ========================================================================== */

let reconcileTimer = null;

/**
 * True while the primary GM has manually chosen a room from the eavesdrop
 * dialog. Suppresses auto-follow for their OWN voice only, and only while
 * their own Monokuma token is off every mapped room — dragging it INTO a room
 * always wins over a stale manual choice. Cleared by `stopEavesdropping()` and
 * by `resetAllVoice()`.
 */
let manualEavesdrop = false;

/**
 * @param {object} [options]
 * @param {boolean} [options.immediate]  Skip the debounce.
 * @param {boolean} [options.force]      Re-send every assignment even when it
 *   matches what we last sent. For the moments where a client's own idea of
 *   which room it is in has been reset underneath us — a reconnect, the world
 *   loading, voice being switched on.
 */
export function scheduleReconcile({ immediate = false, force = false } = {}) {
    if (reconcileTimer) {
        clearTimeout(reconcileTimer);
        reconcileTimer = null;
    }
    if (immediate) {
        reconcileNow({ force });
        return;
    }
    reconcileTimer = setTimeout(() => {
        reconcileTimer = null;
        reconcileNow({ force });
    }, RECONCILE_DEBOUNCE_MS);
}

async function reconcileNow({ force = false } = {}) {
    try {
        if (!isPrimaryGm()) return;
        if (!getSetting(SETTINGS.voiceEnabled)) return;
        if (!avclientActive()) return;

        const { isEclipse } = await import("./eclipse.mjs");
        if (isEclipse()) return; // batched reconcile fires when it ends

        // Located without the canvas, per actor.
        //
        // This used to read `canvas.scene.id` once and `roomOfActor()` per
        // actor, and both only ever see the scene the GM is LOOKING AT. A GM
        // reviewing a different map — the trial room, a scratch scene, the
        // world's default on load — made every player read as "in no room at
        // all", which sent the entire table back to the main room and kept them
        // there. The scene also has to come from the actor, or two players on
        // two maps would be given the same LiveKit room name for two different
        // "Kitchen"s.
        const { locateActor } = await import("./movement.mjs");

        let changed = 0;
        for (const actor of game.actors.filter(a => a.type === "character")) {
            // Isolated per actor, on purpose. `assignUserToRoom` for the
            // primary GM's own Monokuma runs a full LiveKit disconnect/
            // reconnect (see applyLocalBreakout) — the one call in this loop
            // most likely to reject, whether from a slow server or a dropped
            // connection. With one try/catch around the whole loop, that
            // single rejection aborted every actor still left to process in
            // this pass, silently — which reads exactly like "the player who
            // just moved is still grouped with whoever they left behind": the
            // moved actor's turn simply never happened this time around, and
            // nothing runs again until another token move schedules a fresh
            // pass. A GM whose own reconnect keeps failing is also exactly why
            // "Monokuma isn't audible" would stick — every other assignment
            // after theirs in `game.actors`' iteration order silently stopped
            // happening too.
            try {
                const monokuma = isMonokuma(actor);
                // A student's voice follows their active owner; a Monokuma's
                // follows whichever GM its Despair pool is pointed at — the
                // same relationship, read from the same setting, not a second
                // one.
                const user = monokuma ? poolUserFor(actor) : activeOwnerOf(actor);
                if (!user?.active) continue;

                // The dead do not talk.
                //
                // A murdered student's player stays at the table and keeps
                // watching, but their voice leaves the room with them — a body
                // that can still be heard from the crime scene it is lying in
                // gives away everything an investigation is meant to uncover.
                // They get it back the moment they opt in as a Monocub, which
                // is the guide's own re-entry point (p. 16), and a Monocub is
                // routed like any other student from there on.
                if (!monokuma && silencedByDeath(actor)) {
                    if (await assignUserToRoom(user.id, null, { force })) changed += 1;
                    continue;
                }

                const where = locateActor(actor);
                const room = where?.room ?? null;
                const isSelf = user.id === game.user.id;

                // Your own Monokuma, off the map, while you are manually
                // listening to a room you picked from the dialog: leave it alone.
                if (monokuma && isSelf && !room && manualEavesdrop) continue;
                // Dragging the token INTO a room always wins over a stale choice.
                if (monokuma && isSelf && room) manualEavesdrop = false;

                const target = liveKitRoomFor(where?.scene?.id ?? null, room);
                const didChange = await assignUserToRoom(user.id, target, { force });
                if (!didChange) continue;
                changed += 1;

                // Walking your own Monokuma INTO a room means "let me talk to
                // these players" — undo the mute an earlier eavesdrop left you in,
                // so arriving does not silently leave you unheard. Only on the
                // actual transition, not on every later pass while you are still
                // standing there — a mute you choose mid-conversation must stick.
                if (monokuma && isSelf && room) {
                    try {
                        await game.webrtc.client.toggleAudio(true);
                    } catch {
                        // Not fatal — the room switch itself already succeeded.
                    }
                }
            } catch (err) {
                error(`Voice reconcile failed for "${actor.name}"; continuing with the rest`, err);
            }
        }
        if (changed) debug(`Voice: reassigned ${changed} participant(s).`);
    } catch (err) {
        error("Voice reconcile failed", err);
    }
}

/** Active owner only — an offline player has no AV client to move. */
function activeOwnerOf(actor) {
    return game.users.find(u => !u.isGM && u.active && actor.testUserPermission(u, "OWNER")) ?? null;
}

/**
 * Dead, and not yet back as a Monocub.
 *
 * Read straight off the two flags rather than through `chapter.mjs`/`monocub.mjs`
 * — this runs inside the reconcile loop on every token move, and a dynamic
 * import per actor per pass is a lot of churn for two boolean reads.
 */
function silencedByDeath(actor) {
    const dead = Boolean(actor?.getFlag?.(MODULE_ID, FLAGS.deceased));
    if (!dead) return false;
    return !actor.getFlag(MODULE_ID, FLAGS.monocub);
}

/* ==========================================================================
 * THE GM'S OWN VOICE — eavesdropping on a room
 * --------------------------------------------------------------------------
 * A player's client is moved by remote control: write the registry, emit a
 * socket aimed at their user id, their own client reconnects on receipt.
 * There is no equivalent remote control for your OWN client — you already
 * have it open. This reaches directly into avclient-livekit's LiveKitClient,
 * setting the same `breakoutRoom` property its own exported `breakout()`
 * function sets (see LiveKitBreakout.ts), then calls the public
 * `game.webrtc.connect()`.
 *
 * Unlike the registry+socket path above, this exact mechanism was not part of
 * the live Forge test — it is grounded in the same decompiled source, not
 * independently confirmed. Worth one manual check before relying on it.
 * ========================================================================== */

function liveKitClient() {
    return game.webrtc?.client?._liveKitClient ?? null;
}

/**
 * Move THIS client's voice to a room, or clear it (`null`) for the main room.
 * Used both by the eavesdrop dialog and by reconcileNow() when the room being
 * assigned happens to belong to the client running it.
 *
 * @returns {Promise<"changed"|"unchanged"|"no-client"|"failed">}
 */
async function applyLocalBreakout(breakoutRoom) {
    const client = liveKitClient();
    if (!client) return "no-client";

    const current = client.breakoutRoom ?? null;
    if (current === (breakoutRoom ?? null)) return "unchanged";

    try {
        client.breakoutRoom = breakoutRoom ?? undefined;
        await game.webrtc.connect();
        return "changed";
    } catch (err) {
        error("Could not switch this client's voice room", err);
        return "failed";
    }
}

/**
 * Join a room's LiveKit channel as a listener, muted on entry. Pass `null` to
 * leave, return to the main room, and hand control back to your own
 * Monokuma's token position.
 */
export async function eavesdropRoom(drpgRoom) {
    if (!game.user.isGM) return false;
    if (!avclientActive()) {
        ui.notifications.warn(game.i18n.localize("DRPG.Voice.notActive"));
        return false;
    }

    const sceneId = canvas?.scene?.id;
    const target = liveKitRoomFor(sceneId, drpgRoom);
    const result = await applyLocalBreakout(target);

    if (result === "no-client") {
        ui.notifications.warn(game.i18n.localize("DRPG.Voice.notActive"));
        return false;
    }
    if (result === "failed") {
        ui.notifications.error(game.i18n.localize("DRPG.Voice.eavesdropFailed"));
        return false;
    }

    manualEavesdrop = Boolean(drpgRoom);

    // Politeness, not a guarantee: mute on entry, only when a reconnect
    // actually happened. A GM who wants to talk can unmute as always.
    if (drpgRoom && result === "changed") {
        try {
            await game.webrtc.client.toggleAudio(false);
        } catch {
            // Not fatal — the room switch itself already succeeded.
        }
    }
    return true;
}

export function stopEavesdropping() {
    return eavesdropRoom(null);
}

/* ==========================================================================
 * RESET
 * ========================================================================== */

/** Send every currently-assigned participant back to the main room. */
export async function resetAllVoice() {
    if (!game.user.isGM || !avclientActive()) return 0;
    let n = 0;
    for (const userId of Object.keys(readRegistry())) {
        if (await assignUser(userId, null)) n += 1;
    }

    // The calling GM's own client never goes through the registry — see
    // assignUserToRoom — so it needs resetting directly, and any manual
    // eavesdrop choice should not survive a full reset.
    manualEavesdrop = false;
    if (await applyLocalBreakout(null) === "changed") n += 1;

    // Forget what we think everyone was told. "Send everybody back" is also the
    // GM's way of saying "this has drifted, start again", and leaving the intent
    // map populated would have the next pass skip exactly the people it was
    // just used to fix.
    intended.clear();

    return n;
}

/* ==========================================================================
 * GM DIALOG
 * ========================================================================== */

export async function openEavesdropDialog() {
    if (!game.user.isGM) return;
    if (!avclientActive()) {
        ui.notifications.warn(game.i18n.localize("DRPG.Voice.notActive"));
        return;
    }

    const rooms = allRooms();
    if (!rooms.length) {
        ui.notifications.warn(game.i18n.localize("DRPG.Voice.noRooms"));
        return;
    }

    const options = rooms
        .map(r => `<option value="${foundry.utils.escapeHTML(r)}">${foundry.utils.escapeHTML(r)}</option>`)
        .join("");

    const DialogV2 = foundry.applications.api.DialogV2;
    const choice = await DialogV2.wait({
        window: { title: game.i18n.localize("DRPG.Voice.eavesdropTitle") },
        classes: ["drpg-panel"],
        content: `<form>
            <p>${game.i18n.localize("DRPG.Voice.eavesdropPrompt")}</p>
            <label>${game.i18n.localize("DRPG.Voice.room")}
                <select name="room">${options}</select></label>
        </form>`,
        buttons: [
            {
                action: "join", label: game.i18n.localize("DRPG.Voice.join"), default: true,
                callback: (event, button, dialog) => dialog.element.querySelector("[name=room]").value
            },
            { action: "stop", label: game.i18n.localize("DRPG.Voice.stopEavesdrop") },
            { action: "cancel", label: game.i18n.localize("DRPG.Panel.close") }
        ],
        rejectClose: false
    });

    if (!choice || choice === "cancel") return;

    if (choice === "stop") {
        await stopEavesdropping();
        ui.notifications.info(game.i18n.localize("DRPG.Voice.stopped"));
        return;
    }

    if (await eavesdropRoom(choice)) {
        ui.notifications.info(game.i18n.format("DRPG.Voice.joined", { room: choice }));
    }
}
