/**
 * Danganronpa RPG — world settings.
 * ---------------------------------------------------------------------------
 * Registered during `init`. Anything the GM should be able to flip lives here
 * with `config: true`; internal state is stored with `config: false` so it
 * never clutters the settings window.
 */

import { MODULE_ID, ROOMS, TIMES_OF_DAY } from "./config.mjs";

/** Setting keys, so nothing else in the module has to spell them out. */
export const SETTINGS = {
    forcePrivateRolls: "forcePrivateRolls",
    enforceAnonymity: "enforceAnonymity",
    searchTokensPerRoom: "searchTokensPerRoom",
    searchTokens: "searchTokens",
    clock: "clock",
    despairPools: "despairPools",
    /** Custom display label per pool, independent of the account name. */
    poolNames: "poolNames",
    /** Assistant GMs explicitly granted their own Despair pool. */
    extraPoolUsers: "extraPoolUsers",
    /** Which Gamemaster's pool each Monokuma actor spends from. */
    monokumaPools: "monokumaPools",
    gmAssignments: "gmAssignments",
    despairFromRolls: "despairFromRolls",
    projectMeta: "projectMeta",
    chargeMovement: "chargeMovement",
    lockPlayerResources: "lockPlayerResources",
    roomVisibility: "roomVisibility",
    lockRollDialog: "lockRollDialog",
    eclipseMoves: "eclipseMoves",
    sealedRooms: "sealedRooms",
    /** Per-player Despair Call restrictions, cleared with the clock. */
    restrictions: "restrictions",
    hideSystemFear: "hideSystemFear",
    pixelFont: "pixelFont",
    debug: "debug",
    /** Regions become LiveKit breakout rooms — off by default, needs avclient-livekit. */
    voiceEnabled: "voiceEnabled",
    /** Per-client: the last time each messenger thread was read, by player user id. */
    messengerLastRead: "messengerLastRead",
    /** Per-client: remembered position/size of each messenger window, by player user id. */
    messengerWindowPositions: "messengerWindowPositions"
};

/** Shape of the campaign clock stored under SETTINGS.clock. */
export const DEFAULT_CLOCK = {
    /**
     * True while the placement window between two times of day is running.
     * An Eclipse is not part of a day — the day counter does not move for it.
     */
    eclipse: false,
    /** Free text shown at the top of the HUD, e.g. "Hope's Peak: Drowned Summer". */
    campaignName: "",
    season: 1,
    chapter: 1,
    session: 1,
    /** In-fiction day. Five times of day make one day; ticks over automatically. */
    day: 1,
    /** One of the keys in PHASES: dailyLife | investigation | classTrial. */
    phase: "dailyLife",
    timeOfDay: TIMES_OF_DAY[0]
};

export function registerSettings() {
    game.settings.register(MODULE_ID, SETTINGS.forcePrivateRolls, {
        name: "DRPG.Settings.forcePrivateRolls.name",
        hint: "DRPG.Settings.forcePrivateRolls.hint",
        scope: "world",
        config: true,
        type: Boolean,
        default: true
    });

    game.settings.register(MODULE_ID, SETTINGS.enforceAnonymity, {
        name: "DRPG.Settings.enforceAnonymity.name",
        hint: "DRPG.Settings.enforceAnonymity.hint",
        scope: "world",
        config: true,
        type: Boolean,
        default: true
    });

    game.settings.register(MODULE_ID, SETTINGS.searchTokensPerRoom, {
        name: "DRPG.Settings.searchTokensPerRoom.name",
        hint: "DRPG.Settings.searchTokensPerRoom.hint",
        scope: "world",
        config: true,
        type: Number,
        default: ROOMS.searchTokensPerRoom,
        range: { min: 0, max: 10, step: 1 }
    });

    game.settings.register(MODULE_ID, SETTINGS.hideSystemFear, {
        name: "DRPG.Settings.hideSystemFear.name",
        hint: "DRPG.Settings.hideSystemFear.hint",
        scope: "world",
        config: true,
        type: Boolean,
        default: true,
        onChange: () => document.body.classList.toggle("drpg-hide-system-fear", getSetting(SETTINGS.hideSystemFear))
    });

    game.settings.register(MODULE_ID, SETTINGS.pixelFont, {
        name: "DRPG.Settings.pixelFont.name",
        hint: "DRPG.Settings.pixelFont.hint",
        scope: "world",
        config: true,
        type: Boolean,
        default: true,
        onChange: () => document.body.classList.toggle("drpg-pixel-font", getSetting(SETTINGS.pixelFont))
    });

    game.settings.register(MODULE_ID, SETTINGS.debug, {
        name: "DRPG.Settings.debug.name",
        hint: "DRPG.Settings.debug.hint",
        scope: "client",
        config: true,
        type: Boolean,
        default: false
    });

    game.settings.register(MODULE_ID, SETTINGS.voiceEnabled, {
        name: "DRPG.Settings.voiceEnabled.name",
        hint: "DRPG.Settings.voiceEnabled.hint",
        scope: "world",
        config: true,
        type: Boolean,
        default: false,
        onChange: value => {
            // Turning it on should take effect immediately, not wait for the
            // next token move. Turning it off should let everyone go, not
            // strand them in whatever room they were last assigned to.
            import("./voice.mjs").then(m => {
                if (value) m.scheduleReconcile({ immediate: true });
                else m.resetAllVoice();
            }).catch(() => {});
        }
    });

    /* ---- internal state, never shown in the settings window ---- */

    // Read state is personal — the player's and each GM's own idea of what
    // they have seen — so this is client-scoped, not world-scoped like
    // everything else below it.
    game.settings.register(MODULE_ID, SETTINGS.messengerLastRead, {
        scope: "client",
        config: false,
        type: Object,
        default: {}
    });

    game.settings.register(MODULE_ID, SETTINGS.messengerWindowPositions, {
        scope: "client",
        config: false,
        type: Object,
        default: {}
    });

    game.settings.register(MODULE_ID, SETTINGS.despairFromRolls, {
        name: "DRPG.Settings.despairFromRolls.name",
        hint: "DRPG.Settings.despairFromRolls.hint",
        scope: "world",
        config: true,
        type: Boolean,
        default: true
    });

    game.settings.register(MODULE_ID, SETTINGS.lockRollDialog, {
        name: "DRPG.Settings.lockRollDialog.name",
        hint: "DRPG.Settings.lockRollDialog.hint",
        scope: "world",
        config: true,
        type: Boolean,
        default: true
    });

    game.settings.register(MODULE_ID, SETTINGS.roomVisibility, {
        name: "DRPG.Settings.roomVisibility.name",
        hint: "DRPG.Settings.roomVisibility.hint",
        scope: "world",
        config: true,
        type: Boolean,
        default: true,
        onChange: () => {
            import("./visibility.mjs").then(m => m.applyAll()).catch(() => {});
        }
    });

    game.settings.register(MODULE_ID, SETTINGS.lockPlayerResources, {
        name: "DRPG.Settings.lockPlayerResources.name",
        hint: "DRPG.Settings.lockPlayerResources.hint",
        scope: "world",
        config: true,
        type: Boolean,
        default: true
    });

    game.settings.register(MODULE_ID, SETTINGS.chargeMovement, {
        name: "DRPG.Settings.chargeMovement.name",
        hint: "DRPG.Settings.chargeMovement.hint",
        scope: "world",
        config: true,
        type: Boolean,
        default: true
    });

    // Rooms sealed by "Behind Closed Doors". Cleared when the clock advances.
    game.settings.register(MODULE_ID, SETTINGS.sealedRooms, {
        scope: "world",
        config: false,
        type: Array,
        default: [],
        onChange: () => onWorldChange(SETTINGS.sealedRooms)
    });

    // Silenced and chained players, by actor id. A Despair Call lasts one time
    // of day, so this is emptied whenever the clock moves.
    game.settings.register(MODULE_ID, SETTINGS.restrictions, {
        scope: "world",
        config: false,
        type: Object,
        default: {},
        onChange: () => onWorldChange(SETTINGS.restrictions)
    });

    // Eclipse crossings used, per actor. Cleared when the Eclipse ends.
    game.settings.register(MODULE_ID, SETTINGS.eclipseMoves, {
        scope: "world",
        config: false,
        type: Object,
        default: {},
        onChange: () => onWorldChange(SETTINGS.eclipseMoves)
    });

    // Per-project data Daggerheart's countdowns do not carry: which room the
    // project belongs to, whether it is an indirect murder, whether it is secret.
    game.settings.register(MODULE_ID, SETTINGS.projectMeta, {
        scope: "world",
        config: false,
        type: Object,
        default: {},
        onChange: () => onWorldChange(SETTINGS.projectMeta)
    });

    // Which Monokuma looks after which student. Format: { "<actorId>": "<userId>" }
    game.settings.register(MODULE_ID, SETTINGS.gmAssignments, {
        scope: "world",
        config: false,
        type: Object,
        default: {},
        onChange: () => {
            import("./despair.mjs").then(m => m.renderDespairBar()).catch(() => {});
        }
    });

    // One Despair pool per full Gamemaster. Format: { "<userId>": 7 }
    game.settings.register(MODULE_ID, SETTINGS.despairPools, {
        scope: "world",
        config: false,
        type: Object,
        default: {},
        onChange: () => onWorldChange(SETTINGS.despairPools)
    });

    // Custom display label per pool — a GM's account name is not always what
    // the table calls their Monokuma. Format: { "<userId>": "Monokid" }
    game.settings.register(MODULE_ID, SETTINGS.poolNames, {
        scope: "world",
        config: false,
        type: Object,
        default: {},
        onChange: () => onWorldChange(SETTINGS.poolNames)
    });

    // Assistant GMs given a pool of their own, beyond the automatic one every
    // full Gamemaster already gets. Format: ["<userId>", ...]
    game.settings.register(MODULE_ID, SETTINGS.extraPoolUsers, {
        scope: "world",
        config: false,
        type: Array,
        default: [],
        onChange: () => onWorldChange(SETTINGS.extraPoolUsers)
    });

    // Which Gamemaster's pool each Monokuma actor draws on. Set in the Monokuma
    // panel. Format: { "<actorId>": "<userId>" }
    game.settings.register(MODULE_ID, SETTINGS.monokumaPools, {
        scope: "world",
        config: false,
        type: Object,
        default: {},
        onChange: () => onWorldChange(SETTINGS.monokumaPools)
    });

    // Search token counters, keyed by room. Format: { "Library": 2, "Kitchen": 0 }
    game.settings.register(MODULE_ID, SETTINGS.searchTokens, {
        scope: "world",
        config: false,
        type: Object,
        default: {},
        onChange: () => onWorldChange(SETTINGS.searchTokens)
    });

    // Where we are in the campaign. Advanced from the GM panel.
    game.settings.register(MODULE_ID, SETTINGS.clock, {
        scope: "world",
        config: false,
        type: Object,
        default: DEFAULT_CLOCK,
        // The clock is the one every player watches, so this does the whole
        // refresh — HUD, sheets, Eclipse dimming, room visibility — not just the
        // sheets. Redrawing the sheets alone was why the time of day changed in
        // the header while the Eclipse stayed light and tokens stayed visible.
        onChange: () => onWorldChange(SETTINGS.clock)
    });
}

/**
 * Refresh this client because a world setting changed.
 *
 * Foundry syncs the Setting document to every client and runs the registered
 * `onChange` there, so this fires on the players' screens as well as the GM's —
 * which is exactly what the module's socket could not be relied on to do.
 */
function onWorldChange(key) {
    import("./sync.mjs").then(m => m.applyFor(key)).catch(() => {});
}

/** Convenience reader. */
export function getSetting(key) {
    return game.settings.get(MODULE_ID, key);
}

/** Convenience writer. GM-only for world-scoped settings. */
export function setSetting(key, value) {
    return game.settings.set(MODULE_ID, key, value);
}
