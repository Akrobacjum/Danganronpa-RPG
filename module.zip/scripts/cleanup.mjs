/**
 * Danganronpa RPG — Stage 6, the killer cleaning up.
 * ---------------------------------------------------------------------------
 * Guide: once the incident is over the killer can finally see the Remnants they
 * left, and spend Stress trying to make them go away. "Przedmioty sprzątające
 * ułatwiają rozwiązanie morderstwa" — this is the stage the Cleaning Tool exists
 * for.
 *
 * Until now the module wrote `stage: "resolution"` and stopped. Everything the
 * stage needed was already modelled and unused: the `reinforced` flag on a
 * Remnant is documented in remnants.mjs as "cannot be removed by the killer in
 * Stage 6", `resolution` is a real Remnant type described as "left by the
 * killer's mistakes while cleaning up the scene", `RESOLUTION_STRESS_COST` is
 * declared, and `removeRemnant` refuses reinforced traces on its own. There was
 * simply nothing that called any of it. This is the missing half.
 *
 * WHY THE SCORING RUNS ON THE GM'S CLIENT. Same reason as Observe (see
 * observe.mjs): the threshold comes from how visible the trace is, which is a
 * flag on a hidden token — and Foundry ships every token to every client, so the
 * killer's own browser physically holds the answer. Their client picks a target
 * and throws the dice; the number travels here, and the verdict, the deletion
 * and the new trace are all produced on this side.
 *
 * WHAT IS NOT AUTOMATED. Whether the killer is standing in the right room, and
 * whether Stage 6 has gone on long enough — both the GM's, as everywhere else in
 * murder.mjs. This owns the numbers and the tokens.
 */

import { MODULE_ID, CLEANUP, RESOLUTION_STRESS_COST } from "./config.mjs";
import { murderState } from "./murder.mjs";
import {
    REMNANT_FLAGS, remnantsInRoom, remnantData, removeRemnant, dropRemnant
} from "./remnants.mjs";
import { roomOfToken } from "./movement.mjs";
import { equippedIn } from "./use-items.mjs";
import { ITEM_FLAGS } from "./inventory.mjs";
import { resourceValue, resourceMax } from "./character.mjs";
import { automatedUpdate } from "./resource-guard.mjs";
import { whisperToGms, whisperToOwner, log, error } from "./utils.mjs";

/* ==========================================================================
 * WHO MAY CLEAN, AND WHAT
 * ========================================================================== */

/** Is a clean-up possible at all right now? */
export function isResolutionStage() {
    return murderState()?.stage === "resolution";
}

/**
 * The killer of the incident currently in Stage 6, if this is them.
 *
 * Role reversal can have swapped the two sides mid-incident, so this reads the
 * state rather than remembering who opened the murder — the person who ends up
 * cleaning is whoever the state calls the killer when the fight stopped.
 */
export function isCleaner(actor) {
    const state = murderState();
    if (!state || state.stage !== "resolution") return false;
    return state.killerId === actor?.id;
}

/**
 * Every trace in the killer's own room that a clean-up could be aimed at.
 *
 * Reinforced ones are INCLUDED and marked, not filtered out. A killer who can
 * see the smear they cannot get rid of is being told something true and
 * important about their case; silently omitting it would read as "there is
 * nothing else here".
 *
 * @returns {Array<{token: TokenDocument, data: object, dc: number|null}>}
 */
export function cleanableRemnants(actor, where = null) {
    if (!actor) return [];

    const spot = where ?? locate(actor);
    if (!spot?.room) return [];

    return remnantsInRoom(spot.room, spot.scene)
        .map(token => {
            const data = remnantData(token);
            if (!data) return null;
            return { token, data, dc: data.reinforced ? null : cleanupDc(data.visibility, actor) };
        })
        .filter(Boolean)
        // Reinforced last: they are the ones that cannot be acted on.
        .sort((a, b) => {
            if (a.data.reinforced !== b.data.reinforced) return a.data.reinforced ? 1 : -1;
            return (a.dc ?? 0) - (b.dc ?? 0);
        });
}

/**
 * Where this character is standing: scene, token AND room.
 *
 * The room is the whole point — `cleanableRemnants` filters on it — and the
 * first version of this returned only the scene and the token, so every caller
 * bailed on `if (!spot?.room)` and Stage 6 listed nothing for anybody, ever.
 *
 * `roomOfToken` rather than `roomOfActor`: the latter only sees the scene the
 * client is currently looking at, and this runs on a GM who is very often
 * looking somewhere else entirely.
 *
 * Synchronous, so the sheet and the tracker can build a list without awaiting.
 */
function locate(actor) {
    const active = actor?.getActiveTokens?.()?.[0]?.document;
    if (active?.parent) {
        return { scene: active.parent, tokenDoc: active, room: roomOfToken(active) };
    }

    for (const scene of game.scenes) {
        const tokenDoc = scene.tokens.find(t => t.actorId === actor?.id);
        if (tokenDoc) return { scene, tokenDoc, room: roomOfToken(tokenDoc) };
    }
    return null;
}

/**
 * How hard this trace is to erase, with the tool in hand taken off the top.
 *
 * Only an EQUIPPED Cleaning Tool counts, matching the weapon rule in murder.mjs:
 * the guide's tools are objects in a hand, not entries on an inventory list.
 */
export function cleanupDc(visibility, actor) {
    const base = CLEANUP.dc[visibility];
    if (base === undefined) return null;
    if (!CLEANUP.toolTierReducesDc) return base;
    return Math.max(0, base - cleaningTier(actor));
}

/** The tier of the readied Cleaning Tool, or 0 for bare hands. */
export function cleaningTier(actor) {
    const tool = equippedIn(actor, "cleaningTool");
    if (!tool) return 0;
    return Number(tool.getFlag(MODULE_ID, ITEM_FLAGS.tier) ?? 0);
}

export function cleaningTool(actor) {
    return equippedIn(actor, "cleaningTool");
}

/** One Remnant token by id, from whichever scene it is on. */
function findRemnantToken(tokenId) {
    if (!tokenId) return null;
    for (const scene of game.scenes) {
        const token = scene.tokens.get(tokenId);
        if (token) return token;
    }
    return null;
}

/* ==========================================================================
 * THE ROLL — player side
 * ========================================================================== */

/**
 * Attempt to erase one trace.
 *
 * Costs Stress rather than an action, as the guide has it: Stage 6 is not part
 * of the day's economy, and a killer with nothing left to give simply cannot
 * keep scrubbing. Refused before the dice when there is no Stress to spend, so
 * nobody rolls for something they cannot pay for.
 *
 * The threshold is not computed here and never travels to this client — see the
 * note at the top of the file. What goes over the socket is which token was
 * aimed at and what the dice said.
 */
export async function attemptCleanup(actor, tokenId) {
    if (!actor || !tokenId) return null;

    if (!isCleaner(actor)) {
        ui.notifications.warn(game.i18n.localize("DRPG.Cleanup.notYours"));
        return null;
    }
    if (resourceValue(actor, "stress") >= resourceMax(actor, "stress")) {
        ui.notifications.warn(game.i18n.localize("DRPG.Murder.noStressLeft"));
        return null;
    }

    const { rollTrait } = await import("./action-rolls.mjs");
    const calls = await import("./call-effects.mjs");

    // The tool in hand is worth advantage on top of the threshold it lowers —
    // the guide's "ułatwiają" applied to both halves of "easier".
    const tool = cleaningTool(actor);
    if (CLEANUP.toolAdvantage && tool) calls.armSituational(1);

    let roll;
    try {
        roll = await rollTrait(actor, CLEANUP.traits[0], {
            actionKey: "cleanup", context: { cleanup: tokenId }
        });
    } finally {
        calls.clearSituational();
    }
    if (!roll) return null;

    const { requestCleanup } = await import("./gm-bridge.mjs");
    await requestCleanup({
        actorId: actor.id,
        tokenId,
        total: roll.total,
        isCritical: Boolean(roll.isCritical),
        withHope: Boolean(roll.withHope)
    });

    return { roll };
}

/* ==========================================================================
 * THE VERDICT — GM side
 * ========================================================================== */

/**
 * Score one clean-up attempt and apply it.
 *
 * @param {object} options
 * @param {string} options.actorId
 * @param {string} options.tokenId  The Remnant token being wiped.
 * @param {number} options.total
 * @param {boolean} [options.isCritical]
 * @param {boolean} [options.withHope]
 */
export async function resolveCleanup({
    actorId, tokenId, total, isCritical = false, withHope = false, undo = false
} = {}) {
    if (!game.user.isGM) return null;

    const actor = game.actors.get(actorId);
    if (!actor) return null;
    if (!isCleaner(actor)) return null;

    // A Reroll: put the scene back the way it was before scoring the new number,
    // or the second attempt would be measured against a room the first one had
    // already changed — and the Stress would be charged twice for one attempt.
    //
    // A rewind that could not happen aborts the replay rather than scoring on
    // top of the first attempt. `undoLastCleanup` has already told the GMs what
    // to put right by hand.
    if (undo && !await undoLastCleanup(actor, tokenId)) return null;

    // Searched across every scene rather than only the one the killer is
    // standing on. The two are the same in the normal case, and are NOT the same
    // if the killer's token was moved between picking a trace and the dice
    // landing — where scoping to their current scene would report the trace as
    // vanished and charge them for it.
    const token = findRemnantToken(tokenId);
    const data = token ? remnantData(token) : null;
    if (!data) {
        // The trace is gone — another attempt got it, or the GM removed it by
        // hand between the player picking and the dice landing. The Stress is
        // still spent: they scrubbed at something.
        await spendStress(actor);
        await whisperToOwner(actor, `<p>${game.i18n.localize("DRPG.Cleanup.vanished")}</p>`);
        return { removed: false, gone: true };
    }

    // Reinforced traces refuse to be removed at all — remnants.mjs has said so
    // since the flag was introduced. Checked here as well as there so the Stress
    // is not taken for an attempt that was never possible.
    if (data.reinforced) {
        await whisperToOwner(actor, `<p>${game.i18n.format("DRPG.Cleanup.reinforced", {
            what: foundry.utils.escapeHTML(`${data.visibilityLabel} ${data.typeLabel}`)
        })}</p>`);
        return { removed: false, reinforced: true };
    }

    const dc = cleanupDc(data.visibility, actor);
    const success = isCritical || (dc !== null && total >= dc);
    const band = isCritical ? "critical" : (success ? (withHope ? "hope" : "despair") : "failure");
    const outcome = CLEANUP.outcome[band] ?? CLEANUP.outcome.failure;

    // Everything needed to put this attempt back, recorded before it happens.
    // The erased trace is stored as its full creation data rather than as an id,
    // because by the time a Reroll asks for it the token no longer exists.
    const receipt = {
        actorId,
        tokenId,
        stressBefore: resourceValue(actor, "stress"),
        erased: null,
        leftBehind: null
    };

    await spendStress(actor);

    const done = [];

    if (outcome.removes) {
        try {
            receipt.erased = recreationDataFor(token);
            // Through `removeRemnant` rather than `token.delete()`: it owns the
            // refusal of reinforced traces, and one place deciding that is the
            // difference between a rule and two rules that can drift apart.
            await removeRemnant(token);
            done.push(game.i18n.format("DRPG.Cleanup.removed", {
                what: `${data.visibilityLabel} ${data.typeLabel}`
            }));
        } catch (err) {
            error("Could not remove the Remnant a clean-up erased", err);
        }
    } else {
        done.push(game.i18n.localize("DRPG.Cleanup.stillThere"));
    }

    if (outcome.leaves) {
        const placed = await dropRemnant(actor, {
            type: CLEANUP.remnantType,
            visibility: outcome.leaves.visibility,
            faint: outcome.leaves.faint,
            // Tied to the crime, so the chapter-end sweep leaves it alone unless
            // it is faint — the guide's own exception, already honoured by
            // `clearFaintRemnants`.
            tiedToCrime: true,
            // "resolution", not "cleanup": `DRPG.Remnant.action.resolution` is
            // already defined as "Cleanup" — the vocabulary was written for this
            // stage before there was anything to fill it.
            action: "resolution",
            note: game.i18n.format("DRPG.Cleanup.remnantNote", {
                what: `${data.visibilityLabel} ${data.typeLabel}`
            })
        });
        if (placed) {
            receipt.leftBehind = refOf(placed);
            done.push(game.i18n.format("DRPG.Cleanup.leftTrace", {
                visibility: outcome.leaves.visibility
            }));
        }
    }

    await report(actor, data, { band, success, total, dc, done });
    lastAttempt.set(actorId, receipt);

    log(`Cleanup: ${actor.name} rolled ${total} against DC ${dc} on a ${data.visibility} ${data.type} — ${band}.`);
    return { removed: Boolean(outcome.removes), band, done };
}

/* ==========================================================================
 * TAKING A CLEAN-UP BACK — the Reroll's other half
 * --------------------------------------------------------------------------
 * Kept on this client rather than in a world setting, unlike the incident's own
 * receipt in murder.mjs. What it holds is the answer key: the full creation data
 * of a Remnant, including how visible it is and what it really is. Writing that
 * into the murder state would publish it to every player's console — see
 * truth-bullets.mjs for the same reasoning about the ledger. The cost is that a
 * GM who reloads mid-Stage-6 cannot replay a clean-up, which is the same trade
 * observe.mjs already makes, and it says so when it happens.
 * ========================================================================== */

/** actorId -> what their last clean-up attempt did. GM browsers only. */
const lastAttempt = new Map();

function refOf(placed) {
    const doc = placed?.document ?? placed;
    if (!doc?.id) return null;
    return { id: doc.id, sceneId: doc.parent?.id ?? null };
}

/**
 * Enough to build this Remnant again where it stood, with everything it knew.
 *
 * `placeRemnant` takes exactly this shape, so recreating is handing the flags
 * back rather than reconstructing them from a summary.
 *
 * The token ID is the one thing that cannot come back — Foundry mints a new one.
 * Two things key off it, and neither is hurt here: a Truth Bullet's `remnantId`
 * (a back-reference for the GM, not something the trial reads), and the
 * already-copied check that stops one character copying one trace twice. The
 * second means a character who had already found this trace could find it again
 * after a reroll, which is a strictly kinder failure than the trace staying
 * erased.
 */
function recreationDataFor(token) {
    const f = key => token.getFlag(MODULE_ID, REMNANT_FLAGS[key]);
    return {
        x: token.x,
        y: token.y,
        sceneId: token.parent?.id ?? null,
        type: f("type"),
        visibility: f("visibility"),
        faint: Boolean(f("faint")),
        reinforced: Boolean(f("reinforced")),
        tiedToCrime: Boolean(f("tiedToCrime")),
        note: f("note") ?? "",
        action: f("action") ?? "manual",
        subject: f("subject") ?? "",
        pointsAt: f("pointsAt") ?? null,
        sourceActor: f("sourceActor") ?? null,
        sourceName: f("sourceName") ?? "",
        room: f("room") ?? null,
        chapter: f("chapter") ?? null,
        day: f("day") ?? null,
        timeOfDay: f("timeOfDay") ?? null
    };
}

/**
 * Put the room back the way it was before this actor's last clean-up attempt.
 *
 * Order matters: the trace it left behind goes first, then the one it erased
 * comes back, then the Stress. Doing it the other way round would briefly leave
 * two traces describing the same wipe, and `cleanableRemnants` runs off exactly
 * that list.
 */
async function undoLastCleanup(actor, tokenId) {
    const receipt = lastAttempt.get(actor.id);
    if (!receipt) {
        await whisperToGms(`<p class="drpg-warning">${
            game.i18n.localize("DRPG.Cleanup.rerollLost")}</p>`);
        return false;
    }
    if (receipt.tokenId !== tokenId) {
        error(`Cleanup reroll: the recorded attempt was on a different trace (${receipt.tokenId}).`);
        // Same contract as a lost receipt: the caller aborts, and a human is
        // told, because the dice on the player's screen have already changed.
        await whisperToGms(`<p class="drpg-warning">${
            game.i18n.localize("DRPG.Cleanup.rerollLost")}</p>`);
        return false;
    }

    if (receipt.leftBehind?.id) {
        try {
            const scene = receipt.leftBehind.sceneId
                ? game.scenes.get(receipt.leftBehind.sceneId)
                : null;
            await scene?.tokens?.get(receipt.leftBehind.id)?.delete();
        } catch (err) {
            error("Could not take back the trace a rerolled clean-up left", err);
        }
    }

    if (receipt.erased) {
        try {
            const { placeRemnant } = await import("./remnants.mjs");
            await placeRemnant(receipt.erased);
        } catch (err) {
            error("Could not put back the Remnant a rerolled clean-up erased", err);
        }
    }

    if (typeof receipt.stressBefore === "number") {
        try {
            await automatedUpdate(actor, {
                "system.resources.stress.value": receipt.stressBefore
            });
        } catch (err) {
            error("Could not refund the Stress a rerolled clean-up spent", err);
        }
    }

    lastAttempt.delete(actor.id);
    return true;
}

async function spendStress(actor) {
    const marks = resourceValue(actor, "stress");
    const max = resourceMax(actor, "stress");
    if (marks >= max) return;
    try {
        await automatedUpdate(actor, {
            "system.resources.stress.value": Math.min(max, marks + RESOLUTION_STRESS_COST)
        });
    } catch (err) {
        error("Could not charge the Stress for a clean-up", err);
    }
}

/**
 * Two different messages on purpose.
 *
 * The killer is told what happened to the scene. The GMs are told that plus the
 * threshold it was measured against, because that number is the answer key and
 * the killer must not learn how visible their own traces are by subtraction.
 */
async function report(actor, data, { band, success, total, dc, done }) {
    const summary = done.map(line => `<li>${line}</li>`).join("");

    await whisperToOwner(actor, `
        <h3>${game.i18n.localize("DRPG.Cleanup.title")}</h3>
        <p><strong>${game.i18n.localize(`DRPG.Cleanup.band.${band}`)}</strong></p>
        ${summary ? `<ul>${summary}</ul>` : ""}
        <p><small>${game.i18n.format("DRPG.Cleanup.stressSpent", { n: RESOLUTION_STRESS_COST })}</small></p>`);

    await whisperToGms(`
        <h3>${game.i18n.localize("DRPG.Cleanup.title")}</h3>
        <p>${game.i18n.format("DRPG.Cleanup.gmLine", {
            actor: foundry.utils.escapeHTML(actor.name),
            what: foundry.utils.escapeHTML(`${data.visibilityLabel} ${data.typeLabel}`),
            total,
            dc: dc ?? "—",
            verdict: game.i18n.localize(success ? "DRPG.Cleanup.hit" : "DRPG.Cleanup.miss")
        })}</p>
        ${summary ? `<ul>${summary}</ul>` : ""}`);
}

/* ==========================================================================
 * THE KILLER'S SCREEN
 * ========================================================================== */

/**
 * Pick something to wipe.
 *
 * What the killer is shown is what their character can now see — Stage 6 is the
 * point at which the guide lets them look at their own traces — but NOT how hard
 * any of it is to erase. The threshold comes from a Remnant's visibility, and
 * showing it would hand them a reading of how much evidence they left, which is
 * the trial's whole question. Reinforced traces are the exception and are named
 * outright: "this one is not going anywhere" is a decision they have to be able
 * to make.
 */
export async function openCleanupDialog(actor) {
    if (!isCleaner(actor)) {
        ui.notifications.warn(game.i18n.localize("DRPG.Cleanup.notYours"));
        return null;
    }

    const traces = cleanableRemnants(actor);
    if (!traces.length) {
        ui.notifications.info(game.i18n.localize("DRPG.Cleanup.nothingHere"));
        return null;
    }

    // Every trace here refuses to be removed. The picker would open with every
    // option disabled, no value to submit, and a confirm button that did nothing
    // — a dead end that looks like a bug. Say what is actually true instead.
    if (traces.every(t => t.data.reinforced)) {
        ui.notifications.warn(game.i18n.localize("DRPG.Cleanup.allReinforced"));
        return null;
    }

    const options = traces.map(t => {
        const label = [
            `${t.data.visibilityLabel} ${t.data.typeLabel}`,
            t.data.reinforced ? game.i18n.localize("DRPG.Cleanup.reinforcedFlag") : null
        ].filter(Boolean).join(" · ");
        return `<option value="${t.token.id}"${t.data.reinforced ? " disabled" : ""}>${
            foundry.utils.escapeHTML(label)}</option>`;
    }).join("");

    const tool = cleaningTool(actor);
    const DialogV2 = foundry.applications.api.DialogV2;
    const { dialogContent } = await import("./utils.mjs");

    const picked = await DialogV2.wait({
        window: { title: game.i18n.localize("DRPG.Cleanup.title") },
        classes: ["drpg-panel"],
        content: dialogContent(`<form>
            <p>${game.i18n.format("DRPG.Cleanup.intro", { n: RESOLUTION_STRESS_COST })}</p>
            <p class="notes">${tool
                ? game.i18n.format("DRPG.Cleanup.withTool", {
                    item: foundry.utils.escapeHTML(tool.name), tier: cleaningTier(actor)
                })
                : game.i18n.localize("DRPG.Cleanup.bareHands")}</p>
            <label>${game.i18n.localize("DRPG.Cleanup.which")}
                <select name="trace">${options}</select></label>
        </form>`),
        buttons: [
            {
                action: "ok", label: game.i18n.localize("DRPG.Cleanup.confirm"), default: true,
                callback: (e, b, d) => d.element.querySelector("[name=trace]").value
            },
            { action: "cancel", label: game.i18n.localize("DRPG.Advance.cancel") }
        ],
        rejectClose: false
    });

    if (!picked || picked === "cancel") return null;
    return attemptCleanup(actor, picked);
}

/* ==========================================================================
 * CLOSING THE STAGE
 * ========================================================================== */

/**
 * Stage 6 is over: destroy the tools it used up.
 *
 * `CLEANUP.destroysTools` has declared for some time that a crime tool used in
 * an incident is destroyed, and nothing was destroying anything. The cleaning tool
 * goes the same way and for the same reason — one crime scene, one set of
 * gloves. Both are read as EQUIPPED items: an unopened spare in the stash is not
 * a thing that was used.
 *
 * Called by `endMurder`, so it also covers a GM closing an incident by hand.
 */
export async function endResolution(actor) {
    if (!game.user.isGM || !actor) return [];

    const destroyed = [];
    for (const category of CLEANUP.destroysTools) {
        const item = equippedIn(actor, category);
        if (!item) continue;
        try {
            destroyed.push(item.name);
            await item.delete();
        } catch (err) {
            error(`Could not destroy the ${category} used in the incident`, err);
        }
    }

    if (destroyed.length) {
        await whisperToOwner(actor, `<p>${game.i18n.format("DRPG.Cleanup.toolsGone", {
            items: foundry.utils.escapeHTML(destroyed.join(", "))
        })}</p>`);
        log(`Cleanup: destroyed ${destroyed.join(", ")} used by ${actor.name}.`);
    }
    return destroyed;
}
