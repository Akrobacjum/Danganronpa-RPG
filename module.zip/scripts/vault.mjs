/**
 * Danganronpa RPG — the stash.
 * ---------------------------------------------------------------------------
 * A character carries three usable items, one crime tool and two cleaning
 * tools, and not one thing more. The stash is where the rest of what they own
 * lives: their own bedroom, uncapped, and — this being a killing game —
 * searchable by anybody who walks in while they are elsewhere.
 *
 * Two flags carry the whole thing:
 *
 *   on the ROOM    `drpgVaultOwner`     whose bedroom this is
 *                  `drpgVaultConcealed` they have built a hiding place in it
 *   on the ITEM    `location`           carried, or stashed
 *
 * The item flag is the important design choice. A stashed item is still an
 * ordinary item on its owner's sheet, not a document living somewhere else —
 * so everything that sweeps a character's belongings reaches it without having
 * to know stashes exist. Decision D1's "przedmioty noszone i w skrytce znikają"
 * was already true the moment this flag landed; `killCharacter` needed no
 * change at all.
 */

import { MODULE_ID, ITEM_CATEGORIES } from "./config.mjs";
import { ITEM_FLAGS, LOCATIONS, isStashed, canCarry } from "./inventory.mjs";
// The one room lookup. movement.mjs does not reach back into this file.
import { roomOfActor } from "./movement.mjs";
import { dialogContent, whisperToOwner, log, error } from "./utils.mjs";

const DialogV2 = foundry.applications.api.DialogV2;

/**
 * Region flags. Prefixed like the other room flags a GM might read by hand.
 *
 * `table` and `favours` are not about stashes at all — they are what makes a
 * room a *place* rather than a name: what turns up when you search it, and what
 * it is a good place to search FOR. They live here because they are set on the
 * same screen, from the same region documents, as the rest of it.
 */
export const VAULT_FLAGS = {
    owner: "drpgVaultOwner",
    concealed: "drpgVaultConcealed",
    /** Name of a RollTable this room draws from, instead of the global pool. */
    table: "drpgItemTable",
    /** Item categories this room is a sensible place to look for. */
    favours: "drpgFavours"
};

/** The RollTable this room draws from, or `null` for the global pool. */
export function roomTable(room, scene = canvas?.scene) {
    return regionsByName(scene).get(room)?.getFlag(MODULE_ID, VAULT_FLAGS.table) || null;
}

/** Categories this room is a good place to search for. */
export function roomFavours(room, scene = canvas?.scene) {
    return regionsByName(scene).get(room)?.getFlag(MODULE_ID, VAULT_FLAGS.favours) ?? [];
}

/**
 * Does looking for this here make sense?
 *
 * The medic's office is where the medicine is. Searching the boiler room for
 * bandages should not be as good a bet, and the guide agrees: "co się znajdzie,
 * może zależeć od pomieszczenia".
 */
export function favoursCategory(room, category) {
    return roomFavours(room).includes(category);
}

/* ==========================================================================
 * WHOSE ROOM IS THIS
 * ========================================================================== */

function regionsByName(scene = canvas?.scene) {
    const map = new Map();
    for (const region of scene?.regions ?? []) {
        if (region.name) map.set(region.name, region);
    }
    return map;
}

/** The actor id whose stash lives in this room, or `null`. */
export function vaultOwnerOf(room, scene = canvas?.scene) {
    return regionsByName(scene).get(room)?.getFlag(MODULE_ID, VAULT_FLAGS.owner) ?? null;
}

/** Has a "build a stash" project made this room's contents hard to find? */
export function isConcealed(room, scene = canvas?.scene) {
    return Boolean(regionsByName(scene).get(room)?.getFlag(MODULE_ID, VAULT_FLAGS.concealed));
}

/** The room this character stashes things in, or `null`. */
export function vaultRoomFor(actor, scene = canvas?.scene) {
    if (!actor) return null;
    for (const [name, region] of regionsByName(scene)) {
        if (region.getFlag(MODULE_ID, VAULT_FLAGS.owner) === actor.id) return name;
    }
    return null;
}

/** Every room on the scene that belongs to somebody. */
export function allVaults(scene = canvas?.scene) {
    const out = [];
    for (const [name, region] of regionsByName(scene)) {
        const owner = region.getFlag(MODULE_ID, VAULT_FLAGS.owner);
        if (!owner) continue;
        out.push({
            room: name,
            owner: game.actors.get(owner) ?? null,
            concealed: Boolean(region.getFlag(MODULE_ID, VAULT_FLAGS.concealed))
        });
    }
    return out;
}

/** GM: point a room at an owner, and say whether it is concealed. */
export async function setVaultRoom(room, {
    owner = undefined, concealed = undefined, table = undefined, favours = undefined
} = {}) {
    if (!game.user.isGM) return null;

    const region = regionsByName().get(room);
    if (!region) return null;

    const update = {};
    if (owner !== undefined) update[`flags.${MODULE_ID}.${VAULT_FLAGS.owner}`] = owner || null;
    if (concealed !== undefined) {
        update[`flags.${MODULE_ID}.${VAULT_FLAGS.concealed}`] = Boolean(concealed);
    }
    if (table !== undefined) update[`flags.${MODULE_ID}.${VAULT_FLAGS.table}`] = table || null;
    if (favours !== undefined) {
        update[`flags.${MODULE_ID}.${VAULT_FLAGS.favours}`] = Array.isArray(favours) ? favours : [];
    }
    if (!Object.keys(update).length) return null;

    await region.update(update);
    return region;
}

/* ==========================================================================
 * WHAT IS IN IT
 * ========================================================================== */

/** Everything this character has stashed. Uncapped by design. */
export function vaultContents(actor) {
    if (!actor) return [];
    return actor.items.filter(i =>
        i.getFlag(MODULE_ID, ITEM_FLAGS.category) && isStashed(i));
}

/** Am I standing in my own stash room? */
export async function atOwnVault(actor) {
    const room = vaultRoomFor(actor);
    if (!room) return false;
    const { roomOfActor } = await import("./movement.mjs");
    return roomOfActor(actor) === room;
}

/**
 * Put something away. No action, no roll — but you have to be there.
 *
 * Truth Bullets are refused outright: they are not objects in a drawer, they
 * are what the character knows, and hiding one would only mean hiding it from
 * the trial the whole game is pointed at.
 */
export async function stow(actor, item) {
    if (!actor || !item) return false;

    if (item.getFlag(MODULE_ID, ITEM_FLAGS.category) === "truthBullet") {
        ui.notifications.warn(game.i18n.localize("DRPG.Vault.noBullets"));
        return false;
    }
    if (isStashed(item)) return false;

    if (!await atOwnVault(actor)) {
        ui.notifications.warn(game.i18n.localize("DRPG.Vault.notHere"));
        return false;
    }

    try {
        await item.setFlag(MODULE_ID, ITEM_FLAGS.location, LOCATIONS.vault);
    } catch (err) {
        error("Could not stash the item", err);
        return false;
    }

    log(`${actor.name} stashed "${item.name}".`);
    return true;
}

/** Take something back out. The carry limit has a say on the way out. */
export async function retrieve(actor, item) {
    if (!actor || !item || !isStashed(item)) return false;

    if (!await atOwnVault(actor)) {
        ui.notifications.warn(game.i18n.localize("DRPG.Vault.notHere"));
        return false;
    }

    const category = item.getFlag(MODULE_ID, ITEM_FLAGS.category);
    const room = canCarry(actor, category);
    if (!room.ok) {
        ui.notifications.warn(game.i18n.format("DRPG.Inventory.full", {
            category: ITEM_CATEGORIES[category]?.plural ?? category,
            limit: room.limit
        }));
        return false;
    }

    try {
        await item.setFlag(MODULE_ID, ITEM_FLAGS.location, LOCATIONS.carried);
    } catch (err) {
        error("Could not take the item out of the stash", err);
        return false;
    }

    log(`${actor.name} took "${item.name}" out of their stash.`);
    return true;
}

/* ==========================================================================
 * SOMEBODY ELSE'S STASH
 * ========================================================================== */

/**
 * Whose stash is in the room this character is standing in, if it is open.
 *
 * "Open" means not concealed. A concealed stash is one its owner has built a
 * hiding place for — a project — and finding that is what the Search action's
 * own stash branch is for, at a penalty, with a roll. An unconcealed stash is
 * just a drawer in a bedroom: anyone who walks in can go through it, which is
 * exactly the pressure a killing game wants on leaving your things lying about.
 *
 * @returns {{owner: Actor, room: string, items: Item[]}|null}
 */
export function openStashHere(actor) {
    if (!actor) return null;

    // `roomOfActor` is the module's one answer to "which room is this actor in"
    // — it already handles unlinked tokens, an empty region set and the
    // geometric fallback. A local re-implementation here was a third copy of
    // that logic, and a copy of a geometric test is a copy that drifts.
    const room = roomOfActor(actor);
    if (!room) return null;

    const ownerId = vaultOwnerOf(room);
    if (!ownerId || ownerId === actor.id) return null;   // yours is not a theft
    if (isConcealed(room)) return null;                  // hidden: needs a Search

    const owner = game.actors.get(ownerId);
    if (!owner) return null;

    return { owner, room, items: vaultContents(owner) };
}

/**
 * Go through an open stash and take one thing. No action, no roll.
 *
 * The write itself is GM-only — it touches two sheets — so it goes over the
 * same bridge the Search branch uses, and `stealFromVault` re-checks everything
 * on that side. This is the picker, not the authority.
 */
export async function rifleStashDialog(actor) {
    const here = openStashHere(actor);
    if (!here) {
        ui.notifications.warn(game.i18n.localize("DRPG.Vault.noOpenStashHere"));
        return false;
    }
    if (!here.items.length) {
        ui.notifications.info(game.i18n.format("DRPG.Vault.stashEmpty", {
            who: here.owner.name
        }));
        return false;
    }

    const options = here.items.map(i => {
        const tier = i.getFlag(MODULE_ID, ITEM_FLAGS.tier);
        const cat = ITEM_CATEGORIES[i.getFlag(MODULE_ID, ITEM_FLAGS.category)]?.label ?? "";
        return `<option value="${i.id}">${foundry.utils.escapeHTML(
            `${i.name}${cat ? ` — ${cat}` : ""}${tier !== null && tier !== undefined ? ` (T${tier})` : ""}`
        )}</option>`;
    }).join("");

    const picked = await DialogV2.wait({
        window: { title: game.i18n.format("DRPG.Vault.rifleTitle", { room: here.room }) },
        classes: ["drpg-panel"],
        content: dialogContent(`<form>
            <p>${game.i18n.format("DRPG.Vault.rifleIntro", {
                who: foundry.utils.escapeHTML(here.owner.name),
                room: foundry.utils.escapeHTML(here.room)
            })}</p>
            <label>${game.i18n.localize("DRPG.Items.whichItem")}
                <select name="item">${options}</select></label>
            <p class="notes">${game.i18n.localize("DRPG.Vault.rifleNote")}</p>
        </form>`),
        buttons: [
            {
                action: "take", label: game.i18n.localize("DRPG.Vault.take"), default: true,
                callback: (e, b, d) => d.element.querySelector("[name=item]").value
            },
            { action: "cancel", label: game.i18n.localize("DRPG.Advance.cancel") }
        ],
        rejectClose: false
    });

    if (!picked || picked === "cancel") return false;

    const { requestVaultSteal } = await import("./gm-bridge.mjs");
    await requestVaultSteal({ thiefId: actor.id, ownerId: here.owner.id, itemId: picked });
    return true;
}

/**
 * Take one thing out of a stash that is not yours. GM-side: it writes to the
 * owner's sheet and to the thief's.
 *
 * The item moves rather than being copied — this is theft, and the owner
 * noticing that something is missing is the entire point.
 */
export async function stealFromVault({ thiefId, ownerId, itemId } = {}) {
    if (!game.user.isGM) return null;

    const thief = game.actors.get(thiefId);
    const owner = game.actors.get(ownerId);
    const item = owner?.items?.get(itemId);
    if (!thief || !owner || !item || !isStashed(item)) return null;

    // The dead rob nobody. A socket payload is a claim, and this side is the
    // one that decides — the same reasoning `handover.mjs` applies to a gift.
    const { isDeceased } = await import("./chapter.mjs");
    if (isDeceased(thief)) {
        error(`Refused a stash theft: ${thief.name} is dead.`);
        return null;
    }

    const category = item.getFlag(MODULE_ID, ITEM_FLAGS.category);
    const { grantItem } = await import("./inventory.mjs");

    const copy = await grantItem(thief, {
        name: item.name,
        category,
        tier: item.getFlag(MODULE_ID, ITEM_FLAGS.tier) ?? null,
        description: item.system?.description ?? "",
        img: item.img
    });
    if (!copy) return null;

    try {
        await item.delete();
    } catch (err) {
        error("Could not remove the stolen item from the stash", err);
    }

    await whisperToOwner(thief, `<p>${game.i18n.format("DRPG.Vault.stole", {
        item: foundry.utils.escapeHTML(item.name),
        who: foundry.utils.escapeHTML(owner.name)
    })}</p>`);

    log(`${thief.name} took "${item.name}" from ${owner.name}'s stash.`);
    return copy;
}

/* ==========================================================================
 * GM SETUP
 * ========================================================================== */

/**
 * One screen for everything a room IS.
 *
 * Whose bedroom it is, whether the stash in it is hidden, what searching it
 * draws from, what it is a good place to search for — and, since they are the
 * same kind of question asked of the same regions on the same evening, which
 * rests it allows. Those two used to be separate dialogs on separate GM-panel
 * entries, which meant setting up a map was a lap of the panel per room rather
 * than one pass down a table.
 *
 * Every column is a region flag written when the map is built. `rest.mjs` still
 * owns the two rest flags and their readers; this only edits them.
 */
export async function openRoomSetupDialog() {
    if (!game.user.isGM) {
        ui.notifications.warn(game.i18n.localize("DRPG.Panel.gmOnly"));
        return null;
    }

    const rooms = Array.from(regionsByName().keys());
    if (!rooms.length) {
        ui.notifications.warn(game.i18n.localize("DRPG.Vault.noRooms"));
        return null;
    }

    const { studentActors } = await import("./monokuma.mjs");
    const { REST_FLAGS, setRestRoom } = await import("./rest.mjs");
    const students = studentActors();
    const tables = Array.from(game.tables ?? []).map(t => t.name).sort();
    // Truth Bullets are not searched for, so they are not a category a room can
    // stock or favour.
    const categories = Object.entries(ITEM_CATEGORIES).filter(([key]) => key !== "truthBullet");
    const regions = regionsByName();

    const rows = rooms.map(room => {
        const owner = vaultOwnerOf(room) ?? "";
        const table = roomTable(room) ?? "";
        const favours = roomFavours(room);
        const region = regions.get(room);
        const esc = foundry.utils.escapeHTML(room);

        const people = students.map(a =>
            `<option value="${a.id}"${a.id === owner ? " selected" : ""}>${
                foundry.utils.escapeHTML(a.name)}</option>`).join("");
        const tableOptions = tables.map(t =>
            `<option value="${foundry.utils.escapeHTML(t)}"${t === table ? " selected" : ""}>${
                foundry.utils.escapeHTML(t)}</option>`).join("");
        const boxes = categories.map(([key, cat]) =>
            `<label class="drpg-inline-check"><input type="checkbox"
                name="fav:${esc}:${key}" ${favours.includes(key) ? "checked" : ""} />${
                foundry.utils.escapeHTML(cat.label)}</label>`).join(" ");

        return `<tr>
            <td><strong>${esc}</strong></td>
            <td><select name="owner:${esc}"><option value="">—</option>${people}</select></td>
            <td style="text-align:center"><input type="checkbox" name="concealed:${esc}"
                ${isConcealed(room) ? "checked" : ""} /></td>
            <td style="text-align:center"><input type="checkbox" name="short:${esc}"
                ${region?.getFlag(MODULE_ID, REST_FLAGS.short) ? "checked" : ""} /></td>
            <td style="text-align:center"><input type="checkbox" name="long:${esc}"
                ${region?.getFlag(MODULE_ID, REST_FLAGS.long) ? "checked" : ""} /></td>
            <td><select name="table:${esc}">
                <option value="">${game.i18n.localize("DRPG.Vault.globalPool")}</option>
                ${tableOptions}</select></td>
            <td>${boxes}</td>
        </tr>`;
    }).join("");

    const result = await DialogV2.wait({
        window: { title: game.i18n.localize("DRPG.Vault.manageTitle") },
        // `drpg-projects` as well as `drpg-panel`: that is the class the
        // stylesheet hangs the table treatment on — full width, a scrolling
        // window-content and sane select sizing. Without it this dialog asked
        // for 860px, lost to the 26rem `.drpg-panel` cap, and clipped its own
        // right-hand columns with no way to scroll to them.
        classes: ["drpg-panel", "drpg-projects"],
        content: dialogContent(`<form>
            <p>${game.i18n.localize("DRPG.Vault.manageIntro")}</p>
            <table class="drpg-vault-table"><thead><tr>
                <th>${game.i18n.localize("DRPG.Vault.room")}</th>
                <th>${game.i18n.localize("DRPG.Vault.owner")}</th>
                <th>${game.i18n.localize("DRPG.Vault.concealed")}</th>
                <th>${game.i18n.localize("DRPG.Rest.shortColumn")}</th>
                <th>${game.i18n.localize("DRPG.Rest.longColumn")}</th>
                <th>${game.i18n.localize("DRPG.Vault.table")}</th>
                <th>${game.i18n.localize("DRPG.Vault.favours")}</th>
            </tr></thead><tbody>${rows}</tbody></table>
            <p class="notes">${game.i18n.localize("DRPG.Vault.manageNote")}</p>
            <p class="notes">${game.i18n.localize("DRPG.Rest.manageIntro")}</p>
        </form>`),
        buttons: [
            {
                action: "ok", label: game.i18n.localize("DRPG.Panel.apply"), default: true,
                callback: (e, b, d) => {
                    const f = d.element.querySelector("form");
                    const pick = name => f.querySelector(`[name="${name}"]`);
                    return rooms.map(room => ({
                        room,
                        owner: pick(`owner:${CSS.escape(room)}`)?.value ?? "",
                        concealed: Boolean(pick(`concealed:${CSS.escape(room)}`)?.checked),
                        shortRest: Boolean(pick(`short:${CSS.escape(room)}`)?.checked),
                        longRest: Boolean(pick(`long:${CSS.escape(room)}`)?.checked),
                        table: pick(`table:${CSS.escape(room)}`)?.value ?? "",
                        favours: categories
                            .map(([key]) => key)
                            .filter(key => pick(`fav:${CSS.escape(room)}:${key}`)?.checked)
                    }));
                }
            },
            { action: "cancel", label: game.i18n.localize("DRPG.Advance.cancel") }
        ],
        rejectClose: false
    });

    if (!Array.isArray(result)) return null;

    // One owner, one room. Two bedrooms pointing at the same student would make
    // `vaultRoomFor` answer differently depending on region order, which is the
    // kind of bug that only shows up mid-session.
    const claimed = new Map();
    for (const row of result) {
        if (!row.owner) continue;
        if (claimed.has(row.owner)) {
            ui.notifications.error(game.i18n.format("DRPG.Vault.twoRooms", {
                name: game.actors.get(row.owner)?.name ?? "?",
                a: claimed.get(row.owner), b: row.room
            }));
            return null;
        }
        claimed.set(row.owner, row.room);
    }

    let changed = 0;
    for (const row of result) {
        const region = regionsByName().get(row.room);
        if (!region) continue;

        const before = {
            owner: region.getFlag(MODULE_ID, VAULT_FLAGS.owner) ?? null,
            concealed: Boolean(region.getFlag(MODULE_ID, VAULT_FLAGS.concealed)),
            table: region.getFlag(MODULE_ID, VAULT_FLAGS.table) ?? null,
            favours: region.getFlag(MODULE_ID, VAULT_FLAGS.favours) ?? []
        };
        const beforeRest = {
            short: Boolean(region.getFlag(MODULE_ID, REST_FLAGS.short)),
            long: Boolean(region.getFlag(MODULE_ID, REST_FLAGS.long))
        };

        const same = before.owner === (row.owner || null)
            && before.concealed === row.concealed
            && before.table === (row.table || null)
            && beforeRest.short === row.shortRest
            && beforeRest.long === row.longRest
            && before.favours.length === row.favours.length
            && before.favours.every(f => row.favours.includes(f));
        if (same) continue;

        await setVaultRoom(row.room, {
            owner: row.owner,
            concealed: row.concealed,
            table: row.table,
            favours: row.favours
        });
        // Through rest.mjs's own writer rather than a second flag path, so the
        // two rest flags keep one owner.
        await setRestRoom(row.room, { short: row.shortRest, long: row.longRest });
        changed++;
    }

    ui.notifications.info(game.i18n.format("DRPG.Vault.saved", { n: changed }));
    return changed;
}

/** GM: look inside anybody's stash, and pull things out of it. */
export async function openVaultInspector() {
    if (!game.user.isGM) {
        ui.notifications.warn(game.i18n.localize("DRPG.Panel.gmOnly"));
        return null;
    }

    const vaults = allVaults().filter(v => v.owner);
    if (!vaults.length) {
        ui.notifications.warn(game.i18n.localize("DRPG.Vault.noneSet"));
        return null;
    }

    const sections = vaults.map(v => {
        const items = vaultContents(v.owner);
        const list = items.length
            ? items.map(i => `<li>${foundry.utils.escapeHTML(i.name)} — ${
                foundry.utils.escapeHTML(
                    ITEM_CATEGORIES[i.getFlag(MODULE_ID, ITEM_FLAGS.category)]?.label ?? "?")
            }</li>`).join("")
            : `<li class="notes">${game.i18n.localize("DRPG.Sheet.groupEmpty")}</li>`;
        return `<div class="drpg-vault-section">
            <h4>${foundry.utils.escapeHTML(v.owner.name)} — ${foundry.utils.escapeHTML(v.room)}${
                v.concealed ? ` · <em>${game.i18n.localize("DRPG.Vault.concealedShort")}</em>` : ""
            }</h4>
            <ul>${list}</ul>
        </div>`;
    }).join("");

    return DialogV2.wait({
        window: { title: game.i18n.localize("DRPG.Vault.inspectTitle") },
        classes: ["drpg-panel"],
        content: dialogContent(`<div>${sections}
            <p class="notes">${game.i18n.localize("DRPG.Vault.inspectNote")}</p></div>`),
        buttons: [{ action: "close", label: game.i18n.localize("DRPG.Panel.close"), default: true }],
        rejectClose: false
    });
}
