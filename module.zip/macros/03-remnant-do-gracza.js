/**
 * MAKRO: Truth Bullet do gracza
 * ---------------------------------------------------------------------------
 * Kopiuje wybrany Remnant z mapy do ekwipunku jednego lub kilku graczy jako
 * Truth Bullet. Sam Remnant zostaje na miejscu — tak jak chce przewodnik.
 *
 * WAZNE — co sie zmienilo wzgledem starej wersji tego makra:
 * poprzednio makro tworzylo przedmiot z flaga `truthBullet: true`. Karta postaci
 * grupuje ekwipunek po fladze `category`, wiec te kule NIGDY nie pojawialy sie
 * w zakladce Truth Bullets ani w zadnym liczniku — istnialy tylko jako luzny
 * przedmiot. Teraz makro wola `game.drpg.grantItem` z `category: "truthBullet"`,
 * czyli tak samo jak reszta modulu.
 *
 * Typ makra: Script.  Uruchamia: tylko DM.
 */

const DialogV2 = foundry.applications.api.DialogV2;

if (!game.user.isGM) {
    ui.notifications.warn("To makro moze uruchomic tylko DM.");
    return;
}
if (!game.drpg?.grantItem) {
    ui.notifications.error("Modul Danganronpa RPG nie jest aktywny.");
    return;
}

// --- Ktory Remnant ---------------------------------------------------------
const remnants = game.drpg.remnantsOn(canvas.scene)
    .map(t => ({ token: t, data: game.drpg.remnantData(t) }))
    .filter(r => r.data);

if (!remnants.length) {
    ui.notifications.warn("Na tej scenie nie ma zadnych Remnantow. Postaw je makrem nr 2.");
    return;
}

// --- Komu ------------------------------------------------------------------
const uczniowie = game.drpg.studentActors();
if (!uczniowie.length) {
    ui.notifications.warn("Brak postaci graczy.");
    return;
}

const wynik = await DialogV2.wait({
    window: { title: "Truth Bullet do gracza" },
    classes: ["drpg-panel"],
    position: { width: 520 },
    content: `
    <form class="flexcol" style="gap:8px">
      <div class="form-group">
        <label>Ktory Remnant</label>
        <select name="remnant">${
            remnants.map((r, i) => {
                const d = r.data;
                const opis = `${d.visibilityLabel} ${d.typeLabel}${d.room ? ` · ${d.room}` : ""}${d.subject ? ` · ${d.subject}` : ""}`;
                return `<option value="${i}">${foundry.utils.escapeHTML(opis)}</option>`;
            }).join("")
        }</select>
      </div>
      <div class="form-group">
        <label>Nazwa kuli — to widzi gracz</label>
        <input type="text" name="name" placeholder="np. Slad blota przy oknie" autofocus>
      </div>
      <div class="form-group">
        <label>Opis dla gracza</label>
        <textarea name="description" rows="3" placeholder="Co dokladnie widzi ten, kto to znalazl."></textarea>
      </div>
      <div class="form-group">
        <label>Komu (Ctrl / Shift zaznacza kilku)</label>
        <select name="targets" multiple size="${Math.min(8, uczniowie.length)}">${
            uczniowie.map(a => `<option value="${a.id}">${foundry.utils.escapeHTML(a.name)}</option>`).join("")
        }</select>
      </div>
      <p class="notes">Remnant zostaje na mapie. Kula trafia do ekwipunku i do zakladki Truth Bullets.</p>
    </form>`,
    buttons: [
        {
            action: "ok",
            label: "Wydaj",
            default: true,
            callback: (event, button, dialog) => {
                const f = dialog.element.querySelector("form");
                return {
                    remnant: Number(f.remnant.value),
                    name: f.name.value.trim(),
                    description: f.description.value.trim(),
                    targets: Array.from(f.targets.selectedOptions).map(o => o.value)
                };
            }
        },
        { action: "cancel", label: "Anuluj" }
    ],
    rejectClose: false
});

if (!wynik || wynik === "cancel") return;

if (!wynik.targets.length) {
    ui.notifications.warn("Nie wybrano zadnego gracza.");
    return;
}

const zrodlo = remnants[wynik.remnant];
const nazwa = wynik.name || `${zrodlo.data.visibilityLabel} ${zrodlo.data.typeLabel}`;

let wydano = 0;
for (const id of wynik.targets) {
    const actor = game.actors.get(id);
    if (!actor) continue;

    // Ta sama sciezka co reszta modulu: kategoria "truthBullet" jest tym, po
    // czym karta postaci grupuje ekwipunek. Truth Bullety nie maja limitu.
    const item = await game.drpg.grantItem(actor, {
        name: nazwa,
        category: "truthBullet",
        // Kula dziedziczy widocznosc Remnanta, z ktorego powstala — to ona
        // decyduje pozniej o progu Analizy.
        tier: game.drpg.config.REMNANT_VISIBILITY.indexOf(zrodlo.data.visibility),
        description: wynik.description
            ? `<p>${foundry.utils.escapeHTML(wynik.description)}</p>`
            : `<p>${foundry.utils.escapeHTML(zrodlo.data.note || "—")}</p>`,
        override: true
    });
    if (!item) continue;

    wydano++;
    await game.drpg.whisperToOwner(actor, `
      <h3>Nowy Truth Bullet</h3>
      <p><strong>${foundry.utils.escapeHTML(nazwa)}</strong></p>
      ${wynik.description ? `<p>${foundry.utils.escapeHTML(wynik.description)}</p>` : ""}
      <p><small>Znajdziesz go w ekwipunku, w zakladce Truth Bullets.</small></p>`);
}

ui.notifications.info(`Wydano Truth Bullet "${nazwa}" — ${wydano} gracz(y).`);
